# HADS 4.7.0-rc7 — bezpečnostní oprava

## Co je opraveno

- Placená AI je po upgradu z RC6 vypnutá i při existujícím klíči a zapnutém výzkumu. Nová volba `ai_paid_calls_enabled` vyžaduje výslovné zapnutí. Samostatná volba `ai_paid_web_enabled` povoluje web.
- Staré `ai_call_limits_enabled: false` už limity neobchází. Limity jsou klouzavých 24 hodin, sdílené chatem a automatickým výzkumem a přežívají restart. Neúspěšné a přerušené požadavky se započítají.
- Nová instalace: 6 požadavků / 24 hodin, 2 na případ. Upgrade zachová nižší nastavení; tvrdé maximum je 20 celkem a 6 na případ. Nastavení vyšší než maximum se za běhu ořízne. Nejde o dolarový strop ani záruku, že se dlouhodobě nespotřebuje celý kredit.
- Každý požadavek má nejvýše 4000 výstupních tokenů včetně uvažování a nejvýše jedno vestavěné volání nástroje. Vstupní limit 64 kB zůstává. Web může přidat účtované tokeny. Účtování závisí na modelu a poskytovateli.
- Oficiální kontrola `/core/check` již neběží uvnitř globální databázové transakce. Po dobu čekání mohou jiné požadavky číst incidenty.
- Panel výslovně ukazuje bezpečnostní vypnutí AI a účinné limity.

## Co netvrdíme

Příčina selhání HTTP healthchecku Supervisor watchdogu není prokázaná. Odstranění databázového blokování není důkaz odstranění všech restartů. Health endpoint nepoužívá databázi. Tato verze nebyla nasazena ani ověřena na živém HAOS při sestavení.

## Postup po instalaci

1. Nechte placenou AI i web vypnuté. Nejprve ověřte stabilitu HADS, otevření incidentů během hluboké analýzy a dokončení několika sběrů bez restartu.
2. Při opakovaném restartování HADS zastavte a uložte aktuální HADS a Supervisor log. Nezapínejte AI kvůli řešení nestability HADS.
3. Teprve po ověření stability případně povolte AI, nejprve s limity 3 celkem / 2 na případ a bez webu. Každý krok výzkumu spotřebuje jeden požadavek. Limity nejsou počet kompletních incidentů.
4. Zásahy do HA nadále vyžadují konkrétní schválený plán a ověřenou zálohu. Tato aktualizace je sama nespouští.

## Ověření

Offline testy používají podvržené odpovědi; nevolají placené API. Nové scénáře: starý klíč bez nového souhlasu, 428 pokusů s restartem evidence, souběžná rezervace limitů, samostatný souhlas s webem, tokenový limit a čtení DB z druhého vlákna během Core checku. Přesný výsledek sestavení je v souboru verification.json vedle instalátoru.

Parametry API ověřeny proti dokumentaci: https://developers.openai.com/api/reference/cli/resources/responses/methods/create
