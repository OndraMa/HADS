# HADS 5.1.0-rc1 — funkční pozornost místo seznamu logů

8. 10. 2026. Výchozí zdroj: 5.0.0-rc5. Nový kandidát vyžaduje ověření na HAOS; offline test není záruka funkčnosti všech zařízení.

## Implementováno

- Hlavní přehled a Incidenty rozlišují požadavky na rozhodnutí/výsledky oprav, možné funkční závady, neurčený dopad a rozbalitelné technické důkazy. Logy nejsou vymazány, rozhodnutí ani konverzace se nepřepisují.
- Plánovač přednostně zpracuje přesné plány, neúspěšné zásahy, automatizace, zařízení a Core. Technické případy kontroluje nejdříve po šesti hodinách místo půlhodiny; při více pracovních místech rezervuje jedno pro jejich průběžnou kontrolu.
- Čtení stavu a historie přesných entit probíhá automaticky také bez placené AI. U zařízení se načte asociace v registru a dostupná související baterie/síťová telemetrie; u automatizace stav, historie a existující sběr trace.
- Paměťové incidenty využijí existující čtecí nástroj pro Core/Supervisor, kontejnery a uložené metriky/restartové události. Kontejnerové statistiky nejsou seznam hostitelských procesů.
- Nový nativní sběr má maximálně dvě entity, dvanáct čtecích kroků a šedesátisekundové okno pro zahájení kroků. Již zahájený požadavek může doběhnout do svého timeoutu. Odložený krok není úspěch.
- Čerstvě načtená nedostupná entita může posunout původně technický případ do funkční pozornosti. Po patnácti minutách se tento údaj již nepovažuje za současné potvrzení; historický důkaz zůstává.
- Nedostupnost nejvýše 60 sekund lze odsunout mezi technické důkazy pouze s úplnou, časově seřazenou historií následného zotavení a dostupným aktuálním stavem. Selhaná automatizace, skript, kritický Core a konkrétní opravný plán jsou z této výjimky vyňaté.
- Hlášky o verzi/DNS, PulseAudio, Meross MQTT a iCloud mají stručné české vysvětlení bez předstírání potvrzené příčiny. Úspěšné čtení stavu není fyzický test ani důkaz včerejšího úspěchu.
- Pouze technický případ bez doloženého funkčního dopadu nevolá placenou AI automaticky. Interaktivní dotaz a nové vyšetření neúspěšné opravy stále používají již povolené AI s původními limity.
- Kompaktní panel zachovává důležité nativní důkazy bez velkých historických payloadů. Připravené plány, zálohovací brána a selhání zůstávají dohledatelné.

## Bezpečnost a skutečné meze

Autonomní je diagnostika, nikoli zápis do HA. Žádná oprava se nespustí bez konkrétního schváleného plánu a povinné ověřené OneDrive zálohy. Instalace zůstává na předchozí výslovnou žádost bez nové předinstalační HA/OneDrive zálohy.

Tato verze nerozšiřuje obecná oprávnění MCP ani neumožňuje modelu libovolné shell/SQL příkazy. Podporuje pouze již validované opravné typy. Chybějící historický trace, identitu telefonu či fyzický úspěch akce nelze nahradit odhadem. Rozhraní doplňků nadále musí projít konkrétním ověřením; katalog MCP není potvrzení zdraví doplňku.

Model, API klíče a placené volby se při instalaci automaticky nemění. Během vývoje nebyla spuštěna žádná placená analýza ani zásah v produkčním HAOS. Výsledky spuštěných testů jsou v samostatném verification.json.
