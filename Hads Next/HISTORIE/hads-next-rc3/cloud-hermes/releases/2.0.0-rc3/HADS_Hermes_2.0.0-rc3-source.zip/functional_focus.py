"""Operational attention, not log severity. Pure policy; never authorizes writes.

Technical evidence remains searchable. A model's diagnosis cannot certify current
health; only the native read layer supplies live observations below.
"""
from __future__ import annotations

import datetime as dt
import re
import diagnostic_policy
from mcp_diagnostics import entity_ids


DECISIONS = {"awaiting_decision", "approved", "needs_information", "review_ready"}
PROTECTED = DECISIONS | {"repair_failed", "verifying", "manual_monitoring", "reinvestigate"}
FUNCTIONAL = re.compile(
    r"automation|automatiz|script|skript|unknown (?:entity|service|action)|"
    r"neznám.{0,12}(?:entit|služb)|icloud|play_sound|boot.?loop|"
    r"core.{0,30}(?:crash|failed|unhealthy|pád)|"
    r"(?:device|entity|zařízení|entita).{0,40}(?:unavailable|offline|nedostup|nereag|nefung)|"
    r"(?:excessive|high|velk|výrazn).{0,15}(?:latency|delay|zpožd)|"
    r"out of memory|oom.kill|nedostat.{0,15}pamě|disk.{0,25}(?:full|pln)", re.I)
TECHNICAL = re.compile(
    r"error fetching version|version (?:data|information)|registry.hub.docker.com|nelze zjistit verzi|"
    r"pulseaudio|closing transport|brokenpipe|connectionreset|subscribing to events|"
    r"inspection refresh failed|nedokázal.{0,15}obnovit diagnostiku|"
    r"git metadata|git.{0,15}(?:folder|directory)|orphan.{0,30}statistic|"
    r"osiřel.{0,30}statistik|nepoužívan.{0,20}entit", re.I)
GENERIC = re.compile(r"traceback|\.py[:\", ]|connection error|error fetching|can't read|cannot read", re.I)


def text(row):
    return " ".join(str(row.get(k) or "") for k in ("title", "sample", "normalized_message", "category", "logger"))[:8000]


def classify(row):
    """Human task routing is independent of a P1 label or a frequency score."""
    state = row.get("decision_state")
    research = row.get("research") if isinstance(row.get("research"), dict) else {}
    result = research.get("research") if isinstance(research.get("research"), dict) else {}
    native = result.get("functional_evidence") if isinstance(result.get("functional_evidence"), dict) else {}
    impact = native.get("current_impact")
    try:
        observed = dt.datetime.fromisoformat(str(native.get("observed_at") or "").replace("Z", "+00:00"))
        age = (dt.datetime.now(dt.timezone.utc) - observed).total_seconds()
        if not 0 <= age <= 900:
            impact = "unknown"
    except (ValueError, TypeError):
        impact = "unknown"
    if row.get("repair_prepared") or row.get("repair_plan_id") or state in PROTECTED:
        return {"lane": "action", "rank": 0 if state == "repair_failed" else 1,
                "reason": "Rozhodnutí, opravný plán nebo výsledek zásahu musí zůstat viditelný."}
    if impact == "unavailable":
        return {"lane": "functional", "rank": 2, "reason": "Čerstvé čtení potvrzuje nedostupnou entitu; příčina ještě není potvrzena."}
    value = text(row)
    value = re.sub(r'\b(?:script|automation)\.py\b', '', value, flags=re.I)
    if diagnostic_policy.dns_timeout(value) and not re.search(r'automatiz|automation|skript|script|boot.?loop', value, re.I):
        return {'lane': 'technical', 'rank': 5, 'reason': 'DNS timeout bez doloženého dopadu na funkci; cílová doména není důkaz vadného telefonu.'}
    critical = bool(re.search(r"automation|automatiz|script|skript|boot.?loop|out of memory|oom|core.{0,30}(?:crash|failed|unhealthy|pád)|disk.{0,25}(?:full|pln)", value, re.I))
    if impact == "transient_recovered" and not critical:
        return {"lane": "technical", "rank": 5, "reason": "Historie doložila krátkou nedostupnost a obnovu, současný stav je dostupný. To není důkaz úspěchu všech fyzických akcí."}
    confirmed = row.get("evidence_state") == "confirmed" or any(
        isinstance(e, dict) and e.get("state") == "confirmed" for e in (row.get("evidence") or []))
    if confirmed and not TECHNICAL.search(value):
        return {"lane": "functional", "rank": 2, "reason": "Existuje konkrétní důkaz problému; je třeba posoudit jeho současný dopad."}
    if row.get("category") in {"hads_internal", "diagnostic_coverage"} or TECHNICAL.search(value):
        return {"lane": "technical", "rank": 5, "reason": "Technická nebo diagnostická událost bez doloženého výpadku uživatelské funkce."}
    if FUNCTIONAL.search(value):
        return {"lane": "functional", "rank": 3, "reason": "Možný dopad na automatizaci, zařízení nebo Core; HADS musí ověřit stav a historii."}
    # A transient event is not proof of recovery and never overrides critical
    # evidence or a failed repair, checked above.
    if row.get("temporal_state") in {"grace", "transient"} or GENERIC.search(value):
        return {"lane": "technical", "rank": 5, "reason": "Samotný traceback či krátká transportní událost neprokazuje nefunkční domácnost."}
    return {"lane": "unverified", "rank": 4, "reason": "Dopad není určen. Případ není vymazán ani označen jako vyřešený."}


def annotate(row):
    value = dict(row)
    value["attention"] = classify(value)
    return value


def partition(rows):
    result = {k: [] for k in ("functional", "action", "technical", "unverified")}
    for raw in rows:
        row = annotate(raw)
        result[row["attention"]["lane"]].append(row)
    for values in result.values():
        values.sort(key=lambda r: (r["attention"]["rank"], {"P1": 0, "P2": 1, "P3": 2}.get(r.get("priority"), 3)))
    return result


def due_interval(row):
    # Still check background technical cases; avoid repeatedly spending the
    # foreground worker/AI budget on them every thirty minutes.
    return 6 * 3600 if classify(row)["lane"] == "technical" else 1800


def short_recovery(item):
    """Require ordered, untruncated timestamped history and a fresh live state.

    Never infer outage duration from last_changed or the number of log rows.
    """
    current, history = item.get("current") or {}, item.get("history") or {}
    data = history.get("data") or {}
    if current.get("status") != "ok" or (current.get("data") or {}).get("state") in {None, "unavailable", "unknown"} or ((current.get("data") or {}).get("attributes") or {}).get("restored") is True:
        return False
    if history.get("status") != "ok" or data.get("omitted") or not data.get("records"):
        return False
    pending = previous = None
    recovered = False
    try:
        for row in data["records"]:
            stamp = dt.datetime.fromisoformat(str(row.get("last_changed") or row.get("last_updated") or "").replace("Z", "+00:00"))
            if stamp.tzinfo is None or (previous is not None and stamp < previous):
                return False
            previous = stamp
            state = row.get("state")
            if state in {"unknown", "unavailable"}:
                pending = pending or stamp
            elif state is not None and pending is not None:
                if not 0 < (stamp - pending).total_seconds() <= 60:
                    return False
                recovered = True
                pending = None
        return recovered and pending is None
    except (ValueError, TypeError):
        return False


def collect(case, investigator, now):
    """Bounded native read-only collection, also when paid AI is disabled.

    Identifiers come from scoped evidence, never a similar friendly name.
    Max two device targets and a +/- 12-hour historical window.
    """
    targets = entity_ids(text(case))[:2]
    result = {"observed_at": now, "current_impact": "unknown", "targets": [], "coverage_gaps": [],
              "summary": "Z technické hlášky zatím nelze určit, co v domácnosti nefunguje.",
              "next_step": "HADS potřebuje spojit hlášku s konkrétní funkcí a jejím stavem; bez důkazu nepřipraví změnu."}
    value = text(case)
    specific = diagnostic_policy.explanation(value)
    if re.search(r"error fetching version|registry.hub.docker.com|version information|nelze zjistit verzi", value, re.I):
        result.update(summary="Nepodařilo se zjistit verzi nebo dostupnou aktualizaci. Hláška sama nedokazuje, že zařízení či automatizace nefunguje.",
                      next_step="Porovnat opakování a DNS chybu s ostatními síťovými službami. Bez ověření příčiny neměnit DNS ani nepřeinstalovávat funkční doplněk.")
    elif re.search(r"pulseaudio", value, re.I):
        result.update(summary="Chyba systémové zvukové služby HAOS. Neznamená, že máte nainstalovaný doplněk PulseAudio ani že selhal Music Assistant.",
                      next_step="HADS musí doložit, zda výpadek zasáhl skutečně používané přehrávání nebo hlas. Samotná hláška není důvod měnit funkční konfiguraci.")
    elif re.search(r"mqtt_not_setup_cannot_publish", value, re.I):
        result.update(summary="Meross nemohl publikovat přes MQTT. To ještě nedokazuje výpadek lampy: může fungovat přes HTTP.",
                      next_step="Ověřit transport konkrétního zařízení a jeho historii. Změnu protokolu nabídnout až pro přesný cíl s náhledem, ne lampu znovu párovat naslepo.")
    elif specific:
        result.update(summary=specific['summary'], next_step=specific['next_step'])
    if re.search(r"out of memory|oom|nedostat.{0,15}pamě|memory pressure", value, re.I):
        try:
            from investigation import case_window
            start, end = case_window(case)
            result["resources"] = investigator.resources(start, end)
            result.update(summary="Událost souvisí s pamětí. HADS načetl aktuální kontejnerové metriky a uložené vzorky z času incidentu; krátká špička není sama důkaz slabého hardwaru ani úniku paměti.",
                          next_step="Porovnat růst RAM Core a doplňků, opakování OOM a restart či instalaci ve stejném čase. Upgrade doporučit až podle dlouhodobého měření.")
        except (ValueError, TypeError):
            result["coverage_gaps"].append("Paměťové metriky nelze přiřadit k neznámému času incidentu.")
    if not targets:
        result["coverage_gaps"].append("V incidentu není přesné entity_id; podobný název není bezpečný cíl opravy.")
        return result
    try:
        from investigation import case_window
        start, end = case_window(case)
    except (ValueError, TypeError):
        result["coverage_gaps"].append("Čas incidentu není znám s časovým pásmem; historické okno se nehádá.")
        start = end = None
    unavailable = []
    for target in targets:
        if target.startswith(("automation.", "script.")) or start is None:
            item = {"entity_id": target, "current": investigator.live_state(target)}
            if start:
                item["history"] = investigator.history(target, start, end)
        else:
            item = investigator.device(target, start, end)
        result["targets"].append(item)
        current = item.get("current") or {}
        data = current.get("data") or {}
        if current.get("status") != "ok":
            result["coverage_gaps"].append(f"Aktuální stav {target} nebyl načten; chyba čtení není důkaz výpadku zařízení.")
        elif data.get("state") in {"unavailable", "unknown"} or (data.get("attributes") or {}).get("restored") is True:
            unavailable.append(target)
        history = item.get("history") or {}
        if history and (history.get("status") != "ok" or not (history.get("data") or {}).get("records")):
            result["coverage_gaps"].append(f"Chybí použitelná historie {target}; současný stav nedokazuje minulý úspěch.")
    if unavailable:
        result.update(current_impact="unavailable", summary="Právě nedostupné nebo neznámé: " + ", ".join(unavailable) + ". To může bránit ovládání či automatizaci; důvod výpadku ještě není prokázán.",
                      next_step="HADS porovná historii a telemetrii stejného zařízení. Baterii ani rádiové spojení nebude hádat podle jediné hodnoty RSSI.")
    else:
        if result['targets'] and all(short_recovery(item) for item in result['targets']):
            result['current_impact'] = 'transient_recovered'
        result["summary"] = "HADS načetl důkazy pro " + ", ".join(targets) + ". Aktuální stav není důkaz úspěšného fyzického ovládání ani včerejší automatizace."
        if result['current_impact'] == 'transient_recovered':
            result['summary'] = "Historie doložila nedostupnost nejvýše 60 sekund a následnou obnovu; aktuální stav je dostupný. Nejde o potvrzení úspěchu jednotlivých příkazů."
        result["next_step"] = "Porovnat čas selhání s historií, trace automatizace a jejími přesnými cíli; chybějící data jsou uvedena níže."
    return result
