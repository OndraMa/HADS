"""Explicit operator-run installation helpers. Never imported by HADS runtime.

Backup upload/readback uses the existing HA OneDrive backup agent. Missing
prerequisites stop installation; no Microsoft credentials leave Home Assistant.
"""
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tarfile
import urllib.request
import uuid

import native_backup

SLUG = 'local_hads4'


def supervisor(path, payload=None):
    token = os.environ.get('SUPERVISOR_TOKEN')
    if not token:
        raise RuntimeError('Terminál neposkytuje SUPERVISOR_TOKEN; instalace zastavena.')
    request = urllib.request.Request('http://supervisor'+path,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={'Authorization': 'Bearer '+token, 'Content-Type': 'application/json'})
    with urllib.request.urlopen(request, timeout=1800) as response:
        raw = response.read(2*1024*1024+1)
    if len(raw) > 2*1024*1024:
        raise RuntimeError('Odpověď Supervisoru je příliš velká.')
    result = json.loads(raw)
    if result.get('result') != 'ok':
        raise RuntimeError('Supervisor nepotvrdil úspěch; zkontrolujte jeho protokol.')
    return result.get('data') or {}


def preflight(staging):
    if not os.environ.get('SUPERVISOR_TOKEN'):
        raise RuntimeError('Terminál musí poskytovat SUPERVISOR_TOKEN; hodnotu neposílejte do chatu.')
    supervisor('/supervisor/info')
    agent = native_backup.select_agent(native_backup.backup_agents(), os.environ.get('HADS_ONEDRIVE_AGENT_ID', '').strip())
    # Archive the actual source BEFORE HA snapshots /share. A missing
    # addons/local mount must not silently omit the installed local add-on.
    source = Path('/addons/hads4')
    source_info = None
    if source.is_symlink():
        raise RuntimeError('Zdroj doplňku nesmí být symbolický odkaz.')
    if source.is_dir():
        directory = Path('/share/hads4_preinstall_source')
        if directory.is_symlink():
            raise RuntimeError('Adresář zdrojové zálohy nesmí být symbolický odkaz.')
        directory.mkdir(parents=True, exist_ok=True)
        archive_path = directory / ('hads4-' + uuid.uuid4().hex + '.tar.gz')
        with tarfile.open(archive_path, 'x:gz') as archive:
            archive.add(source, arcname='hads4', recursive=True)
        with archive_path.open('rb') as stream:
            digest, size = native_backup.stream_digest(stream)
        source_info = {'member': archive_path.relative_to('/share').as_posix(), 'sha256': digest, 'bytes': size}
    Path(staging, 'onedrive-preflight.json').write_text(json.dumps({'agent_id': agent, 'source': source_info}), encoding='utf-8')
    print('Nativní OneDrive úložiště nalezeno. Záloha bude před instalací nahrána a celá znovu přečtena.')


def verify_digest(expected, actual):
    if actual != expected or expected[1] <= 0:
        raise RuntimeError('Obsah nebo velikost OneDrive zálohy nesouhlasí; instalace zastavena.')


def cloud_copy(path, agent):
    with Path(path).open('rb') as stream:
        expected = native_backup.stream_digest(stream)
    backup_id = native_backup.upload_backup(Path(path), agent)
    verify_digest(expected, native_backup.readback_sha256(backup_id, agent))
    return {'sha256': expected[0], 'bytes': expected[1], 'agent_id': agent, 'backup_id': backup_id, 'readback_verified': True}


def verify_source_in_backup(backup, source_info):
    if not source_info:
        return
    # Inspect without extracting paths or loading a full archive in RAM.
    with tarfile.open(backup, 'r|*') as outer:
        for member in outer:
            if member.name.removeprefix('./') not in {'share.tar.gz', 'share.tar'} or not member.isfile():
                continue
            with outer.extractfile(member) as stream, tarfile.open(fileobj=stream, mode='r|*') as share:
                for item in share:
                    name = item.name.removeprefix('./').removeprefix('share/')
                    if name == source_info['member'] and item.isfile():
                        with share.extractfile(item) as source:
                            actual = native_backup.stream_digest(source)
                        verify_digest((source_info['sha256'], source_info['bytes']), actual)
                        return
    raise RuntimeError('Plná záloha neobsahuje ověřenou kopii zdrojů HADS. Instalace zastavena.')


def backup_to_cloud(slug, staging):
    if not re.fullmatch(r'[A-Za-z0-9_-]+', slug):
        raise ValueError('Neplatné ID zálohy.')
    preflight_info = json.loads(Path(staging, 'onedrive-preflight.json').read_text(encoding='utf-8'))
    agent = native_backup.select_agent(native_backup.backup_agents(), preflight_info['agent_id'])
    # Terminal add-ons often do not mount /backup. Download by documented API
    # to persistent /share instead of filling HAOS's RAM-backed /tmp.
    destination = Path('/share/hads4_installer_backups')
    destination.mkdir(parents=True, exist_ok=True)
    backup = destination / (slug+'.tar')
    if destination.is_symlink() or backup.is_symlink() or backup.exists():
        raise RuntimeError('Kolize nebo nepovolená cesta lokální zálohy.')
    request = urllib.request.Request('http://supervisor/backups/'+slug+'/download',
                                    headers={'Authorization': 'Bearer '+os.environ['SUPERVISOR_TOKEN']})
    with urllib.request.urlopen(request, timeout=120) as response, backup.open('xb') as stream:
        while chunk := response.read(1024*1024):
            if shutil.disk_usage(destination).free < 256*1024*1024:
                raise RuntimeError('Málo místa pro lokální stažení. Neúplná záloha ponechána; instalace zastavena.')
            stream.write(chunk)
    verify_source_in_backup(backup, preflight_info['source'])
    print('Nahrávám plnou zálohu přes OneDrive integraci HA. U velké zálohy může přenos trvat déle.')
    receipt = cloud_copy(backup, agent)
    receipt['addon_source'] = preflight_info['source']
    Path(staging, 'onedrive-receipt.json').write_text(json.dumps(receipt), encoding='utf-8')
    (destination/(slug+'-onedrive-receipt.json')).write_text(json.dumps(receipt), encoding='utf-8')
    # The original Supervisor backup stays in /backup. Remove only this
    # installer-created transfer copy to avoid recursive /share backup growth.
    backup.unlink()
    print('OneDrive: zpětné stažení ze vzdáleného úložiště a SHA-256 souhlasí. Záloha je ve správě záloh HA; starší zálohy nemažu. Test obnovy nebyl proveden.')


def catalog_update(version, existing):
    supervisor('/store/reload', {})
    catalog = supervisor('/store/addons/'+SLUG)
    if catalog.get('version_latest', catalog.get('version')) != version:
        raise RuntimeError('Supervisor katalog neuvádí očekávanou verzi. Neprovádím rebuild starého obrazu.')
    if existing:
        current = supervisor('/addons/'+SLUG+'/info')
        if current.get('version') == version:
            raise RuntimeError('Tato verze je už nainstalována; odmítám neversionovaný rebuild.')
    payload = {'background': False}
    if existing:
        # User explicitly requested no pre-install backup, including the
        # Supervisor's automatic add-on update backup. Runtime gates unchanged.
        payload['backup'] = False
    supervisor('/store/addons/'+SLUG+('/update' if existing else '/install'), payload)
    current = supervisor('/addons/'+SLUG+'/info')
    if current.get('version') != version:
        raise RuntimeError('Supervisor nepotvrdil novou verzi. Zdrojová záloha je zachována.')
    supervisor('/addons/'+SLUG+'/start', {})


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'access':
            supervisor('/supervisor/info')
        elif action == 'preflight':
            preflight(sys.argv[2])
        elif action == 'cloud':
            backup_to_cloud(sys.argv[2], sys.argv[3])
        elif action == 'update':
            catalog_update(sys.argv[2], sys.argv[3] == '1')
        else:
            raise ValueError('Neznámý instalační úkon.')
    except Exception as exc:
        # Avoid raw urllib/subprocess errors containing authorization or URLs.
        print('Instalace zastavena: '+ (str(exc) if isinstance(exc, (RuntimeError, ValueError)) else type(exc).__name__), file=sys.stderr)
        sys.exit(1)
