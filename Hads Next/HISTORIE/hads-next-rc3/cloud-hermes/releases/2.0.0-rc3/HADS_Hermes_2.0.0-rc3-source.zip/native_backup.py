"""Installer-only, bounded standard-library client for HA's native backup API.

Uses the terminal's Supervisor credentials, never Microsoft's OAuth token.
No paid requests, package installation, redirect following or write retries.
"""
import base64
import hashlib
import http.client
import json
import os
import socket
import struct
import time
from urllib.parse import quote, urlencode

LIMIT = 2 * 1024 * 1024
CHUNK = 1024 * 1024


def headers():
    token = os.environ.get('SUPERVISOR_TOKEN', '')
    if not token:
        raise RuntimeError('Terminál neposkytuje SUPERVISOR_TOKEN. Jeho hodnotu neposílejte do chatu.')
    return {'Authorization': 'Bearer ' + token}


def backup_agents():
    """One read-only WebSocket command, with bounded frames and deadline."""
    token = headers()['Authorization'][7:]
    deadline = time.monotonic() + 60
    with socket.create_connection(('supervisor', 80), timeout=30) as sock:
        def read_exact(size):
            result = bytearray()
            while len(result) < size:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('HA WebSocket timeout')
                sock.settimeout(min(30, remaining))
                block = sock.recv(size - len(result))
                if not block:
                    raise RuntimeError('HA uzavřel diagnostické spojení.')
                result.extend(block)
            return bytes(result)

        def send(payload, opcode=1):
            mask = os.urandom(4)
            size = len(payload)
            length = bytes([size | 128]) if size < 126 else bytes([254]) + struct.pack('!H', size)
            sock.sendall(bytes([128 | opcode]) + length + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(payload)))

        def receive():
            message = bytearray()
            started = False
            while True:
                first, second = read_exact(2)
                opcode, final = first & 15, bool(first & 128)
                if first & 112 or second & 128:
                    raise RuntimeError('Neplatný HA WebSocket rámec.')
                size = second & 127
                if size == 126:
                    size = struct.unpack('!H', read_exact(2))[0]
                elif size == 127:
                    size = struct.unpack('!Q', read_exact(8))[0]
                if size > LIMIT - len(message):
                    raise RuntimeError('Odpověď HA překročila bezpečný limit.')
                if opcode >= 8 and (not final or size > 125):
                    raise RuntimeError('Neplatný řídicí rámec HA.')
                data = read_exact(size)
                if opcode == 8:
                    raise RuntimeError('HA uzavřel diagnostické spojení.')
                if opcode == 9:
                    send(data, 10)
                    continue
                if opcode == 10:
                    continue
                if opcode != (0 if started else 1):
                    raise RuntimeError('Neočekávaná WebSocket zpráva HA.')
                started = True
                message.extend(data)
                if final:
                    return json.loads(message)

        key = base64.b64encode(os.urandom(16)).decode('ascii')
        sock.sendall(('GET /core/websocket HTTP/1.1\r\nHost: supervisor\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: ' + key + '\r\n\r\n').encode('ascii'))
        response = bytearray()
        while not response.endswith(b'\r\n\r\n'):
            if len(response) >= 16384:
                raise RuntimeError('Příliš dlouhá WebSocket hlavička.')
            response.extend(read_exact(1))
        lines = response.decode('latin-1').split('\r\n')
        fields = dict(line.lower().split(':', 1) for line in lines[1:] if ':' in line)
        expected = base64.b64encode(hashlib.sha1((key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).decode()
        # Header names are case-insensitive; the accept value is not.
        accept = next((line.split(':', 1)[1].strip() for line in lines[1:] if line.lower().startswith('sec-websocket-accept:')), '')
        if len(lines[0].split()) < 2 or lines[0].split()[1] != '101' or accept != expected or fields.get('upgrade', '').strip() != 'websocket':
            raise RuntimeError('HA odmítl WebSocket pro ověření OneDrive.')
        if receive().get('type') != 'auth_required':
            raise RuntimeError('Neočekávané ověření přístupu HA.')
        send(json.dumps({'type': 'auth', 'access_token': token}).encode())
        if receive().get('type') != 'auth_ok':
            raise RuntimeError('Terminál nemá potřebný přístup do HA API.')
        send(b'{"id":1,"type":"backup/agents/info"}')
        reply = receive()
        if reply.get('id') != 1 or reply.get('success') is not True:
            raise RuntimeError('HA neposkytl seznam zálohovacích úložišť; ověřte oprávnění terminálu.')
        return reply['result']['agents']


def select_agent(agents, requested=''):
    candidates = [a['agent_id'] for a in agents if isinstance(a, dict) and str(a.get('agent_id', '')).startswith('onedrive.')]
    if requested:
        candidates = [a for a in candidates if a == requested]
    if len(candidates) != 1:
        raise RuntimeError('Nenalezeno jediné aktivní OneDrive úložiště. Při více účtech zvolte HADS_ONEDRIVE_AGENT_ID; bez ověření instalace nepokračuje.')
    return candidates[0]


def stream_digest(stream):
    digest, size = hashlib.sha256(), 0
    while chunk := stream.read(CHUNK):
        digest.update(chunk)
        size += len(chunk)
    return digest.hexdigest(), size


def upload_backup(path, agent):
    boundary = 'hads-' + os.urandom(16).hex()
    prefix = ('--' + boundary + '\r\nContent-Disposition: form-data; name="file"; filename="backup.tar"\r\nContent-Type: application/x-tar\r\n\r\n').encode()
    suffix = ('\r\n--' + boundary + '--\r\n').encode()
    connection = http.client.HTTPConnection('supervisor', timeout=3600)
    try:
        connection.putrequest('POST', '/core/api/backup/upload?' + urlencode({'agent_id': agent}))
        for name, value in {**headers(), 'Content-Type': 'multipart/form-data; boundary=' + boundary,
                            'Content-Length': str(len(prefix) + path.stat().st_size + len(suffix))}.items():
            connection.putheader(name, value)
        connection.endheaders()
        connection.send(prefix)
        with path.open('rb') as stream:
            while chunk := stream.read(CHUNK):
                connection.send(chunk)
        connection.send(suffix)
        response = connection.getresponse()
        raw = response.read(LIMIT + 1)
        if response.status != 201 or len(raw) > LIMIT:
            raise RuntimeError('Nahrání přes nativní OneDrive selhalo (HTTP %s). Instalace zastavena.' % response.status)
        backup_id = json.loads(raw).get('backup_id')
        if not isinstance(backup_id, str) or not backup_id or len(backup_id) > 200:
            raise RuntimeError('HA nevrátil platné ID nahrané zálohy.')
        return backup_id
    finally:
        connection.close()


def readback_sha256(backup_id, agent):
    connection = http.client.HTTPConnection('supervisor', timeout=300)
    try:
        # Explicit cloud agent: never accept a local backup as remote evidence.
        connection.request('GET', '/core/api/backup/download/' + quote(backup_id, safe='') + '?' + urlencode({'agent_id': agent}), headers=headers())
        response = connection.getresponse()
        if response.status != 200:
            raise RuntimeError('Zpětné stažení právě z OneDrive selhalo (HTTP %s).' % response.status)
        return stream_digest(response)
    finally:
        connection.close()
