# HADS 4.7.0-rc5 — dostupnost incidentů a pravdivý stav vyšetřování

Podklad: Audit HADS 4.7.0 RC1, poslední analýza 16. 9., dodaný provozní log RC4 a živý audit 15. 9.

## Opraveno

- Dialog incidentu se otevře před síťovým požadavkem. Základ z přehledu je označen jako uložený, nikoli aktuálně ověřený. Detail má jeden pokus s timeoutem 10 sekund, viditelnou chybu a opakování. Neúplný detail nenabízí schválení. Pozdní odpověď po zavření dialog znovu neotevře.
- Přehled nečeká na zámek běžící síťové inicializace konektorů při čtení HAGHS cache. Chybějící cache vrací neznámé skóre, nikoli potvrzené zdraví.
- Start HTTP již nečeká na kompletní síťový refresh konektorů. Lokální priority a root-cases se obnoví před startem, síťový refresh zůstává následným úkolem.
- Selhání vyšetřování a uložená chyba se zobrazují přímo na kartě. Nečerstvý dokončený cyklus je explicitně označen. Stav aktuálního plánovače je oddělen od posledního dokončeného cyklu.
- Chronická četnost nepovýší neověřený SIGKILL bez OOM na P1. Potvrzený OOM se tím nepotlačuje. Nedoložená chyba cesty PulseAudio a přesně rozpoznané informační startovací hlášky nejsou kritické události.
- WebMCP přesunut pod technické rozhraní, není prezentován jako překážka diagnostiky.

## Ověřování

Offline Python testy, kompilace, kontrola JS a vykonávané testy UI v izolovaném DOM stubu: čekající požadavek, 502, opakování, závod se zavřením dialogu a štítek selhání. To není plný browser/Ingress test v HAOS.

## Co tato verze NEPROKAZUJE a neřeší

- Z logu bez chyb jednotlivých běhů nelze určit příčinu všech 25 selhání ani deset opakovaných startů. Historická 429 není důkaz současného vyčerpání limitu. Tento balík nemění API model, kredity ani schvalovací politiku.
- Není doložena původní příčina každé 502. Opravena je reprodukovatelná blokující cesta a způsob zobrazení chyby, nikoli zaručena dostupnost celé HA infrastruktury.
- Watchman, varianta HA-MCP, úplné využití Hamsteru, podezření na změny členství historických incidentů a společný kontext zařízení zůstávají otevřenými body auditu.
- Některé informační zprávy dostanou nižší prioritu, ale tato verze nezavádí kompletní oddělený archiv informačních událostí.
- Neproveden živý cyklus schválení → OneDrive readback → oprava → funkční ověření → návrat. Bez něj nejde o finální akceptaci. Existující zálohovací a schvalovací brány zůstávají zachovány.

Po nasazení nejprve ověřit otevření detailu v Ingressu a zachytit konkrétní chyby vyšetřování. Neschvalovat neurčité ani neověřené plány.
