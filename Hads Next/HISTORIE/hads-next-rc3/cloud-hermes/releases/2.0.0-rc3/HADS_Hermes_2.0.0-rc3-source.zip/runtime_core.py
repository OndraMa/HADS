"""Resource-aware runtime primitives. No HA writes and no model calls here."""
from __future__ import annotations
import collections
import datetime as dt
import json
import sqlite3
import threading
import time
from http.server import ThreadingHTTPServer
from contextlib import contextmanager
from pathlib import Path

MIB = 1024 * 1024


class ResourceDeferred(RuntimeError):
    pass


class ResponseTooLarge(ValueError):
    pass


class BoundedHTTPServer(ThreadingHTTPServer):
    """Bound request threads; slow clients cannot allocate an unlimited pool."""
    daemon_threads = True
    def __init__(self, *args, workers=6, **kwargs):
        self.slots = threading.BoundedSemaphore(workers)
        super().__init__(*args, **kwargs)

    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            try:
                request.settimeout(1)
                request.sendall(b'HTTP/1.0 503 Service Unavailable\r\nRetry-After: 5\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')
            except OSError:
                pass
            finally:
                self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self.slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()


def read_bounded(stream, limit=4 * MIB):
    """Never read an unbounded response; refuse partial JSON/log evidence."""
    value = stream.read(limit + 1)
    if len(value) > limit:
        raise ResponseTooLarge(f"Zdroj překročil limit {limit // 1024} KiB; data nejsou úplná a nebyla použita.")
    return value


def read_sse_response(stream, request_id, limit=2*MIB, timeout=30):
    """Stop at our JSON-RPC result, not at EOF of a persistent MCP stream."""
    used, data = 0, []
    deadline = time.monotonic()+timeout
    while used <= limit:
        if time.monotonic() >= deadline:
            raise TimeoutError('MCP stream včas nevrátil odpověď na tento požadavek.')
        line = stream.readline(limit-used+1)
        used += len(line)
        if used > limit:
            raise ResponseTooLarge('MCP stream překročil limit; neúplná odpověď nebyla použita.')
        if not line or not line.strip():
            if data:
                value = json.loads(b'\n'.join(data))
                if isinstance(value, dict) and value.get('id') == request_id and ('result' in value or 'error' in value):
                    return value
                data = []
            if not line:
                raise ValueError('MCP stream skončil bez odpovědi na tento požadavek.')
        elif line.startswith(b'data:'):
            data.append(line[5:].strip())


class ByteCache:
    """TTL/LRU serialized cache bounded by bytes, not just entry count."""
    def __init__(self, limit=8 * MIB, ttl=120):
        self.limit, self.ttl = limit, ttl
        self.items = collections.OrderedDict()
        self.size = 0

    def get(self, key, default=None):
        item = self.items.get(key)
        if not item:
            return default
        stamp, payload = item
        if time.monotonic() - stamp > self.ttl:
            self.size -= len(self.items.pop(key)[1])
            return default
        self.items.move_to_end(key)
        return json.loads(payload)

    def __setitem__(self, key, value):
        payload = json.dumps(value, ensure_ascii=False, default=str).encode()
        if key in self.items:
            self.size -= len(self.items.pop(key)[1])
        if len(payload) > self.limit // 2:
            return
        while self.items and self.size + len(payload) > self.limit:
            self.size -= len(self.items.popitem(last=False)[1][1])
        self.items[key] = time.monotonic(), payload
        self.size += len(payload)

    def clear(self):
        self.items.clear()
        self.size = 0


def memory_sample(proc=Path('/proc'), cgroup=Path('/sys/fs/cgroup')):
    def fields(path):
        values = {}
        try:
            for line in path.read_text().splitlines():
                parts = line.split()
                if len(parts) >= 2 and parts[1].isdigit():
                    values[parts[0].rstrip(':')] = int(parts[1]) * 1024
        except OSError:
            pass
        return values
    mem, own = fields(proc / 'meminfo'), fields(proc / 'self/status')
    available = mem.get('MemAvailable')
    try:
        maximum = (cgroup / 'memory.max').read_text().strip()
        current = int((cgroup / 'memory.current').read_text().strip())
        if maximum.isdigit():
            headroom = max(0, int(maximum) - current)
            available = min(available, headroom) if available is not None else headroom
    except (OSError, ValueError):
        pass
    return {'available_bytes': available, 'rss_bytes': own.get('VmRSS'),
            'swap_free_bytes': mem.get('SwapFree'), 'sampled_at': time.time()}


class Governor:
    """Single heavy diagnostic lane + durable backoff across OOM restarts.

    A running row at next process start is treated as interrupted, never success.
    This is admission control, NOT a guarantee against OS-level OOM.
    """
    def __init__(self, path, sample=memory_sample, reserve=192*MIB, rss_limit=192*MIB):
        self.path, self.sample = Path(path), sample
        self.reserve, self.rss_limit = reserve, rss_limit
        self.lock = threading.RLock()
        self.owner = None
        self.depth = 0
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as conn:
            conn.execute('CREATE TABLE IF NOT EXISTS jobs(name TEXT PRIMARY KEY,status TEXT,next_at REAL,failures INTEGER,detail TEXT,updated REAL)')
            conn.execute("UPDATE jobs SET status='interrupted',next_at=?,failures=failures+1,detail='Předchozí běh byl přerušen; automatický pokus odložen.',updated=? WHERE status='running'", (time.time()+900,time.time()))

    @contextmanager
    def db(self):
        conn = sqlite3.connect(self.path, timeout=2)
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def admit(self, name):
        with self.lock:
            if self.owner == threading.get_ident():
                self.depth += 1
                return
            if self.owner is not None:
                raise ResourceDeferred('Náročná diagnostika již běží; další práce byla odložena.')
            with self.db() as conn:
                row = conn.execute('SELECT next_at,detail,status FROM jobs WHERE name=?', (name,)).fetchone()
                if row and row[0] > time.time():
                    deadline = dt.datetime.fromtimestamp(row[0], dt.timezone.utc).isoformat(timespec='seconds')
                    reason = str(row[1] or ('Běžný interval po úspěšném běhu.' if row[2] == 'completed' else 'Předchozí pokus nebyl úspěšně dokončen.'))[:300]
                    raise ResourceDeferred(f'Úloha {name} čeká do {deadline} (zbývá {max(1, int(row[0]-time.time())+1)} s). Důvod: {reason}')
            mem = self.sample()
            if mem['available_bytes'] is None or mem['rss_bytes'] is None:
                self.defer(name, 'Nelze ověřit paměťovou rezervu. Náročná diagnostika je pozastavena.', 300)
                raise ResourceDeferred('Paměťová rezerva není ověřena.')
            if mem['available_bytes'] < self.reserve or mem['rss_bytes'] >= self.rss_limit:
                self.defer(name, 'Nedostatek paměťové rezervy; chráním provoz HA a odkládám diagnostiku.', 300)
                raise ResourceDeferred('Málo RAM nebo dosažen pracovní RSS limit HADS; diagnostika odložena.')
            with self.db() as conn:
                conn.execute("INSERT INTO jobs VALUES(?,'running',0,0,'',?) ON CONFLICT(name) DO UPDATE SET status='running',updated=excluded.updated", (name,time.time()))
            self.owner, self.depth, self.name = threading.get_ident(), 1, name

    def defer(self, name, detail, seconds):
        with self.db() as conn:
            conn.execute("INSERT INTO jobs VALUES(?,'deferred',?,0,?,?) ON CONFLICT(name) DO UPDATE SET status='deferred',next_at=excluded.next_at,detail=excluded.detail,updated=excluded.updated", (name,time.time()+seconds,detail,time.time()))

    def finish(self, success, detail=''):
        with self.lock:
            if self.owner != threading.get_ident():
                return
            self.depth -= 1
            if self.depth:
                return
            try:
                with self.db() as conn:
                    row = conn.execute('SELECT failures FROM jobs WHERE name=?',(self.name,)).fetchone()
                    failures = 0 if success else (row[0] if row else 0)+1
                    delay = (0 if self.name == 'panel_snapshot' else 60) if success else min(3600, 60 * 2**min(failures,6))
                    conn.execute('UPDATE jobs SET status=?,next_at=?,failures=?,detail=?,updated=? WHERE name=?', ('completed' if success else 'failed',time.time()+delay,failures,str(detail)[:300],time.time(),self.name))
            finally:
                self.owner = None

    def status(self):
        with self.db() as conn:
            conn.row_factory = sqlite3.Row
            jobs = [dict(row) for row in conn.execute('SELECT * FROM jobs ORDER BY updated DESC LIMIT 20')]
        for job in jobs:
            job['cooldown_active'] = job['next_at'] > time.time()
        return {'memory': self.sample(), 'jobs': jobs, 'reserve_bytes': self.reserve, 'rss_admission_limit': self.rss_limit}


class Snapshot:
    """HTTP reads a completed immutable JSON snapshot, never triggers analysis."""
    def __init__(self, limit=2*MIB):
        self.payload = None
        self.created = None
        self.error = ''
        self.lock = threading.Lock()
        self.limit = limit

    def publish(self, value):
        payload = bytearray()
        encoder = json.JSONEncoder(ensure_ascii=False, default=str, separators=(',', ':'))
        for chunk in encoder.iterencode(value):
            data = chunk.encode('utf-8')
            if len(payload) + len(data) > self.limit:
                message = f'Data panelu překročila limit {self.limit} bajtů; nejde o měření volné RAM.'
                self.fail(message)
                raise ResponseTooLarge(message)
            payload.extend(data)
        with self.lock:
            self.payload, self.created, self.error = bytes(payload), time.time(), ''

    def fail(self, message):
        with self.lock:
            self.error = str(message)[:500]

    def get(self):
        with self.lock:
            return self.payload, self.created, self.error
