# HADS 5.0.0-rc5 — databázové blokování a dohledatelný test sběru

3. 10. 2026. Opravné vydání navazující na RC4 a její živý audit. Původní vydání zůstávají zachována.

## Opravy

- Čtecí dotazy dashboardu a jeho health přehledu používají WAL snapshot místo zbytečného čekání ve frontě zápisů.
- Ověření zotavení entity nedrží databázový zápisový zámek během síťového požadavku. Před uložením výsledku znovu kontroluje aktuální stav a čas zotavení, aby nepřepsalo novější pozorování.
- Úspěšné publikování dashboard senzorů již není označeno jako neúspěšné jen proto, že zápis pomocného času narazil na obsazenou databázi. Odložené uložení času se samostatně zaznamená.
- Test sběru ukládá poslední výsledek atomicky do samostatného JSON souboru mimo SQLite: ID, stav, fázi, zdroj, časy a konkrétní selhání. Při restartu označí nedokončený test jako přerušený, nikoli úspěšný. Pokud selže samotné ukládání, chybu neskrývá.
- Diagnostické zdroje zobrazují výsledek trvale, nejen v krátkém oznámení, a nabízejí stažení diagnostiky JSON. Chybové zprávy jsou escapované; export neobsahuje surové logy ani konfiguraci přístupových údajů. URL v chybách jsou maskované.
- Diagnostika databáze obsahuje čas obsazení zápisové fronty a vlastníka posledního timeoutu pro další vyšetřování.

## Bezpečnost a omezení

Placené AI ani web se tímto upgradem automaticky nezapínají. Uložené volby však zůstávají zachované; chcete-li zabránit placeným voláním, vypněte je před instalací v nastavení. Schválení konkrétní opravy a ověřená záloha zůstávají povinné. Instalátor na dřívější výslovný požadavek nevytváří novou předinstalační HA/OneDrive zálohu; místní kopie zdrojů není systémová záloha.

Potvrzené databázové slabiny jsou opravené. Konkrétní příčinu dvou neúspěšných hlubokých testů na RC4 nelze z dodaného logu určit: nebyla zaznamenána. Toto vydání proto zajišťuje její dohledatelnost. Nejde o potvrzení univerzálního autonomního opraváře, kompletního využití všech konektorů ani živě ověřeného backup/repair/restore toku.

## Ověření

Autoritativní offline výsledek je `HADS4_5.0.0-rc5-verification.json`: regresní testy, kompilace Pythonu, JavaScript scénáře, YAML, integrita instalačního payloadu a zdrojového ZIP a dostupná kontrola Bash syntaxe. Nové testy pokrývají souběžný zápis/čtení, síťové ověření bez držení zámku, restart, selhání ukládání, odložení sběru, chyby zdrojů a zobrazení/export výsledku.

Nová RC5 není tímto chatem nasazena na HAOS. Po instalaci: Diagnostické zdroje → Otestovat sběr protokolů → Stáhnout diagnostiku JSON. Postup a nastavení MCP zůstávají v `MANUAL_5.0.0-rc5_CS.md` a `HA_MCP_NASTAVENI_CS.md`.
