# HADS Hermes 2.0.0-rc1 — instalace a nastavení

**Pro tvůj Raspberry Pi 4B:** před nasazením potvrdit RAM a 64bitový HAOS
(`aarch64`). Každý Hermes krok potřebuje 768 MiB ověřené paměťové rezervy;
při nedostatku se odloží bez placeného požadavku. Nutné je jádro povolující
Landlock ABI 4 (Linux 6.7+ a příslušná konfigurace). Obraz používá Python 3.14
podle aktuálního upstreamu a opravené SQLite 3.53.4 s ověřeným SHA256.

Nová větev používá skutečný Hermes Agent v0.22.2 jako omezeného analytika.
Přebírá sběr, UI, incidenty, chat, přesné opravné plány a bezpečnostní brány
z HADS 5.1.0-rc3. Není to Hermes model ani univerzální neomezený shell agent.

## Stav vydání a kompatibilita

Jde o kandidáta RC1, nikoli o potvrzeně funkční produkční nasazení na tvém HAOS.
Zatím jej nedoporučuji nasadit do ostrého systému bez předchozího sestavení
a smoke testu Linux obrazu. Instalátor před nahrazením zdrojů ověří 64bitové
prostředí a dostupnost Landlock; samotný test v terminálu nepotvrzuje
oprávnění budoucího kontejneru ani všechny závislosti.
Zdrojový strom a instalátor jsou připravené. Lokální testy používají falešný
model bez placeného API. Skutečný Hermes se při sestavování Docker obrazu musí
otestovat vestavěným smoke testem; pokud neprojde, obraz se nesestaví.
Živé HAOS, OneDrive readback a skutečná oprava vyžadují přejímku po instalaci.

Podporované cíle jsou amd64 a aarch64. armv7 se v této větvi nenabízí.
Nový Debian/Python obraz je větší než předchozí Alpine. Před instalací ověř
volné úložiště a paměť; doporučuji alespoň 4 GB RAM celkem, ideálně více.
Nejde o ověřené minimum Hermes ani záruku, že zbývá dost RAM pro tvé doplňky.

Ponechává slug `local_hads4`, databázi `/data/hads4.db` a stávající nastavení.
Verze 2.0 znamená novou větev Hermes, nikoli návrat ke starému HADS 2.
Nemaže incidenty, schválení ani historii. Nespouštěj starou i novou větev
současně nad jednou databází. Tato RC nepřidává automatické libovolné SQL,
úpravy registrů ani terminál; existující podporované opravné akce zůstávají.

## Instalace

Přenést `HADS_Hermes_install_2.0.0-rc1.sh` do `/config`. V terminálu HA:

```sh
bash /config/HADS_Hermes_install_2.0.0-rc1.sh
```

Ne `python3`: jde o shellový instalátor. Na dřívější výslovnou žádost
instalátor nevytváří novou plnou předinstalační HA/OneDrive zálohu. To
neodstraňuje povinnou zálohu před opravami. Pokud nyní chceš předinstalační
zálohu, vytvoř ji v HA před spuštěním. Nový obraz se sestavuje lokálně;
první sestavení potřebuje internet a může trvat výrazně déle.

## Co nastavit v HADS

1. `Použít analytického agenta Hermes`: zapnuto.
2. Stávající `openai_enabled`, `openai_api_key`, `openai_model` zůstávají
   z důvodu kompatibility. Nepřepisuji tvůj model ani nečtu klíč do balíčku.
   Nová větev zatím podporuje poskytovatele přes stávající OpenAI Responses
   bránu; jiné Hermes poskytovatele či předplatné do ní automaticky nezapojuje.
3. Samostatně povolit `ai_paid_calls_enabled`. Samotný uložený klíč nestačí.
   Pro automatické vyšetřování také `ai_background_research: true`.
   Zachovává se periodické vyšetřování a watchdog; neznámé technické případy
   nejsou důvodem k neomezeným placeným dotazům.
4. Doporučený začátek: 6 modelových požadavků/24 h, 2 na případ, nejvýše
   3 kroky. Každý krok může být placený, i když nedokončí analýzu. Limity
   přežijí restart, nejde však o dolarovou záruku. Po dosažení limitu pokračuje
   místní diagnostika. Interní modelové retry v kroku broker nepustí.
5. Web vyžaduje samostatně `ai_paid_web_enabled` a `openai_web_search_enabled`.
   Platí domény z nastavení a nejvýše jedno webové volání na požadavek.
6. Ověřená nativní OneDrive záloha a rescue readback zůstávají povinné před
   opravou. Pouhé potvrzení uploadu bránu neodemkne.

Hermes běží bez přímých nástrojů, bez Supervisor/API klíčů a bez přímého
síťového spojení k HA. Agent si vyžádá pojmenované čtení a provede ho HADS.
Dočasný proces není VM. Povinné Landlock omezení zakazuje přístup ke konfiguraci
HA, přístupovým klíčům a zálohám; dovoluje zápis jen do vlastního dočasného
adresáře a zakazuje spouštění programů. TCP je omezen na port brokeru,
doplňková Python pojistka na loopback adresu. Bez izolace se worker nespustí.
Nejde o obranu proti chybě jádra. Nevkládá se do
něj nedůvěryhodný Python, shell, uživatelské pluginy ani automatické skills.
Paměť pochází z dohledatelné historie HADS, nikoli z automaticky spuštěného
staženého kódu.

## Doplňky

Není nutné instalovat další komunitní Hermes doplněk: runtime je uvnitř
tohoto obrazu. HA-MCP a Hamster zůstávají čtecí zdroje HADS. V HA-MCP buď
vypni globální Tool Search, nebo připni `ha_search`, `ha_get_state`,
`ha_get_entity`, `ha_get_history`, `ha_get_automation_traces`,
`ha_get_system_health`; ponech read-only. Povolení skrytého nástroje není
totéž jako jeho zveřejnění v katalogu. V HADS použij ověření všech spojení.

Spook přes Repairs, Watchman přes dostupný TXT report/stavy, HADocs,
Automation Inspector, Entity Availability a HAGHS používají zachované
adaptéry a jejich skutečně dostupná rozhraní. Hermes nevytvoří API, které
daná verze doplňku nemá. Instalace doplňku se nevydává za potvrzené zdraví.

## Přejímka po instalaci

1. Doplněk běží, panel ukazuje Hermes 2.0.0-rc1 a lze otevřít incident.
2. Stav Hermes rozlišuje vypnuté placení, nečinnost, běh, dokončení a chybu.
3. U jedné selhané automatizace ověř čas, trace, správnou entitu a skutečný
   stav. Analýza musí uvést neznámé údaje, pokud se nedají načíst.
4. Zkontroluj počítadlo skutečných API požadavků. Pouhý test spojení s MCP
   nemá spotřebovávat modelové požadavky.
5. Přesná scalar oprava automatizace se nejprve zobrazí jako náhled. Přijetí
   závěru není schválení opravy. Tlačítko spuštění odemkne jen skutečný plán.
6. Bez ověřené cloudové zálohy se nesmí provést změna. První skutečnou opravu
   provést jen na zvoleném konkrétním plánu a potom ověřit funkční výsledek.
7. Při chybě uložit běh a důvod, nikoli opakovat zápis nebo tvrdit vyřešeno.

Po selhání pracovního procesu se další pokus odloží o 5 minut; UI a incident
ukážou fázi chyby. Tato krátká runtime prodleva není dolarový limit a není
perzistentní přes restart; placené limity a účtenky v HADS jsou perzistentní.

Nejsou slíbeny opravy všech možných scénářů. Chybějící automatický vykonavatel
se musí zobrazit jako omezení nebo ruční postup, ne falešný úspěch.
