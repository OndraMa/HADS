# HADS 4.7.0-rc4 — návaznost AI vyšetřování

Datum: 14. září 2026. Navazuje na rc3; není potvrzením celé funkčnosti v HAOS.

## Změny

- Každá OpenAI analýza dostává poslední tři uložené analýzy a tři opravné plány stejného zdrojového případu, včetně chyb a výsledků. Záznamy se znovu čtou z SQLite i po restartu. Historická data nejsou současným stavem ani souhlasem.
- Texty jsou omezené, běžná pojmenovaná tajemství redigovaná a zkrácená pole označená. Nejde o kompletní archiv v promptu ani o automatické obnovení přerušeného API požadavku.
- Nastavení `openai_reasoning_effort`: auto/low/medium/high/xhigh/max. Výchozí auto neposílá nový parametr a zachovává chování stávajícího modelu. Konkrétní kombinaci musí podporovat zvolený model/API účet. Neprovádí se automatický přechod na dražší model ani opakování odmítnutého požadavku s jiným modelem.
- Stávající oprávnění, schvalování a povinná záloha se nemění.

## Vyhodnocení Daily Tech News (10.–14. září)

Relevantní je zejména Agents API ze zprávy 12. září. Oficiální dokumentace potvrzuje spravované relace, práci s kontextem, obnovu a připojení nástrojů. Pro HADS je to vhodný kandidát další architektury, ne pouhá výměna URL Responses API. Zdroje:

- https://developers.openai.com/api/docs/guides/agents-api/overview
- https://developers.openai.com/api/docs/guides/agents-api/sessions
- https://developers.openai.com/api/docs/guides/agents-api/quickstart

**Agents API v rc4 není implementováno ani zapnuto.** HADS zůstává na Responses API s lokálním řízením čtecích nástrojů. Přínos návaznosti vyšetřování nyní zavádíme do existujícího systému. Migrace vyžaduje ověřit uchovávání cloudových relací, oprávnění API účtu, most k lokálním nástrojům, idempotenci událostí, limity nákladů a nemožnost obejít místní schválení i backup gate. HA token nesmí být předán agentovi s obecným shellem. Přímý přístup cloudového agenta do domácí sítě se tímto vydáním nezřizuje.

GPT-6 Astra je v oficiálním katalogu dostupné přes Responses API, podporuje funkce, strukturovaný výstup, web a effort low až max. Lze ho ručně zvolit jako `gpt-6-astra`; stávající model ponecháváme. Podpora schématu v offline testu neprokazuje dostupnost na konkrétním účtu ani kvalitu diagnózy.

- https://developers.openai.com/api/docs/models/gpt-6-astra

Při ceně uvedené v katalogu $10/M vstupních a $50/M výstupních tokenů je příklad 10 000 vstupních + 2 000 výstupních tokenů $0.20 bez dalších nástrojů; vícekolová analýza může stát více. Nejde o změřený průměr incidentu. GPT-Live hlas a computer-use řízení HA nejsou součástí rc4: neřeší nynější nedostatky diagnostiky a vyžadují další ověření bezpečnosti.

## Ověření a hranice

Nové regresní testy pokrývají předání historie do skutečné funkce research_case s náhradním API transportem, izolaci případu, persistenci, redakci, omezení textu a nastavení effort. Build spouští také celou zděděnou testovací sadu, Python kompilaci a JS kontroly. Přesný výsledek je ve verification.json vedle instalačního balíku.

Nebyl proveden placený API test, instalace do HAOS, UI test ani skutečná obnova OneDrive zálohy. Nevyřešené širší hranice rc3 (úplná cloudová záloha/rotace a obecné pozitivní funkční ověření oprav) zůstávají. Po aktualizaci ověřte na jednom existujícím případu nové vyšetřování, jeho spotřebu a návaznost na minulý výsledek. Nejde o automatické nasazení do HAOS.
