"""Offline MCP contracts; fake endpoints only, no model calls or HA writes."""
import json
import threading
import time
import unittest
from unittest import mock

import mcp_diagnostics as policy
from tool_adapters import ToolAdapterBus
import hads4
import test_rc8_regressions as legacy


def tool(name, props=None, required=None):
    return {'name': name, 'inputSchema': {'type': 'object', 'properties': props or {}, 'required': required or []}}


def bus_with(catalog, handler=None):
    bus = ToolAdapterBus.__new__(ToolAdapterBus)
    bus.options = lambda: {}
    bus.now = lambda: '2026-09-27T10:00:00+00:00'
    bus._mcp_sessions = {}
    bus._mcp_versions = {}
    bus._mcp_context = threading.local()
    bus._auto_mcp_urls = lambda cfg: {'ha_mcp': 'http://example.invalid', 'hamster_mcp': 'http://example.invalid'}
    bus._mcp_probe = lambda *args: {'catalog': {'tools': catalog}, 'tool_count': len(catalog)}
    bus._mcp_rpc = handler or (lambda *args, **kwargs: {'result': []})
    return bus


class McpPolicyTests(unittest.TestCase):
    def test_remote_partial_response_never_claims_complete(self):
        value = {'content': [{'type': 'text', 'text': '{"success":true,"has_more":true,"results":[]}'}]}
        self.assertTrue(policy.result_partial(value))
        result = policy.evidence_summary([{'tool': 'ha_get_history', 'result': value, 'partial': True}], [])
        self.assertEqual('partial', result['state'])

    def test_remote_readonly_hint_never_authorizes_unknown_tool(self):
        catalog = {'tools': [dict(tool('get_and_delete_everything'), annotations={'readOnlyHint': True}), tool('ha_call_service'), tool('ha_get_state')]}
        self.assertEqual(['ha_get_state'], [x['name'] for x in policy.readable_tools(catalog)])

    def test_explicit_non_readonly_denies_even_known_name(self):
        self.assertEqual([], policy.readable_tools({'tools': [dict(tool('ha_get_state'), annotations={'readOnlyHint': False})]}))

    def test_metadata_is_not_diagnostic_data(self):
        for name in policy.METADATA:
            self.assertFalse(policy.observation({'tool': name, 'result': {'ok': True}}))
        self.assertFalse(policy.observation({'tool': 'call', 'result': {}}))
        self.assertTrue(policy.observation({'tool': 'ha_get_state', 'result': {'states': []}}))

    def test_protocol_success_with_tool_error_is_failure(self):
        for result in ({'isError': True}, {'success': False}, {'content': [{'type': 'text', 'text': '{"success": false, "error": "not found"}'}]}, None):
            self.assertFalse(policy.observation({'tool': 'ha_get_state', 'result': result}))

    def test_known_entity_binds_union_schema_without_guessing(self):
        schema = tool('ha_get_history', {'entity_ids': {'anyOf': [{'type': 'string'}, {'type': 'array', 'items': {'type': 'string'}}]}}, ['entity_ids'])
        args, error = policy.bind(schema, {'entity_ids': ['light.bedroom'], 'secret_unknown': 'omit'})
        self.assertEqual({'entity_ids': ['light.bedroom']}, args)
        self.assertFalse(error)

    def test_missing_required_parameter_never_fabricated(self):
        args, error = policy.bind(tool('ha_get_entity', {'device_id': {'type': 'string'}}, ['device_id']), {'query': 'light.test'})
        self.assertIsNone(args)
        self.assertIn('device_id', error)

    def test_unsupported_schema_does_not_execute(self):
        args, _ = policy.bind({'inputSchema': {'type': 'object', '$ref': 'external'}}, {})
        self.assertIsNone(args)

    def test_history_uses_incident_time_not_today(self):
        rows = policy.recipes('automation.lights_off light.bedroom custom_components.logger', {'last_seen': '2026-09-25T20:00:00+02:00'})
        values = next(values for name, values, purpose in rows if name == 'ha_get_history')
        self.assertEqual('2026-09-25T19:00:00+02:00', values['start_time'])
        self.assertEqual('2026-09-25T20:15:00+02:00', values['end_time'])
        self.assertNotIn('custom_components.logger', values['entity_ids'])
        self.assertEqual('automation.lights_off', next(v for n, v, p in rows if n == 'ha_get_automation_traces')['automation_id'])

    def test_timezone_missing_explicitly_uses_bounded_recent_window(self):
        rows = policy.recipes('light.bedroom', {'last_seen': '2026-09-25T20:00:00'})
        _, args, purpose = next(row for row in rows if row[0] == 'ha_get_history')
        self.assertEqual('24h', args['start_time'])
        self.assertIn('není doložen', purpose)

    def test_live_catalog_and_schema_target_known_entity(self):
        calls = []
        def rpc(adapter, url, method, params, **kwargs):
            calls.append(params)
            return {'state': 'on'}
        bus = bus_with([tool('ha_get_state', {'entity_id': {'type': 'string'}}, ['entity_id']), tool('ha_call_service')], rpc)
        result = bus._mcp_case_evidence('ha_mcp', 'light.bedroom failed')
        self.assertEqual([{'name': 'ha_get_state', 'arguments': {'entity_id': 'light.bedroom'}}], calls)
        self.assertEqual(1, result['coverage']['successful_reads'])
        self.assertEqual('partial', result['coverage']['state'])
        self.assertIsNone(bus._mcp_context.deadline)

    def test_large_result_is_marked_incomplete_not_success(self):
        bus = bus_with([tool('ha_get_state')], lambda *a, **k: {'state': 'x' * 60000})
        result = bus._mcp_case_evidence('ha_mcp', 'light.bedroom')
        self.assertEqual(0, result['coverage']['successful_reads'])
        self.assertEqual(1, result['coverage']['truncated_results'])
        self.assertLess(len(json.dumps(result)), 9000)

    def test_hamster_failed_schema_never_dispatches(self):
        calls = []
        def rpc(a, u, m, params, **k):
            calls.append(params['name'])
            return {'matches': [{'path': 'hass/get_states'}]} if params['name'] == 'search' else {'isError': True}
        props = {'path': {'type': 'string'}}
        bus = bus_with([tool('search', {'query': {'type': 'string'}}, ['query']), tool('schema', props, ['path']), tool('call')], rpc)
        result = bus._mcp_case_evidence('hamster_mcp', 'light.bedroom')
        self.assertNotIn('call', calls)
        self.assertEqual(0, result['coverage']['successful_reads'])

    def test_hamster_write_path_is_never_dispatched(self):
        calls = []
        def rpc(a, u, m, params, **k):
            calls.append(params['name'])
            return {'matches': [{'path': 'hass/call_service'}, {'path': 'supervisor/core/restart'}]}
        bus = bus_with([tool('search', {'query': {'type': 'string'}}, ['query']), tool('call')], rpc)
        bus._mcp_case_evidence('hamster_mcp', 'repair failed')
        self.assertEqual(['search'], calls)

    def test_catalog_pagination_deduplicates_and_marks_complete(self):
        bus = bus_with([])
        def rpc(a, u, method, params, **kwargs):
            if method == 'initialize': return {'protocolVersion': '2025-11-25'}
            if method == 'notifications/initialized': return None
            return {'tools': [tool('ha_get_state'), tool('ha_get_history')]} if params.get('cursor') else {'tools': [tool('ha_get_state')], 'nextCursor': 'page2'}
        bus._mcp_rpc = rpc
        result = bus._mcp_initialize('ha_mcp', 'http://example.invalid')
        self.assertTrue(result['complete'])
        self.assertEqual(2, result['pages'])
        self.assertEqual(2, len(result['tools']))

    def test_catalog_cursor_cycle_fails_closed(self):
        bus = bus_with([])
        bus._mcp_rpc = lambda a, u, m, p, **k: {'tools': [], 'nextCursor': 'same'} if m == 'tools/list' else {}
        with self.assertRaisesRegex(ValueError, 'kurzor'):
            bus._mcp_initialize('ha_mcp', 'http://example.invalid')

    def test_catalog_page_budget_reports_incomplete(self):
        bus = bus_with([])
        index = [0]
        def rpc(a, u, m, p, **k):
            index[0] += 1
            return {'tools': [tool('ha_get_state')], 'nextCursor': str(index[0])} if m == 'tools/list' else {}
        bus._mcp_rpc = rpc
        result = bus._mcp_initialize('ha_mcp', 'http://example.invalid')
        self.assertFalse(result['complete'])
        self.assertEqual(4, result['pages'])

    def test_ha_mcp_cannot_ignore_initialize_failure(self):
        bus = bus_with([])
        bus._mcp_rpc = mock.Mock(side_effect=RuntimeError('-32601 method not found'))
        with self.assertRaises(RuntimeError):
            bus._mcp_initialize('ha_mcp', 'http://example.invalid')

    def test_unique_request_ids_even_with_same_second(self):
        bus = bus_with([])
        ids = []
        def http(url, **kwargs):
            ids.append(kwargs['payload']['id'])
            return {'id': ids[-1], 'result': {}}, {}
        bus._http_json = http
        for i in range(2):
            ToolAdapterBus._mcp_rpc(bus, 'ha_mcp', 'http://example.invalid', 'tools/list')
        self.assertNotEqual(ids[0], ids[1])

    def test_wrong_response_id_is_rejected(self):
        bus = bus_with([])
        bus._http_json = lambda *a, **k: ({'id': 'wrong', 'result': {}}, {})
        with self.assertRaises(ValueError):
            ToolAdapterBus._mcp_rpc(bus, 'ha_mcp', 'http://example.invalid', 'tools/list')

    def test_missing_response_id_is_rejected(self):
        bus = bus_with([])
        bus._http_json = lambda *a, **k: ({'result': {}}, {})
        with self.assertRaises(ValueError):
            ToolAdapterBus._mcp_rpc(bus, 'ha_mcp', 'http://example.invalid', 'tools/list')

    def test_empty_dispatch_arguments_must_meet_schema(self):
        args, error = policy.bind(tool('call', {'path': {'type': 'string'}, 'arguments': {'type': 'object'}}, ['path', 'arguments']), {'path': 'hass/get_states', 'arguments': {}})
        self.assertEqual({'path': 'hass/get_states', 'arguments': {}}, args)
        self.assertFalse(error)
        args, error = policy.bind(tool('call', {'arguments': {'type': 'object', 'required': ['unexpected']}}, ['arguments']), {'arguments': {}})
        self.assertIsNone(args)

    def test_deadline_prevents_another_network_call(self):
        bus = bus_with([])
        bus._mcp_context.deadline = time.monotonic() - 1
        bus._http_json = mock.Mock()
        with self.assertRaises(TimeoutError):
            ToolAdapterBus._mcp_rpc(bus, 'ha_mcp', 'http://example.invalid', 'tools/list')
        bus._http_json.assert_not_called()

    def test_connector_failure_restores_deadline(self):
        bus = bus_with([])
        bus._mcp_context.deadline = 123
        bus._mcp_probe = mock.Mock(side_effect=TimeoutError('offline'))
        with self.assertRaises(TimeoutError):
            bus._mcp_case_evidence('ha_mcp', 'light.bedroom')
        self.assertEqual(123, bus._mcp_context.deadline)


class McpPersistenceTests(unittest.TestCase):
    setUp = legacy.RC8RegressionTests.setUp
    tearDown = legacy.RC8RegressionTests.tearDown
    _case_and_plan = legacy.RC8RegressionTests._case_and_plan

    def test_metadata_only_does_not_replace_last_data_timestamp(self):
        case, _, root = self._case_and_plan()
        bus = ToolAdapterBus(hads4.db, hads4.now_utc, None, None, None)
        with hads4.db() as conn:
            conn.execute("INSERT INTO tool_adapters(adapter_id,title,discovery_json,updated_at) VALUES(?,?,?,?)", ('hamster_mcp', 'Hamster', json.dumps({'last_used_at': 'old-data-time'}), hads4.now_utc()))
        outputs = [{'tool': 'search', 'result': {'matches': [{'path': 'hass/get_states'}]}}]
        with mock.patch.object(bus, 'refresh'), mock.patch.object(bus, 'global_findings', return_value=[]), mock.patch.object(bus, 'status', return_value=[{'adapter_id':'hamster_mcp','active':False,'discovery':{'connector_ready':True}}]), mock.patch.object(bus, '_mcp_case_evidence', return_value={'outputs':outputs,'coverage':policy.evidence_summary(outputs, [])}):
            result = bus.collect({'id': case}, root)
        self.assertNotIn('hamster_mcp', result['used'])
        with hads4.db() as conn:
            row = conn.execute("SELECT * FROM tool_adapters WHERE adapter_id='hamster_mcp'").fetchone()
        discovery = json.loads(row['discovery_json'])
        self.assertEqual('old-data-time', discovery['last_used_at'])
        self.assertEqual('no_diagnostic_data', discovery['mcp_last_research']['state'])
        self.assertEqual(0, row['active'])
