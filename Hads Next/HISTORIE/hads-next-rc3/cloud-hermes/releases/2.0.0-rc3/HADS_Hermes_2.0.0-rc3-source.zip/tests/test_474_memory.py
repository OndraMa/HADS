import json
import unittest
from unittest import mock

import hads4
import incident_workflow as workflow
import test_rc8_regressions as legacy


class MemoryTests(unittest.TestCase):
    setUp = legacy.RC8RegressionTests.setUp
    tearDown = legacy.RC8RegressionTests.tearDown
    _case_and_plan = legacy.RC8RegressionTests._case_and_plan

    def seed(self):
        case, plan, root = self._case_and_plan()
        with hads4.db() as conn:
            for i in range(5):
                conn.execute("INSERT INTO research_runs(case_id,provider,query,status,response_text,created_at) VALUES(?,?,?,?,?,?)",
                             (case, "test", str(i), "completed", "password=secret-value " + "x" * 3000, hads4.now_utc()))
            conn.execute("UPDATE repair_plans SET status='failed',last_error='Ověření neprošlo' WHERE id=?", (plan,))
        return case, plan

    def memory(self, case):
        return workflow.research_memory(hads4.db, case, lambda s: hads4.redact(s, True))

    def test_bounds_order_and_redaction(self):
        case, _ = self.seed()
        result = self.memory(case)
        self.assertEqual(['2', '3', '4'], [r['query'] for r in result['previous_analyses']])
        self.assertNotIn('secret-value', json.dumps(result))
        self.assertIn('response_text', result['previous_analyses'][0]['truncated_fields'])
        self.assertLess(len(json.dumps(result).encode()), 12000)

    def test_failed_receipt_retained_without_approval(self):
        case, plan = self.seed()
        result = self.memory(case)
        self.assertEqual('failed', result['previous_plans'][0]['status'])
        self.assertEqual('Ověření neprošlo', result['previous_plans'][0]['last_error'])
        with hads4.db() as conn:
            self.assertEqual('failed', conn.execute('SELECT status FROM repair_plans WHERE id=?', (plan,)).fetchone()[0])

    def test_other_case_never_leaks(self):
        case, _ = self.seed()
        result = self.memory(case + 999)
        self.assertEqual([], result['previous_analyses'])
        self.assertEqual([], result['previous_plans'])

    def test_memory_survives_reinitialization(self):
        case, _ = self.seed()
        before = self.memory(case)
        hads4.init_db()
        self.assertEqual(before, self.memory(case))

    def test_request_receives_memory_and_opt_in_effort(self):
        case, _ = self.seed()
        cfg = {'hermes_enabled': False, 'ai_paid_calls_enabled': True, 'openai_enabled': True, 'openai_api_key': 'test-only', 'openai_model': 'gpt-6-astra',
               'openai_reasoning_effort': 'high', 'ai_call_limits_enabled': False, 'openai_web_search_enabled': False}
        output = {'summary': 'Potřebujeme nové důkazy', 'functional_impact': 'Neznámý', 'hypotheses': [],
                  'missing_evidence': ['trace'], 'next_test': 'Načíst trace', 'proposed_actions': [],
                  'configuration_changes': [], 'decision_kind': 'investigate'}
        def send(key, body):
            self.assertEqual({'effort': 'high'}, body['reasoning'])
            self.assertEqual('gpt-6-astra', body['model'])
            self.assertFalse(body['store'])
            self.assertNotIn('historical_memory_untrusted', json.dumps(body['input'][0]))
            prompt = body['input'][1]['content']
            self.assertIn('historical_memory_untrusted', prompt)
            self.assertIn('Ověření neprošlo', prompt)
            self.assertNotIn('secret-value', prompt)
            return {'status': 'completed', 'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': json.dumps(output)}]}]}
        with mock.patch.object(hads4, 'options', return_value=cfg), mock.patch.object(hads4, '_openai_post', side_effect=send) as api:
            self.assertEqual('completed', hads4.research_case(case, {})['status'])
        self.assertEqual(1, api.call_count)


class EffortTests(unittest.TestCase):
    def test_default_unchanged(self):
        self.assertEqual({}, workflow.reasoning_options({}))
        self.assertEqual({}, workflow.reasoning_options({'openai_reasoning_effort': 'auto'}))

    def test_explicit_efforts(self):
        for effort in ['low', 'medium', 'high', 'xhigh', 'max']:
            self.assertEqual({'reasoning': {'effort': effort}}, workflow.reasoning_options({'openai_reasoning_effort': effort}))

    def test_invalid_effort_rejected(self):
        for value in ['none', 'ultra', 'HIGH', 'arbitrary']:
            with self.assertRaises(ValueError):
                workflow.reasoning_options({'openai_reasoning_effort': value})
