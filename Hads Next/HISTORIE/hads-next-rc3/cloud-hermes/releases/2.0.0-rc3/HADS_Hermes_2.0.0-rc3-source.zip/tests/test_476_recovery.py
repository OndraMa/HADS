import datetime as dt
import ast
from pathlib import Path
import json
import threading
import unittest
from unittest import mock

import ai_provider
import hads4
import incident_workflow
from tool_adapters import ToolAdapterBus, _sanitize, _safe_error
from first_officer import FirstOfficer
import test_rc8_regressions as legacy


class Contracts(unittest.TestCase):
    def test_docker_includes_every_local_python_dependency(self):
        source = Path(hads4.__file__).parent
        docker = (source / 'Dockerfile').read_text()
        for module in source.glob('*.py'):
            for item in ast.walk(ast.parse(module.read_text(encoding='utf-8'))):
                names = [alias.name.split('.')[0] for alias in item.names] if isinstance(item, ast.Import) else [item.module.split('.')[0]] if isinstance(item, ast.ImportFrom) and item.module else []
                for name in names:
                    if (source / (name + '.py')).exists():
                        self.assertIn(f'COPY {name}.py /app/{name}.py', docker)

    def test_nested_watchman_fields(self):
        schema = [{"domain": "watchman", "services": {"report": {"fields": {
            "create_file": {}, "advanced_options": {"fields": {"force_parsing": {}}}
        }}}}]
        self.assertEqual({"create_file": False, "force_parsing": True}, ToolAdapterBus._watchman_request_body(schema))

    def test_provider_quota_not_rate(self):
        quota = ai_provider.http_failure(429, '{"error":{"code":"insufficient_quota","message":"secret"}}', {})
        self.assertEqual("quota", quota.code)
        self.assertNotIn("secret", str(quota))
        rate = ai_provider.http_failure(429, '{}', {"Retry-After": "120"})
        self.assertEqual("rate_limit", rate.code)
        self.assertEqual(120, rate.retry_seconds)

    def test_provider_unknown_html_and_bad_delay(self):
        result = ai_provider.http_failure(502, '<html>private error</html>', {"Retry-After": "nonsense"})
        self.assertEqual("upstream", result.code)
        self.assertNotIn("private error", str(result))

    def test_generic_cause_does_not_join_unrelated_failures(self):
        base = {"probable_cause": "Příčina zatím nebyla automaticky určena.", "logger": "app.service"}
        self.assertNotEqual(FirstOfficer._group_key({**base, "normalized_message": "DNS failed"}), FirstOfficer._group_key({**base, "normalized_message": "Authentication failed"}))

    def test_inprocess_mcp_discovery_cannot_select_log_host(self):
        bus = ToolAdapterBus(None, lambda: '', mock.Mock(return_value='[custom_components.ha_mcp_tools.server] Connect: https://evil.invalid/api/webhook/mcp_1234567890123456'), None, None)
        bus._loaded_components = {"ha_mcp_tools"}
        self.assertEqual('http://supervisor/core/api/webhook/mcp_1234567890123456', bus._discover_ha_mcp_url())
        self.assertNotIn('1234567890123456', _sanitize('/api/webhook/mcp_1234567890123456'))
        self.assertNotIn('1234567890123456', _safe_error('/api/webhook/mcp_1234567890123456'))

    def test_unrelated_log_cannot_supply_mcp_url(self):
        def request(path, **kwargs):
            return '/api/webhook/mcp_1234567890123456' if path == '/core/logs' else {'addons': []}
        bus = ToolAdapterBus(None, lambda: '', request, None, None)
        bus._loaded_components = {'ha_mcp_tools'}
        self.assertEqual('', bus._discover_ha_mcp_url())

    def test_remote_mcp_does_not_receive_supervisor_token(self):
        bus = ToolAdapterBus(None, lambda: '', None, None, None)
        with mock.patch.dict('os.environ', {'SUPERVISOR_TOKEN': 'never-leak'}), mock.patch.object(bus, '_http_json', side_effect=lambda *a, **k: ({'id': k['payload']['id'], 'result': {}}, {})) as call:
            bus._mcp_rpc('ha_mcp', 'https://external.example/mcp', 'tools/list')
            self.assertEqual('', call.call_args.kwargs['token'])
            bus._mcp_rpc('hamster_mcp', 'http://supervisor/core/api/hamster_mcp', 'tools/list')
            self.assertEqual('never-leak', call.call_args.kwargs['token'])

    def test_planner_worker_does_not_block_collection_or_duplicate(self):
        entered, release = threading.Event(), threading.Event()
        officer = mock.Mock()
        def plan(*args, **kwargs):
            entered.set()
            release.wait(3)
            return {'processed': 0}
        officer.automatic_repair_planner.side_effect = plan
        with mock.patch.object(hads4, 'first_officer', return_value=officer), mock.patch.object(hads4, 'repair_engine'), mock.patch.object(hads4, 'options', return_value={}), mock.patch.object(hads4, 'set_setting'):
            try:
                self.assertEqual('running', hads4.start_planner_worker(mock.Mock())['status'])
                self.assertTrue(entered.wait(1))
                self.assertEqual('already_running', hads4.start_planner_worker(mock.Mock())['status'])
            finally:
                release.set()
                # Wait only for this worker before patched dependencies disappear.
                self.assertTrue(hads4._planner_worker_lock.acquire(timeout=3))
                hads4._planner_worker_lock.release()


class Persistence(unittest.TestCase):
    setUp = legacy.RC8RegressionTests.setUp
    tearDown = legacy.RC8RegressionTests.tearDown
    _case_and_plan = legacy.RC8RegressionTests._case_and_plan

    def test_shared_provider_backoff_persists_without_consuming_call_slot(self):
        case, _, _ = self._case_and_plan()
        send = mock.Mock(side_effect=ai_provider.ProviderUnavailable('quota', 'quota', 900))
        for _ in range(3):
            with self.assertRaises(ai_provider.ProviderUnavailable):
                incident_workflow.metered_call(hads4.db, hads4.now_utc, {'ai_paid_calls_enabled': True}, case, 'test-key', {'model': 'test'}, send)
        self.assertEqual(1, send.call_count)
        with hads4.db() as conn:
            self.assertEqual(1, conn.execute('SELECT count(*) FROM ai_calls').fetchone()[0])
        other = mock.Mock(return_value={'status': 'completed'})
        incident_workflow.metered_call(hads4.db, hads4.now_utc, {'ai_paid_calls_enabled': True}, case, 'changed-key', {'model': 'test'}, other)
        other.assert_called_once()

    def test_unlinked_plan_is_visible_but_not_approved(self):
        _, plan, root = self._case_and_plan()
        with hads4.db() as conn:
            conn.execute("UPDATE root_cases SET repair_plan_id=NULL,decision_state='investigating' WHERE id=?", (root,))
        center = hads4.first_officer().command_center()
        self.assertIn(plan, [p['id'] for p in center['standalone_plans']])
        self.assertEqual(0, center['approved_plans'])

    def test_restart_does_not_leave_running_investigation(self):
        case, _, root = self._case_and_plan()
        with hads4.db() as conn:
            conn.execute("INSERT INTO planner_runs(root_case_id,case_id,status,created_at) VALUES(?,?,'running',?)", (root, case, hads4.now_utc()))
        hads4.init_db()
        with hads4.db() as conn:
            self.assertEqual('interrupted', conn.execute('SELECT status FROM planner_runs ORDER BY id DESC LIMIT 1').fetchone()[0])

    def test_new_group_requires_new_plan_approval(self):
        case, plan, root = self._case_and_plan()
        with hads4.db() as conn:
            conn.execute("UPDATE repair_plans SET status='approved' WHERE id=?", (plan,))
            conn.execute("UPDATE cases SET normalized_message='a different unclassified issue',title='changed',probable_cause='Příčina zatím nebyla automaticky určena.',logger='app.other',source_ref='',integration='' WHERE id=?", (case,))
        hads4.first_officer().rebuild_root_cases()
        with hads4.db() as conn:
            self.assertEqual('pending_approval', conn.execute('SELECT status FROM repair_plans WHERE id=?', (plan,)).fetchone()[0])

    def test_watchman_response_survives_refresh_without_fake_new_timestamp(self):
        stamp = '2026-09-16T08:00:00+00:00'
        now = [stamp]
        schema = [{'domain': 'watchman', 'services': {'report': {'fields': {'force_parsing': {}}}}}]
        def request(path, **kwargs):
            if path == '/core/api/services': return schema
            if path == '/core/api/components': return ['watchman']
            if path.startswith('/core/api/services/watchman/report'):
                return {'service_response': {'missing_entities': [], 'missing_actions': []}}
            if path == '/addons': return {'addons': []}
            return []
        bus = ToolAdapterBus(hads4.db, lambda: now[0], request, lambda *a: [], lambda: None)
        with mock.patch.object(bus, '_auto_mcp_urls', return_value={}), mock.patch.object(bus, '_auto_json_connector', return_value=(None, '')):
            first = bus.refresh(True)
            self.assertTrue(first['adapters']['watchman']['data_used'])
            now[0] = '2026-09-16T08:03:00+00:00'
            bus._last_refresh_monotonic = 0
            second = bus.refresh()
            self.assertTrue(second['adapters']['watchman']['data_used'])
            self.assertEqual(stamp, second['adapters']['watchman']['last_success_at'])

    def test_mcp_error_only_is_not_used_data(self):
        case, _, root = self._case_and_plan()
        bus = ToolAdapterBus(hads4.db, hads4.now_utc, None, None, None)
        with mock.patch.object(bus, 'refresh'), mock.patch.object(bus, 'global_findings', return_value=[]), mock.patch.object(bus, 'status', return_value=[{'adapter_id':'hamster_mcp','active':False,'discovery':{'connector_ready':True}}]), mock.patch.object(bus, '_mcp_case_evidence', return_value={'outputs':[{'error':'failed'}]}):
            result = bus.collect({'id':case}, root)
        self.assertNotIn('hamster_mcp', result['used'])
