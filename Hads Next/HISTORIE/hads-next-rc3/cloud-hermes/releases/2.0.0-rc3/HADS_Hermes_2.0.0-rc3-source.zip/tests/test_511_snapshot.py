"""Production regression: panel byte limit must not stop diagnosis startup."""
import http.client
import json
import threading
import unittest
from unittest import mock

import hads4
import panel_model as panel
import runtime_core as rt
import test_rc8_regressions as legacy


def large_model(count=2000):
    rows = [{'id': n, 'public_id': f'R-{n:03}', 'title': 'Automatizace selhala ' + 'ž'*500,
             'root_cause': 'Příčina ' + 'ř'*800, 'decision_state': 'approved' if n == count-1 else 'investigating',
             'repair_plan_id': 14 if n == count-1 else None} for n in range(count)]
    return {'updated_at': '2026-10-12T05:00:00+00:00', 'functional_cases': rows,
            'investigating_cases': rows, 'attention_cases': rows[-1:], 'repair_cases': rows[-1:],
            'approved_plans': 1, 'tracked_root_count': count,
            'counts': {'investigating': count-1, 'approved': 1},
            'batch_checklist': {'runnable': True, 'approved_plans': 1, 'write_gate': 'locked'}}


class SnapshotTests(unittest.TestCase):
    def test_reproduces_rc1_limit_and_new_projection_fits(self):
        model = large_model()
        snapshot = rt.Snapshot()
        with self.assertRaises(rt.ResponseTooLarge):
            snapshot.publish(model)
        bounded = panel.bounded(model)
        snapshot.publish(bounded)
        self.assertLess(len(snapshot.get()[0]), 2*rt.MIB)
        self.assertEqual(2000, bounded['tracked_root_count'])
        self.assertEqual(2000, bounded['panel_paging']['functional_cases']['total'])
        self.assertEqual(1, bounded['approved_plans'])
        self.assertEqual(1999, bounded['attention_cases'][0]['id'])
        self.assertEqual(model['counts'], bounded['counts'])
        self.assertEqual(model['batch_checklist'], bounded['batch_checklist'])
        self.assertEqual(2000, len(model['functional_cases']))

    def test_all_rows_reachable_without_duplication_or_source_mutation(self):
        model = large_model(114)
        before = json.dumps(model, ensure_ascii=False)
        ids, offset = [], 0
        while True:
            page = panel.section_page(model, 'functional_cases', offset, 25)
            ids.extend(r['id'] for r in page['rows'])
            if page['next_offset'] is None:
                break
            offset = page['next_offset']
        self.assertEqual(list(range(114)), ids)
        self.assertEqual(before, json.dumps(model, ensure_ascii=False))

    def test_large_metadata_is_preview_not_a_ram_request(self):
        model = large_model(114)
        model['tool_adapters'] = [{'title': 'HA-MCP', 'last_error': 'é'*1000000}]
        snapshot = rt.Snapshot()
        snapshot.publish(panel.bounded(model))
        value = json.loads(snapshot.get()[0])
        self.assertIn('zkrácený přehled', value['tool_adapters'][0]['last_error'])
        self.assertEqual(1000000, len(model['tool_adapters'][0]['last_error']))

    def test_section_validation_and_page_clamping(self):
        with self.assertRaises(ValueError):
            panel.section_page({}, '../options')
        page = panel.section_page(large_model(114), 'functional_cases', 999999, 1000000)
        self.assertEqual(50, page['limit'])
        self.assertEqual(100, page['offset'])
        self.assertEqual(114, page['total'])
        self.assertIsNone(page['next_offset'])
        self.assertEqual(0, panel.section_page({}, 'functional_cases', -5)['offset'])

    def test_nested_connector_preview_and_page_are_byte_bounded(self):
        row = {'title': 'Zdroj', 'nested': {str(n): ['ř'*2000]*30 for n in range(100)}}
        model = {'tool_adapters': [row]*114}
        result = panel.section_page(model, 'tool_adapters')
        self.assertLessEqual(len(json.dumps(result, ensure_ascii=False).encode()), 512*1024)
        self.assertEqual(114, result['total'])
        self.assertLess(result['limit'], 50)
        self.assertEqual(result['limit'], result['next_offset'])
        self.assertEqual(100, len(row['nested']))

    def test_snapshot_keeps_payload_and_time_on_utf8_byte_overflow(self):
        snapshot = rt.Snapshot(limit=100)
        snapshot.publish({'good': True})
        before = snapshot.get()
        with self.assertRaises(rt.ResponseTooLarge):
            snapshot.publish({'data': 'ř'*60})
        self.assertEqual(before[:2], snapshot.get()[:2])
        self.assertIn('100 bajtů', snapshot.get()[2])
        snapshot.publish({'recovered': True})
        self.assertEqual('', snapshot.get()[2])


class StartupTests(unittest.TestCase):
    def setUp(self):
        self.snapshot = rt.Snapshot()
        self.state = {'status': 'starting', 'message': 'Starting'}
        self.governor = mock.Mock()
        self.governor.status.return_value = {'jobs': []}
        for name, value in [('panel_snapshot', self.snapshot), ('startup_state', self.state),
                            ('governor', None), ('managed_runtime', True)]:
            patcher = mock.patch.object(hads4, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)

    def test_panel_failure_starts_all_workers_and_fails_closed_then_recovers(self):
        with mock.patch.object(rt, 'Governor', return_value=self.governor), \
             mock.patch.object(hads4, 'initialize_runtime') as initialize, \
             mock.patch.object(hads4, 'first_officer_command_center', side_effect=ValueError('bad panel')), \
             mock.patch.object(hads4.threading, 'Thread') as threads:
            hads4.bootstrap_runtime()
        initialize.assert_called_once()
        self.assertEqual('ready', self.state['status'])
        self.governor.finish.assert_called_once_with(True)
        self.assertEqual(5, threads.call_count)
        self.assertEqual(5, threads.return_value.start.call_count)
        self.assertEqual('bad panel', self.state['panel_error'])
        value = hads4.panel_read_model()
        self.assertFalse(value['batch_checklist']['runnable'])
        self.assertEqual('bad panel', value['snapshot_status']['error'])
        self.assertNotIn('approved_plans', value)  # unknown, not a fabricated zero
        with mock.patch.object(hads4, 'first_officer_command_center', return_value=large_model(114)):
            hads4.publish_panel_snapshot()
        self.assertNotIn('panel_error', self.state)
        self.assertEqual('', hads4.panel_read_model()['snapshot_status']['error'])
        self.assertEqual(1, hads4.panel_read_model()['approved_plans'])

    def test_real_database_initialization_failure_does_not_start_workers(self):
        with mock.patch.object(rt, 'Governor', return_value=self.governor), \
             mock.patch.object(hads4, 'initialize_runtime', side_effect=ValueError('bad DB')), \
             mock.patch.object(hads4.threading, 'Thread') as threads:
            hads4.bootstrap_runtime()
        self.assertEqual('failed', self.state['status'])
        self.governor.finish.assert_called_once_with(False)
        threads.assert_not_called()
        self.assertIsNone(self.snapshot.get()[0])

    def test_even_fallback_publication_failure_does_not_stop_workers(self):
        with mock.patch.object(rt, 'Governor', return_value=self.governor), \
             mock.patch.object(hads4, 'initialize_runtime'), \
             mock.patch.object(hads4, 'panel_snapshot', rt.Snapshot(limit=1)), \
             mock.patch.object(hads4, 'first_officer_command_center', side_effect=ValueError('bad panel')), \
             mock.patch.object(hads4.threading, 'Thread') as threads:
            hads4.bootstrap_runtime()
        self.assertEqual('ready', self.state['status'])
        self.assertEqual(5, threads.return_value.start.call_count)

    def test_failed_refresh_keeps_old_rows_but_disables_launch(self):
        self.snapshot.publish(large_model(2))
        stamp = self.snapshot.get()[1]
        hads4.panel_publish_failed(ValueError('refresh failed'))
        value = hads4.panel_read_model()
        self.assertEqual(2, value['tracked_root_count'])
        self.assertEqual(1, value['approved_plans'])
        self.assertFalse(value['batch_checklist']['runnable'])
        self.assertEqual(stamp, self.snapshot.get()[1])


class HTTPTests(unittest.TestCase):
    def test_real_readonly_pages_and_degraded_readiness(self):
        server = rt.BoundedHTTPServer(('127.0.0.1', 0), hads4.Handler, workers=2)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        snapshot = rt.Snapshot()
        snapshot.publish({'health': {}})
        snapshot.fail('panel unavailable')
        try:
            with mock.patch.object(hads4, 'panel_snapshot', snapshot), \
                 mock.patch.object(hads4, 'first_officer_command_center', return_value=large_model(114)), \
                 mock.patch.object(hads4, 'db', side_effect=AssertionError('write attempted')):
                for path, expected in [('/api/panel-section?section=functional_cases&offset=50', 200),
                                       ('/api/panel-section?section=unknown', 400),
                                       ('/api/panel-section?section=functional_cases&offset=x', 400),
                                       ('/ready', 503)]:
                    conn = http.client.HTTPConnection(*server.server_address, timeout=3)
                    conn.request('GET', path)
                    response = conn.getresponse()
                    value = json.loads(response.read())
                    conn.close()
                    self.assertEqual(expected, response.status)
                    if expected == 200:
                        self.assertEqual(50, value['rows'][0]['id'])
                        self.assertEqual(114, value['total'])
                        self.assertEqual(100, value['next_offset'])
        finally:
            server.shutdown()
            server.server_close()
            worker.join(2)


class DatabaseProjectionTests(unittest.TestCase):
    setUp = legacy.RC8RegressionTests.setUp
    tearDown = legacy.RC8RegressionTests.tearDown
    _case_and_plan = legacy.RC8RegressionTests._case_and_plan

    def test_large_sql_database_keeps_approval_evidence_and_all_case_ids(self):
        _, plan_id, root_id = self._case_and_plan()
        now = hads4.now_utc()
        evidence = json.dumps({'raw': 'x'*rt.MIB})
        with hads4.db() as conn:
            conn.execute("UPDATE root_cases SET decision_state='approved',evidence_json=? WHERE id=?", (evidence, root_id))
            conn.execute("UPDATE repair_plans SET status='approved' WHERE id=?", (plan_id,))
            conn.executemany("""INSERT INTO root_cases(fingerprint,title,root_cause,recommendation,decision_state,
                first_seen,last_seen,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)""",
                [(f'large-panel-{n}', 'Automatizace selhala '+'ř'*450, 'Příčina '+'ž'*750,
                  'Doporučení '+'č'*750, 'investigating', now, now, now, now) for n in range(1500)])
        full = hads4.first_officer().command_center()
        self.assertEqual(1501, full['tracked_root_count'])
        self.assertEqual(1, full['approved_plans'])
        self.assertGreater(len(json.dumps(full, ensure_ascii=False).encode()), 2*rt.MIB)
        snapshot = rt.Snapshot()
        snapshot.publish(panel.bounded(full))
        value = json.loads(snapshot.get()[0])
        self.assertEqual(1501, value['tracked_root_count'])
        self.assertEqual(1, value['approved_plans'])
        self.assertEqual(plan_id, value['attention_cases'][0]['repair_plan_id'])
        with hads4.db_read() as conn:
            self.assertEqual(1501, conn.execute('SELECT COUNT(*) FROM root_cases').fetchone()[0])
            self.assertEqual(evidence, conn.execute('SELECT evidence_json FROM root_cases WHERE id=?',(root_id,)).fetchone()[0])
