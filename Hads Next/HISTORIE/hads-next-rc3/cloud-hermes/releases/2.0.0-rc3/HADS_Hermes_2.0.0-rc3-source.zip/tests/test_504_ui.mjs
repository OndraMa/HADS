import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const elements = new Map();
const element = id => {
  if(!elements.has(id))elements.set(id,{innerHTML:'',textContent:'',dataset:{},hidden:false,addEventListener(){}});
  return elements.get(id);
};
const context=vm.createContext({document:{getElementById:element,addEventListener(){},querySelectorAll(){return[];}},window:{addEventListener(){}},setInterval(){},setTimeout,clearTimeout,AbortSignal,console});
const source=fs.readFileSync(new URL('../web/app.js',import.meta.url),'utf8').replace(/reload\(\);\s*$/, '');
vm.runInContext(source,context);
vm.runInContext(`state={tool_adapters:[{title:'HA-MCP',discovery:{current_presence:'confirmed',connection_verified:false,
 mcp_setup:{message:'Adresa <script> není ověřena',next_step:'Vyplňte ha_mcp_url',purpose:'MCP není model',missing_read_tools:['ha_get_history']}}}],log_sources:[]};renderSources();`,context);
const html=element('main').innerHTML;
assert.match(html,/HA-MCP: co dělat dál/);
assert.match(html,/Vyplňte ha_mcp_url/);
assert.match(html,/ha_get_history/);
assert.match(html,/&lt;script&gt;/);
assert.doesNotMatch(html,/<script>/);
assert.equal(vm.runInContext('mcpSetupHelp({})',context),'');
console.log('RC4 UI: visible setup help, missing read tools and escaped untrusted text passed');
