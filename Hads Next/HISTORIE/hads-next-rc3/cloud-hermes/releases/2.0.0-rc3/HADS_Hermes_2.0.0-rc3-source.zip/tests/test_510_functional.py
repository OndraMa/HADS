import datetime as dt
import json
import unittest
from unittest import mock

import functional_focus as focus
import hads4
from investigation import Investigator
import test_rc8_regressions as legacy


class FocusTests(unittest.TestCase):
    def test_user_examples_are_separated_not_deleted(self):
        rows = [{"id": 1, "title": "Automatizace vypnutí světel selhala", "decision_state": "investigating"},
                {"id": 2, "title": "Error fetching version information from registry.hub.docker.com", "priority": "P1"},
                {"id": 3, "title": "Connection error subscribing to events Traceback file.py", "temporal_state": "transient"},
                {"id": 4, "title": "Failed to open pulseaudio", "priority": "P1"}]
        grouped = focus.partition(rows)
        self.assertEqual([1], [r['id'] for r in grouped['functional']])
        self.assertEqual({2, 3, 4}, {r['id'] for r in grouped['technical']})
        self.assertEqual(4, sum(map(len, grouped.values())))

    def test_p1_and_frequency_alone_do_not_prove_impact(self):
        self.assertEqual('technical', focus.classify({'title': 'Error fetching version data', 'priority': 'P1', 'occurrence_count': 9999})['lane'])

    def test_proven_oom_and_bootloop_never_hidden_as_transient(self):
        for title in ('Core bootloop', 'Out of memory: killed process'):
            self.assertEqual('functional', focus.classify({'title': title, 'temporal_state': 'grace', 'evidence_state': 'confirmed'})['lane'])

    def test_failed_repair_plan_and_user_question_stay_visible(self):
        for state in ('repair_failed', 'needs_information', 'verifying', 'approved'):
            self.assertEqual('action', focus.classify({'title': 'file.py', 'decision_state': state})['lane'])
        self.assertEqual('action', focus.classify({'title': 'file.py', 'repair_plan_id': 4})['lane'])

    def test_current_unavailable_overrides_transport_noise_but_expires(self):
        row = {'title': 'Connection error', 'research': {'research': {'functional_evidence': {
            'current_impact': 'unavailable', 'observed_at': dt.datetime.now(dt.timezone.utc).isoformat()}}}}
        self.assertEqual('functional', focus.classify(row)['lane'])
        row['research']['research']['functional_evidence']['observed_at'] = '2020-01-01T00:00:00+00:00'
        self.assertEqual('technical', focus.classify(row)['lane'])

    def test_unknown_is_not_resolved(self):
        self.assertEqual('unverified', focus.classify({'title': 'Unclassified fault'})['lane'])
        self.assertEqual('unverified', focus.classify({'title': 'Unclassified fault', 'research': {'research': ['malformed']}})['lane'])

    def test_technical_interval_is_six_hours(self):
        self.assertEqual(21600, focus.due_interval({'title': 'Pulseaudio error'}))
        self.assertEqual(1800, focus.due_interval({'title': 'Automation failed'}))

    def test_read_budget_never_calls_callback_after_limit(self):
        inv = Investigator(None, None, None, lambda: 'now', max_reads=1)
        fn = mock.Mock(return_value={})
        self.assertEqual('ok', inv.read('first', fn)['status'])
        self.assertEqual('deferred', inv.read('second', fn)['status'])
        fn.assert_called_once()

    def test_expired_read_deadline_is_a_gap(self):
        inv = Investigator(None, None, None, lambda: 'now', seconds=0)
        fn = mock.Mock()
        self.assertEqual('deferred', inv.read('first', fn)['status'])
        fn.assert_not_called()

    def test_actual_device_collection_uses_exact_identifier(self):
        inv = mock.Mock()
        inv.device.return_value = {'current': {'status': 'ok', 'data': {'state': 'unavailable'}}, 'history': {'status': 'ok', 'data': {'records': []}}}
        result = focus.collect({'title': 'light.lamp failed', 'last_seen': '2026-10-08T10:00:00+00:00'}, inv, 'now')
        self.assertEqual('unavailable', result['current_impact'])
        self.assertEqual('light.lamp', inv.device.call_args.args[0])
        self.assertTrue(result['coverage_gaps'])

    def test_successful_read_is_not_successful_control(self):
        inv = mock.Mock()
        inv.device.return_value = {'current': {'status': 'ok', 'data': {'state': 'on'}}}
        result = focus.collect({'title': 'light.lamp failed', 'last_seen': '2026-10-08T10:00:00+00:00'}, inv, 'now')
        self.assertEqual('unknown', result['current_impact'])
        self.assertIn('není důkaz', result['summary'])

    def test_read_failure_is_not_device_failure(self):
        inv = mock.Mock()
        inv.device.return_value = {'current': {'status': 'unavailable', 'error': 'unauthorized'}}
        result = focus.collect({'title': 'light.lamp failed', 'last_seen': '2026-10-08T10:00:00+00:00'}, inv, 'now')
        self.assertEqual('unknown', result['current_impact'])
        self.assertIn('chyba čtení', result['coverage_gaps'][0])

    def test_no_identifier_does_not_guess_phone_or_mutate(self):
        inv = mock.Mock()
        result = focus.collect({'title': 'icloud.play_sound No device with name'}, inv, 'now')
        self.assertFalse(inv.mock_calls)
        self.assertIn('Find My', result['next_step'])

    def test_invalid_time_does_not_guess_historical_window(self):
        inv = mock.Mock()
        inv.live_state.return_value = {'status': 'ok', 'data': {'state': 'on'}}
        result = focus.collect({'title': 'light.lamp failed'}, inv, 'now')
        inv.device.assert_not_called()
        inv.history.assert_not_called()
        self.assertTrue(result['coverage_gaps'])

    def test_meross_mqtt_not_automatically_lamp_offline(self):
        result = focus.collect({'title': 'mqtt_not_setup_cannot_publish'}, mock.Mock(), 'now')
        self.assertIn('HTTP', result['summary'])
        self.assertEqual('unknown', result['current_impact'])

    def recovered(self, seconds=10):
        return {'current': {'status': 'ok', 'data': {'state': 'on'}}, 'history': {'status': 'ok', 'data': {'omitted': 0, 'records': [
            {'state': 'unavailable', 'last_changed': '2026-10-08T10:00:00+00:00'},
            {'state': 'on', 'last_changed': f'2026-10-08T10:{seconds//60:02d}:{seconds%60:02d}+00:00'}]}}}

    def test_short_recovery_requires_evidence_not_age(self):
        self.assertTrue(focus.short_recovery(self.recovered()))
        self.assertFalse(focus.short_recovery(self.recovered(120)))
        item = self.recovered()
        item['history']['data']['omitted'] = 1
        self.assertFalse(focus.short_recovery(item))

    def test_missing_or_unordered_history_is_not_proof_of_recovery(self):
        item = self.recovered()
        item['history']['data']['records'].reverse()
        self.assertFalse(focus.short_recovery(item))
        item = self.recovered()
        item['history']['data']['records'][0].pop('last_changed')
        self.assertFalse(focus.short_recovery(item))

    def test_short_recovery_does_not_hide_failed_automation(self):
        native = {'current_impact': 'transient_recovered', 'observed_at': dt.datetime.now(dt.timezone.utc).isoformat()}
        row = {'title': 'light.lamp unavailable', 'research': {'research': {'functional_evidence': native}}}
        self.assertEqual('technical', focus.classify(row)['lane'])
        row['title'] = 'automation.turn_off failed'
        self.assertEqual('functional', focus.classify(row)['lane'])


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        legacy.RC8RegressionTests.setUp(self)

    def tearDown(self):
        legacy.RC8RegressionTests.tearDown(self)

    def test_compact_snapshot_retains_native_evidence_and_confirmed_flag(self):
        _, _, root = legacy.RC8RegressionTests._case_and_plan(self)
        native = {'observed_at': hads4.now_utc(), 'current_impact': 'unavailable', 'summary': 'Přesný stav', 'targets': ['x'*100000]}
        with hads4.db() as conn:
            conn.execute("UPDATE root_cases SET research_json=?,evidence_json=? WHERE id=?", (json.dumps({'research': {'functional_evidence': native}}), '[{"state":"confirmed"}]', root))
        row = hads4.first_officer().list_roots(compact=True)[0]
        self.assertEqual('Přesný stav', row['research']['research']['functional_evidence']['summary'])
        self.assertNotIn('targets', row['research']['research']['functional_evidence'])
        self.assertEqual('confirmed', row['evidence'][0]['state'])
        self.assertEqual('action', row['attention']['lane'])

    def test_approved_plan_stays_in_both_repair_queue_and_attention(self):
        _, plan, root = legacy.RC8RegressionTests._case_and_plan(self)
        hads4.first_officer_decide(root, {'decision': 'approve'})
        result = hads4.first_officer().command_center()
        self.assertEqual(1, result['approved_plans'])
        self.assertIn(root, [r['id'] for r in result['attention_cases']])
        self.assertIn(plan, [r['repair_plan_id'] for r in result['repair_cases']])

    def test_ignored_case_is_not_reintroduced_as_an_operational_problem(self):
        _, _, root = legacy.RC8RegressionTests._case_and_plan(self)
        hads4.first_officer_decide(root, {'decision': 'ignore', 'reason': 'Test: ověřený vlastní důvod'})
        result = hads4.first_officer().command_center()
        for key in ('attention_cases', 'functional_cases', 'technical_cases', 'unverified_cases'):
            self.assertNotIn(root, [r['id'] for r in result[key]])
        self.assertIn(root, [r['id'] for r in result['history_cases']])

    def test_technical_background_does_not_spend_paid_ai(self):
        with mock.patch.object(hads4, 'case_detail', return_value={'title': 'Error fetching version data'}), mock.patch.object(hads4, 'derive_verified_repair_actions', return_value={}), mock.patch.object(hads4, 'options', return_value={'ai_background_research': True}), mock.patch.object(hads4, 'research_case') as paid:
            result = hads4.planner_research(1, 'Diagnose', {'evidence': []})
        paid.assert_not_called()
        self.assertIn('aktualizaci', result['functional_evidence']['summary'])

    def planner_roots(self, titles):
        case, _, root = legacy.RC8RegressionTests._case_and_plan(self)
        now = hads4.now_utc()
        with hads4.db() as conn:
            conn.execute("UPDATE root_cases SET title=?,repair_plan_id=NULL,decision_state='investigating' WHERE id=?", (titles[0], root))
            roots = [root]
            for index, title in enumerate(titles[1:], 1):
                other = conn.execute("INSERT INTO root_cases(fingerprint,title,decision_state,first_seen,last_seen,created_at,updated_at) VALUES(?,?,'investigating',?,?,?,?)", (f'focus-{index}', title, now, now, now, now)).lastrowid
                conn.execute("INSERT INTO root_case_members(root_case_id,case_id,relation,confidence) VALUES(?,?,'primary',99)", (other, case))
                roots.append(other)
        return roots

    def run_planner(self, limit):
        seen = []
        bus = mock.Mock()
        bus.collect.side_effect = lambda primary, root: seen.append(root) or {'used': [], 'evidence': []}
        blocked_write = mock.Mock(side_effect=AssertionError('read investigation must not create empty repair'))
        hads4.first_officer().automatic_repair_planner(preview=blocked_write, create_plan=blocked_write, research=lambda *args: {'summary': 'Read only'}, tool_bus=bus, limit=limit)
        blocked_write.assert_not_called()
        return seen

    def test_planner_prioritizes_functional_case_over_technical(self):
        roots = self.planner_roots(['Error fetching version data', 'Automation failed'])
        self.assertEqual([roots[1]], self.run_planner(1))

    def test_planner_reserves_one_technical_slot_without_stopping_foreground(self):
        roots = self.planner_roots(['Error fetching version data', 'Automation failed', 'Script failed'])
        seen = self.run_planner(2)
        self.assertIn(roots[0], seen)
        self.assertEqual(roots[1], seen[0])
