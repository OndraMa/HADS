"""Native OneDrive installer contracts. No HA/OneDrive requests in these tests."""
import base64
import hashlib
import io
import json
from pathlib import Path
import struct
import tarfile
import unittest
from unittest import mock

import install_guard
import native_backup as nb
from test_500_runtime import test_directory


class NativeBackupTests(unittest.TestCase):
    def test_cloud_ack_alone_cannot_unlock_install(self):
        with test_directory() as directory:
            path = Path(directory, 'test.tar')
            path.write_bytes(b'backup')
            for reply in [('wrong', 6), (hashlib.sha256(b'backup').hexdigest(), 7)]:
                with mock.patch.object(nb, 'upload_backup', return_value='slug') as upload, mock.patch.object(nb, 'readback_sha256', return_value=reply) as readback:
                    with self.assertRaises(RuntimeError):
                        install_guard.cloud_copy(path, 'onedrive.account')
                    upload.assert_called_once_with(path, 'onedrive.account')
                    readback.assert_called_once_with('slug', 'onedrive.account')

    def test_exact_remote_bytes_unlock_and_record_cloud_agent(self):
        with test_directory() as directory:
            path = Path(directory, 'test.tar')
            path.write_bytes(b'backup')
            with mock.patch.object(nb, 'upload_backup', return_value='slug'), mock.patch.object(nb, 'readback_sha256', return_value=(hashlib.sha256(b'backup').hexdigest(), 6)):
                receipt = install_guard.cloud_copy(path, 'onedrive.account')
            self.assertTrue(receipt['readback_verified'])
            self.assertEqual('onedrive.account', receipt['agent_id'])

    def test_upload_streams_bounded_multipart_and_no_retry(self):
        with test_directory() as directory, mock.patch.dict('os.environ', {'SUPERVISOR_TOKEN': 'test-only'}):
            path = Path(directory, 'test.tar')
            path.write_bytes(b'a' * (nb.CHUNK * 2 + 7))
            connection = mock.Mock()
            response = connection.getresponse.return_value
            response.status = 201
            response.read.return_value = b'{"backup_id":"slug"}'
            with mock.patch.object(nb.http.client, 'HTTPConnection', return_value=connection):
                self.assertEqual('slug', nb.upload_backup(path, 'onedrive.a+b'))
            connection.putrequest.assert_called_once_with('POST', '/core/api/backup/upload?agent_id=onedrive.a%2Bb')
            blocks = [call.args[0] for call in connection.send.call_args_list]
            self.assertLessEqual(max(map(len, blocks)), nb.CHUNK)
            length = next(call.args[1] for call in connection.putheader.call_args_list if call.args[0] == 'Content-Length')
            self.assertEqual(int(length), sum(map(len, blocks)))
            self.assertEqual(path.read_bytes(), b''.join(blocks[1:-1]))
            connection.close.assert_called_once()

    def test_failed_upload_does_not_readback_or_retry(self):
        with test_directory() as directory, mock.patch.dict('os.environ', {'SUPERVISOR_TOKEN': 'test-only'}):
            path = Path(directory, 'test.tar')
            path.write_bytes(b'x')
            connection = mock.Mock()
            connection.getresponse.return_value.status = 502
            connection.getresponse.return_value.read.return_value = b'error'
            with mock.patch.object(nb.http.client, 'HTTPConnection', return_value=connection), mock.patch.object(nb, 'readback_sha256') as readback:
                with self.assertRaises(RuntimeError):
                    install_guard.cloud_copy(path, 'onedrive.account')
                readback.assert_not_called()
                connection.putrequest.assert_called_once()

    def test_download_selects_remote_agent_and_rejects_redirect(self):
        with mock.patch.dict('os.environ', {'SUPERVISOR_TOKEN': 'test-only'}):
            for status in (200, 302, 404, 502):
                connection = mock.Mock()
                response = connection.getresponse.return_value
                response.status = status
                response.read.side_effect = [b'backup', b'']
                with mock.patch.object(nb.http.client, 'HTTPConnection', return_value=connection):
                    if status == 200:
                        self.assertEqual((hashlib.sha256(b'backup').hexdigest(), 6), nb.readback_sha256('slug', 'onedrive.a'))
                    else:
                        with self.assertRaises(RuntimeError):
                            nb.readback_sha256('slug', 'onedrive.a')
                self.assertEqual('/core/api/backup/download/slug?agent_id=onedrive.a', connection.request.call_args.args[1])
                connection.close.assert_called_once()

    def test_source_must_be_in_full_backup_not_just_local_share(self):
        content = b'source-copy'
        source = {'member': 'hads4_preinstall_source/source.tar.gz', 'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)}
        with test_directory() as directory:
            for name, data, passes in [(source['member'], content, True), ('share/' + source['member'], content, True), (source['member'], b'wrong', False), ('elsewhere', content, False)]:
                inner = io.BytesIO()
                with tarfile.open(fileobj=inner, mode='w:gz') as archive:
                    item = tarfile.TarInfo('./' + name)
                    item.size = len(data)
                    archive.addfile(item, io.BytesIO(data))
                backup = Path(directory, 'full.tar')
                with tarfile.open(backup, 'w') as archive:
                    item = tarfile.TarInfo('./share.tar.gz')
                    item.size = len(inner.getvalue())
                    archive.addfile(item, io.BytesIO(inner.getvalue()))
                if passes:
                    install_guard.verify_source_in_backup(backup, source)
                else:
                    with self.assertRaises(RuntimeError):
                        install_guard.verify_source_in_backup(backup, source)

    def test_installer_skips_backup_but_preserves_sources_and_access_check(self):
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
        import build_release
        with test_directory() as directory:
            destination = Path(directory, 'installer.sh')
            build_release.installer(b'test-payload', destination)
            text = destination.read_text(encoding='utf-8')
            self.assertLess(text.index('install_guard.py" access'), text.index('EXISTING=0'))
            self.assertIn('mv "$TARGET" "$BACKUP"', text)
            for forbidden in ('ha backups new', 'ha backups info', '$BACKUP_SLUG', 'install_guard.py" preflight', 'install_guard.py" cloud'):
                self.assertNotIn(forbidden, text)
            self.assertNotIn('HADS_ONEDRIVE_REMOTE', text)


class FakeSocket:
    def __init__(self, mode):
        self.mode = mode
        self.pending = bytearray()
        self.sent = []

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def settimeout(self, value):
        pass

    def recv(self, size):
        data = bytes(self.pending[:min(size, 3)])
        del self.pending[:len(data)]
        return data

    def sendall(self, data):
        self.sent.append(data)
        if data.startswith(b'GET '):
            key = data.split(b'Sec-WebSocket-Key: ')[1].split(b'\r\n')[0]
            accept = base64.b64encode(hashlib.sha1(key + b'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest())
            if self.mode == 'bad_handshake':
                accept = b'wrong'
            self.pending.extend(b'HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nSec-WebSocket-Accept: ' + accept + b'\r\n\r\n')
            self.frame({'type': 'auth_required'})
        elif data[0] & 15 == 1:
            size = data[1] & 127
            offset = 2
            if size == 126:
                size = struct.unpack('!H', data[2:4])[0]
                offset = 4
            mask = data[offset:offset + 4]
            message = json.loads(bytes(b ^ mask[i % 4] for i, b in enumerate(data[offset + 4:])))
            if message.get('type') == 'auth':
                self.frame({'type': 'auth_invalid' if self.mode == 'auth_invalid' else 'auth_ok'})
            elif self.mode == 'oversized':
                self.pending.extend(b'\x81\x7f' + struct.pack('!Q', nb.LIMIT + 1))
            else:
                reply = {'id': 1, 'success': self.mode != 'denied', 'result': {'agents': [{'agent_id': 'onedrive.a'}]}}
                encoded = json.dumps(reply).encode()
                if self.mode == 'fragmented':
                    self.pending.extend(bytes([1, 10]) + encoded[:10] + b'\x89\x01p' + bytes([128, len(encoded) - 10]) + encoded[10:])
                else:
                    self.frame(reply)

    def frame(self, value):
        data = json.dumps(value).encode()
        self.pending.extend(bytes([129, len(data)]) + data)


class NativeWebsocketTests(unittest.TestCase):
    def test_authenticated_read_only_agent_discovery_and_fragment_ping(self):
        for mode in ('ok', 'fragmented'):
            sock = FakeSocket(mode)
            with mock.patch.dict('os.environ', {'SUPERVISOR_TOKEN': 'test-only'}), mock.patch.object(nb.socket, 'create_connection', return_value=sock):
                self.assertEqual([{'agent_id': 'onedrive.a'}], nb.backup_agents())

    def test_bad_handshake_auth_permission_or_unbounded_frame_stops(self):
        for mode in ('bad_handshake', 'auth_invalid', 'denied', 'oversized'):
            sock = FakeSocket(mode)
            with mock.patch.dict('os.environ', {'SUPERVISOR_TOKEN': 'test-only'}), mock.patch.object(nb.socket, 'create_connection', return_value=sock):
                with self.assertRaises(RuntimeError):
                    nb.backup_agents()
