"""RC7 safety regressions. Network is mocked; no API credit is consumed."""
import concurrent.futures
import threading
import unittest
from unittest import mock

import hads4
import incident_workflow as workflow
import test_rc8_regressions as legacy


class Safety477(unittest.TestCase):
    setUp = legacy.RC8RegressionTests.setUp
    tearDown = legacy.RC8RegressionTests.tearDown

    def test_existing_key_and_uncapped_option_do_not_grant_new_consent(self):
        cfg = {"openai_enabled": True, "openai_api_key": "test", "ai_call_limits_enabled": False}
        send = mock.Mock()
        with self.assertRaises(workflow.AIBudgetExhausted):
            workflow.metered_call(hads4.db, hads4.now_utc, cfg, 1, "test", {}, send)
        with mock.patch.object(hads4, "options", return_value=cfg), mock.patch.object(hads4, "case_detail") as detail:
            with self.assertRaises(workflow.AIBudgetExhausted):
                hads4.research_case(1, {})
            detail.assert_not_called()
        send.assert_not_called()

    def test_428_attempts_cannot_bypass_daily_limit_even_after_restart(self):
        cfg = {"ai_paid_calls_enabled": True, "ai_call_limits_enabled": False, "ai_daily_call_limit": 3}
        send = mock.Mock(return_value={"status": "completed"})
        for index in range(428):
            if index == 100:
                workflow.initialize(hads4.db, hads4.now_utc)
            try:
                workflow.metered_call(hads4.db, hads4.now_utc, cfg, index, "test", {}, send)
            except workflow.AIBudgetExhausted:
                pass
        self.assertEqual(3, send.call_count)

    def test_concurrent_requests_reserve_slots_atomically(self):
        cfg = {"ai_paid_calls_enabled": True, "ai_daily_call_limit": 3}
        send = mock.Mock(return_value={"status": "completed"})
        def attempt(index):
            try:
                workflow.metered_call(hads4.db, hads4.now_utc, cfg, index, "test", {}, send)
            except workflow.AIBudgetExhausted:
                pass
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            list(pool.map(attempt, range(32)))
        self.assertEqual(3, send.call_count)

    def test_web_requires_separate_consent_and_output_is_bounded(self):
        cfg = {"ai_paid_calls_enabled": True, "ai_max_output_tokens": 12000}
        body = {"tools": [{"type": "web_search"}], "max_tool_calls": 100}
        send = mock.Mock(return_value={"status": "completed"})
        with self.assertRaises(workflow.AIBudgetExhausted):
            workflow.metered_call(hads4.db, hads4.now_utc, cfg, 1, "test", body, send)
        send.assert_not_called()
        cfg["ai_paid_web_enabled"] = True
        workflow.metered_call(hads4.db, hads4.now_utc, cfg, 1, "test", body, send)
        self.assertEqual(1, send.call_args.args[1]["max_tool_calls"])
        self.assertEqual(4000, send.call_args.args[1]["max_output_tokens"])

    def test_core_check_releases_database_for_other_threads(self):
        cfgroot = self.test_root / "config"
        cfgroot.mkdir()
        read_completed = threading.Event()
        def read_database():
            with hads4.db() as conn:
                conn.execute("SELECT count(*) FROM cases").fetchone()
            read_completed.set()
        threads = []
        def supervisor(path, **kwargs):
            self.assertEqual("/core/check", path)
            thread = threading.Thread(target=read_database, daemon=True)
            threads.append(thread)
            thread.start()
            return {"result": "ok", "concurrent_read": read_completed.wait(2)}
        with mock.patch.object(hads4, "config_root", return_value=cfgroot), mock.patch.object(hads4, "options", return_value={"yaml_entity_reference_check": False}), mock.patch.object(hads4, "supervisor_request", side_effect=supervisor):
            result = hads4.run_yaml_audit("test")
        for thread in threads:
            thread.join(3)
        self.assertTrue(result["core_check"]["response"]["concurrent_read"])
