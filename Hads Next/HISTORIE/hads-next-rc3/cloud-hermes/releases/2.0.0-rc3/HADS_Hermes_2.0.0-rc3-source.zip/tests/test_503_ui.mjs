import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const elements = new Map(), scores = Array.from({length:6},()=>({textContent:''}));
let removed = false;
const element = id => {
  if(!elements.has(id))elements.set(id,{innerHTML:'',textContent:'',dataset:{},hidden:false,
    querySelectorAll(){return scores;},querySelector(){return {remove(){removed=true;}};},
    insertAdjacentHTML(_,html){this.innerHTML+=html;},addEventListener(){}});
  return elements.get(id);
};
const context=vm.createContext({document:{getElementById:element,addEventListener(){},querySelectorAll(){return[];}},window:{addEventListener(){}},setInterval(){},setTimeout,clearTimeout,AbortSignal,console});
let source=fs.readFileSync(new URL('../web/app.js',import.meta.url),'utf8').replace(/reload\(\);\s*$/, '');
vm.runInContext(source,context);
vm.runInContext(`state={health:{},repair_cases:[],prepared_plan_count:2,executable_plans:2,
  standalone_plans:[{id:6,title:'Plan <six>',status:'pending_approval'},{id:7,title:'Plan seven'}],
  diagnostic_job:{job_id:'test-job',status:'partial',phase:'finished',heartbeat_at:new Date().toISOString(),stage_errors:{yaml:'DB busy'}},
  planner_status:{},batch_checklist:{}};render();`,context);
assert.equal(scores[4].textContent,'2','Overview must count standalone plans too');
assert.match(element('main').innerHTML,/data-plan="6"/);
assert.match(element('main').innerHTML,/data-plan="7"/);
assert.match(element('main').innerHTML,/Plan &lt;six&gt;/);
assert.equal(removed,true,'Do not claim no proposal when standalone plans exist');
assert.match(element('plannerStatus').textContent,/test-job/);
assert.match(element('plannerStatus').textContent,/yaml: DB busy/);
assert.equal(element('launch').disabled,true,'No approval must mean no launch');
console.log('RC3 UI: standalone count, visible plans, escaped title, phase error and approval gate passed');
