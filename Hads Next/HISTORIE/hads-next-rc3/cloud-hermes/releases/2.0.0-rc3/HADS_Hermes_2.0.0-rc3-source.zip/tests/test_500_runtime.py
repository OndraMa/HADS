"""Offline bounded-resource, connector and cache contracts. No paid API calls."""
import http.client
import io
import json
import shutil
import uuid
from contextlib import contextmanager
import threading
import time
import tracemalloc
import unittest
import urllib.error
from pathlib import Path
from unittest import mock

import ai_context
import hads4
import incident_workflow as workflow
import runtime_core as rt
from tool_adapters import ToolAdapterBus
import test_rc8_regressions as legacy
import install_guard
import native_backup


@contextmanager
def test_directory():
    base = (Path.cwd()/'.test-tmp').resolve()
    base.mkdir(exist_ok=True)
    target = base/str(uuid.uuid4())
    target.mkdir()
    try:
        yield str(target)
    finally:
        assert target.resolve().parent == base
        shutil.rmtree(target)


def healthy():
    return {'available_bytes': 512*rt.MIB, 'rss_bytes': 50*rt.MIB}


class RuntimeTests(unittest.TestCase):
    def test_virtual_gigabyte_response_never_allocates_gigabyte(self):
        sizes = []
        class Huge:
            def read(self, amount):
                sizes.append(amount)
                return b'x' * min(amount, 1024*rt.MIB)
        tracemalloc.start()
        try:
            with self.assertRaises(rt.ResponseTooLarge):
                rt.read_bounded(Huge(), rt.MIB)
            _, peak = tracemalloc.get_traced_memory()
        finally:
            tracemalloc.stop()
        self.assertEqual([rt.MIB+1], sizes)
        self.assertLess(peak, 3*rt.MIB)

    def test_cache_bound_lru_expiry_and_no_shared_mutable_object(self):
        cache = rt.ByteCache(limit=1024, ttl=5)
        for i in range(100):
            cache[i] = {'data': 'x'*200}
            self.assertLessEqual(cache.size, 1024)
        self.assertIsNone(cache.get(0))
        item = cache.get(99)
        item['data'] = 'changed'
        self.assertNotEqual(item, cache.get(99))
        with mock.patch.object(rt.time, 'monotonic', return_value=time.monotonic()+10):
            self.assertIsNone(cache.get(99))

    def test_low_or_unknown_memory_never_starts_work(self):
        with test_directory() as folder:
            for n, sample in enumerate([{'available_bytes': None, 'rss_bytes': None},
                                       {'available_bytes': 10, 'rss_bytes': 10},
                                       {'available_bytes': 512*rt.MIB, 'rss_bytes': 193*rt.MIB}]):
                governor = rt.Governor(Path(folder)/f'{n}.db', sample=lambda: sample)
                with self.assertRaises(rt.ResourceDeferred):
                    governor.admit('scan')
                self.assertIsNone(governor.owner)
                self.assertEqual('deferred', governor.status()['jobs'][0]['status'])

    def test_interrupted_work_backoff_survives_new_instance(self):
        with test_directory() as folder:
            path = Path(folder)/'jobs.db'
            old = rt.Governor(path, sample=healthy)
            old.admit('scan')
            new = rt.Governor(path, sample=healthy)
            self.assertEqual('interrupted', new.status()['jobs'][0]['status'])
            with self.assertRaises(rt.ResourceDeferred):
                new.admit('scan')

    def test_single_lane_and_nested_work_release(self):
        with test_directory() as folder:
            gov = rt.Governor(Path(folder)/'jobs.db', sample=healthy)
            gov.admit('scan')
            gov.admit('nested')
            errors = []
            def contender():
                try:
                    gov.admit('planner')
                except rt.ResourceDeferred:
                    errors.append(True)
            t = threading.Thread(target=contender)
            t.start(); t.join(2)
            self.assertEqual([True], errors)
            gov.finish(True)
            self.assertIsNotNone(gov.owner)
            gov.finish(False, 'failed scan')
            self.assertIsNone(gov.owner)
            self.assertEqual('failed', gov.status()['jobs'][0]['status'])

    def test_cgroup_headroom_is_stricter_than_host(self):
        with test_directory() as folder:
            root = Path(folder)
            (root/'self').mkdir()
            (root/'meminfo').write_text('MemAvailable: 800000 kB\nSwapFree: 0 kB\n')
            (root/'self/status').write_text('VmRSS: 1234 kB\n')
            (root/'memory.max').write_text(str(200*rt.MIB))
            (root/'memory.current').write_text(str(190*rt.MIB))
            result = rt.memory_sample(root, root)
            self.assertEqual(10*rt.MIB, result['available_bytes'])
            self.assertEqual(1234*1024, result['rss_bytes'])

    def test_bad_snapshot_preserves_last_good(self):
        snapshot = rt.Snapshot(limit=64)
        snapshot.publish({'good': True})
        before = snapshot.get()
        with self.assertRaises(rt.ResponseTooLarge):
            snapshot.publish({'data': 'x'*100})
        self.assertEqual(before[:2], snapshot.get()[:2])
        self.assertIn('limit', snapshot.get()[2])

    def test_real_http_bootstrap_not_ready_without_touching_database(self):
        snapshot = rt.Snapshot()
        server = rt.BoundedHTTPServer(('127.0.0.1', 0), hads4.Handler, workers=2)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        try:
            with mock.patch.object(hads4, 'managed_runtime', True), mock.patch.object(hads4, 'panel_snapshot', snapshot), \
                 mock.patch.object(hads4, 'db', side_effect=AssertionError('HTTP accessed DB')):
                for path, expected in [('/health', 200), ('/ready', 503), ('/api/first-officer', 503)]:
                    conn = http.client.HTTPConnection(*server.server_address, timeout=2)
                    conn.request('GET', path)
                    response = conn.getresponse()
                    response.read()
                    self.assertEqual(expected, response.status)
                    conn.close()
                snapshot.publish({'roots': [], 'health': {}})
                with mock.patch.object(hads4, 'governor', None):
                    self.assertEqual([], hads4.panel_read_model()['roots'])
                    self.assertFalse(hads4.panel_read_model()['snapshot_status']['stale'])
        finally:
            server.shutdown(); server.server_close(); worker.join(2)

    def test_overloaded_http_does_not_create_more_workers(self):
        server = rt.BoundedHTTPServer(('127.0.0.1', 0), hads4.Handler, workers=1)
        request = mock.Mock()
        server.slots.acquire()
        try:
            server.process_request(request, ('127.0.0.1', 0))
            self.assertIn(b'503 Service Unavailable', request.sendall.call_args.args[0])
            request.close.assert_called_once()
        finally:
            server.slots.release(); server.server_close()


class CacheContractTests(unittest.TestCase):
    def test_stable_prefix_and_supported_capabilities(self):
        body = {'model': 'gpt-6-astra', 'instructions': 'Safety rules',
                'input': [{'role': 'developer', 'content': 'Stable architecture'}, {'role': 'user', 'content': 'Incident A'}]}
        first = ai_context.prepare(body)
        body['input'][1]['content'] = 'Incident B'
        second = ai_context.prepare(body)
        self.assertEqual(first['input'][0], second['input'][0])
        self.assertEqual({'mode': 'explicit', 'ttl': '30m'}, first['prompt_cache_options'])
        self.assertNotIn('instructions', first)
        self.assertNotIn('prompt_cache_options', ai_context.prepare(body, 'implicit'))
        body['model'] = 'unknown-family'
        unknown = ai_context.prepare(body)
        self.assertEqual('unknown-family', unknown['model'])
        self.assertNotIn('prompt_cache_options', unknown)


class MeteringTests(unittest.TestCase):
    setUp = legacy.RC8RegressionTests.setUp
    tearDown = legacy.RC8RegressionTests.tearDown
    _case_and_plan = legacy.RC8RegressionTests._case_and_plan

    def test_panel_does_not_duplicate_full_incident_evidence(self):
        _, _, root = self._case_and_plan()
        large = json.dumps({'raw': 'x'*(1024*1024)})
        with hads4.db() as conn:
            conn.execute('UPDATE root_cases SET evidence_json=?,research_json=? WHERE id=?', (large, large, root))
        panel = hads4.first_officer().command_center()
        self.assertLess(len(json.dumps(panel)), 30000)
        detail = hads4.first_officer().root_case(root)
        self.assertEqual(1024*1024, len(detail['evidence']['raw']))

    def test_cache_usage_saved_and_identical_request_not_rebilled(self):
        send = mock.Mock(return_value={'status': 'completed', 'usage': {'input_tokens': 3000, 'output_tokens': 500,
                                      'input_tokens_details': {'cached_tokens': 2000, 'cache_write_tokens': 1000}}})
        cfg = {'ai_paid_calls_enabled': True}
        body = {'model': 'gpt-6-astra', 'input': 'same evidence'}
        workflow.metered_call(hads4.db, hads4.now_utc, cfg, 1, 'test', body, send)
        workflow.initialize(hads4.db, hads4.now_utc)
        with self.assertRaises(workflow.AIBudgetExhausted):
            workflow.metered_call(hads4.db, hads4.now_utc, cfg, 1, 'test', body, send)
        send.assert_called_once()
        with hads4.db() as conn:
            row = conn.execute('SELECT * FROM ai_calls').fetchone()
        self.assertEqual(2000, row['cached_tokens'])
        self.assertEqual(1000, row['cache_write_tokens'])


class ConnectorTests(unittest.TestCase):
    def test_sse_stops_at_our_response_not_at_stream_end(self):
        stream = io.BytesIO(b': keep-alive\n\ndata: {"method":"notifications/progress"}\n\ndata: {"id":12,"result":{"ok":true}}\n\ndata: THIS MUST NOT BE READ\n')
        self.assertEqual({'id': 12, 'result': {'ok': True}}, rt.read_sse_response(stream, 12))
        self.assertIn(b'THIS MUST NOT BE READ', stream.read())

    def test_sse_wrong_id_or_over_limit_never_becomes_evidence(self):
        with self.assertRaises(ValueError):
            rt.read_sse_response(io.BytesIO(b'data: {"id":11,"result":{}}\n\n'), 12)
        with self.assertRaises(rt.ResponseTooLarge):
            rt.read_sse_response(io.BytesIO(b'data: '+b'x'*100), 12, limit=32)

    def test_mcp_negotiated_version_on_follow_up_requests(self):
        bus = self.bus()
        bus._mcp_sessions = {}
        bus._mcp_versions = {'ha_mcp': '2025-11-25'}
        bus._http_json = mock.Mock(side_effect=lambda *a, **k: ({'id': k['payload']['id'], 'result': {}}, {}))
        bus._mcp_rpc('ha_mcp', 'http://example.invalid/mcp', 'tools/list')
        self.assertEqual('2025-11-25', bus._http_json.call_args.kwargs['extra_headers']['MCP-Protocol-Version'])
    def bus(self):
        bus = ToolAdapterBus.__new__(ToolAdapterBus)
        bus.options = lambda: {}
        bus.now = lambda: '2026-09-23T12:00:00+00:00'
        bus._http_last_good = rt.ByteCache()
        bus._http_transport = {}
        return bus

    def test_etag_revalidates_existing_payload(self):
        bus = self.bus()
        url = 'http://example.invalid/api/v1/inspection'
        value = {'schema_version': 2, 'automations': []}
        bus._http_last_good[url] = (value, {'etag': '"revision1"'}, 'old')
        error = urllib.error.HTTPError(url, 304, 'Not Modified', {}, io.BytesIO(b''))
        with mock.patch('urllib.request.urlopen', side_effect=error) as send:
            data, headers = bus._http_json(url)
        self.assertEqual(value, data)
        self.assertEqual('"revision1"', send.call_args.args[0].get_header('If-none-match'))
        self.assertFalse(bus._http_transport[url]['stale'])

    def test_unknown_inspector_schema_is_not_healthy_empty_report(self):
        bus = self.bus()
        bus._json_connector = lambda *args: {'schema_version': 99, 'automations': []}
        data, error = bus._auto_json_connector('automation_inspector', 'http://example.invalid/', '')
        self.assertIsNone(data)
        self.assertIn('schématu', error)

    def test_availability_reliability_is_context_not_a_new_fault(self):
        history = {'entity_id': 'sensor.entity_availability_mtbf', 'attributes': {'per_device': {
            'light.desk': {'mtbf_hours': 50, 'mttr_minutes': 4, 'offline_events': 3}}}}
        self.assertEqual([], ToolAdapterBus._entity_availability_findings([history]))
        problem = {'entity_id': 'sensor.entity_availability_offline', 'state': '1', 'attributes': {'entities': ['light.desk']}}
        findings = ToolAdapterBus._entity_availability_findings([problem, history])
        self.assertEqual(1, len(findings))
        self.assertEqual(50, findings[0]['evidence']['reliability_history']['mtbf_hours'])

    def test_haghs_current_recommendation_has_human_label(self):
        findings = ToolAdapterBus._haghs_findings([{'entity_id': 'sensor.haghs_score', 'state': '60',
                                                   'attributes': {'rec_ram_pressure': True}}])
        self.assertTrue(findings)
        self.assertIn('paměť', json.dumps(findings, ensure_ascii=False))


class InstallerTests(unittest.TestCase):
    def test_native_agent_selection_excludes_local_backup(self):
        agents = [{'agent_id': 'hassio.local'}, {'agent_id': 'onedrive.account'}]
        self.assertEqual('onedrive.account', native_backup.select_agent(agents))
        with self.assertRaises(RuntimeError):
            native_backup.select_agent(agents, 'hassio.local')

    def test_hash_or_size_mismatch_blocks_install(self):
        install_guard.verify_digest(('abc', 123), ('abc', 123))
        for actual in [('def', 123), ('abc', 124)]:
            with self.assertRaises(RuntimeError):
                install_guard.verify_digest(('abc', 123), actual)

    def test_missing_or_ambiguous_agent_is_not_local_backup_fallback(self):
        for agents in [[], [{'agent_id': 'hassio.local'}], [{'agent_id': 'onedrive.a'}, {'agent_id': 'onedrive.b'}]]:
            with self.assertRaises(RuntimeError):
                native_backup.select_agent(agents)

    def test_catalog_update_is_not_a_rebuild(self):
        answers = [{}, {'version_latest': '5.0.0-rc1', 'version': '4.7.0-rc6'},
                   {'version': '4.7.0-rc6'}, {}, {'version': '5.0.0-rc1'}, {}]
        with mock.patch.object(install_guard, 'supervisor', side_effect=answers) as api:
            install_guard.catalog_update('5.0.0-rc1', True)
        paths = [call.args[0] for call in api.call_args_list]
        self.assertIn('/store/addons/local_hads4/update', paths)
        api.assert_any_call('/store/addons/local_hads4/update', {'background': False, 'backup': False})
        self.assertFalse(any('rebuild' in path for path in paths))

    def test_catalog_mismatch_cannot_update(self):
        with mock.patch.object(install_guard, 'supervisor', side_effect=[{}, {'version_latest': 'wrong'}]) as api:
            with self.assertRaises(RuntimeError):
                install_guard.catalog_update('5.0.0-rc1', True)
        self.assertEqual(2, api.call_count)
