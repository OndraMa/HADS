"""RC4 live failures: durable collector receipt and no network in writer lane."""
import copy
import json
import threading
import unittest
from unittest import mock

import hads4
import test_rc8_regressions as legacy


class CollectorRepairTests(unittest.TestCase):
    def setUp(self):
        self.prior_runtime = copy.deepcopy(hads4.runtime)
        legacy.RC8RegressionTests.setUp(self)
        hads4.runtime.pop('log_collection_test', None)
        hads4.runtime['running'] = False

    def tearDown(self):
        legacy.RC8RegressionTests.tearDown(self)
        hads4.runtime.clear()
        hads4.runtime.update(self.prior_runtime)

    def job(self):
        hads4.runtime['log_collection_test'] = {'job_id': 'probe', 'status': 'running', 'phase': 'import', 'current_source': 'host'}

    def test_exception_is_logged_saved_and_restored_without_database(self):
        self.job()
        with mock.patch.object(hads4, 'begin_task', return_value=True), mock.patch.object(hads4, 'end_task'), mock.patch.object(hads4, 'run_log_pass', side_effect=PermissionError('raw archive denied')), mock.patch.object(hads4, 'db', side_effect=AssertionError('journal must not use DB')), mock.patch.object(hads4, 'log') as logged:
            hads4._run_log_collection_test('probe')
        saved = json.loads((hads4.DATA_DIR / 'last_log_collection_test.json').read_text(encoding='utf-8'))
        self.assertEqual('failed', saved['status'])
        self.assertEqual('PermissionError', saved['error_type'])
        self.assertIn('denied', saved['message'])
        self.assertIn('host', logged.call_args.args[0])
        hads4.runtime.pop('log_collection_test')
        hads4.restore_log_collection_test()
        self.assertEqual(saved['message'], hads4.log_collection_test_status('probe')['message'])
        self.assertEqual('unknown', hads4.log_collection_test_status('other')['status'])

    def test_running_receipt_becomes_interrupted_after_restart(self):
        self.job()
        hads4.log_collection_progress(completed_sources=3)
        hads4.runtime.pop('log_collection_test')
        hads4.restore_log_collection_test()
        self.assertEqual('interrupted', hads4.log_collection_test_status()['status'])
        self.assertEqual(3, hads4.log_collection_test_status()['completed_sources'])
        self.assertEqual('interrupted', json.loads((hads4.DATA_DIR / 'last_log_collection_test.json').read_text(encoding='utf-8'))['status'])

    def test_partial_sources_are_retained_and_url_secrets_removed(self):
        self.job()
        result = {'collection_state': 'partial', 'sources': 2, 'attempted_sources': 3,
                  'failed_sources': [{'name': 'host', 'required': True, 'error': 'failed http://secret.example/mcp/topsecret'}]}
        with mock.patch.object(hads4, 'begin_task', return_value=True), mock.patch.object(hads4, 'end_task'), mock.patch.object(hads4, 'run_log_pass', return_value=result):
            hads4._run_log_collection_test('probe')
        status = hads4.log_collection_test_status()
        self.assertEqual('partial', status['status'])
        self.assertEqual(2, status['sources'])
        self.assertNotIn('topsecret', json.dumps(status))
        self.assertTrue(status['failed_sources'][0]['required'])

    def test_admission_refusal_is_deferred_and_does_not_run_collection(self):
        self.job()
        with mock.patch.dict(hads4.runtime, {'deferred_reason': 'Málo RAM'}), mock.patch.object(hads4, 'begin_task', return_value=False), mock.patch.object(hads4, 'end_task') as end, mock.patch.object(hads4, 'run_log_pass') as run:
            hads4._run_log_collection_test('probe')
        self.assertEqual('deferred', hads4.log_collection_test_status()['status'])
        run.assert_not_called()
        end.assert_not_called()

    def test_receipt_failure_is_explicit_and_previous_receipt_survives(self):
        self.job()
        hads4.log_collection_progress(message='previous')
        with mock.patch.object(hads4.os, 'replace', side_effect=PermissionError('no write')):
            hads4.log_collection_progress(message='new')
        self.assertIn('no write', hads4.log_collection_test_status()['persistence_error'])
        self.assertEqual('previous', json.loads((hads4.DATA_DIR / 'last_log_collection_test.json').read_text(encoding='utf-8'))['message'])
        self.assertEqual([], list(hads4.DATA_DIR.glob('*.tmp')))

    def test_thread_start_failure_is_saved(self):
        with mock.patch.object(hads4.threading.Thread, 'start', side_effect=RuntimeError('cannot start')):
            with self.assertRaises(RuntimeError):
                hads4.start_log_collection_test()
        self.assertEqual('failed', hads4.log_collection_test_status()['status'])
        self.assertTrue((hads4.DATA_DIR / 'last_log_collection_test.json').exists())

    def test_dashboard_reads_while_writer_is_busy(self):
        entered, release = threading.Event(), threading.Event()
        def writer():
            with hads4.db() as conn:
                conn.execute("INSERT INTO settings VALUES('held','1')")
                entered.set()
                release.wait(4)
        worker = threading.Thread(target=writer)
        worker.start()
        try:
            self.assertTrue(entered.wait(2))
            with mock.patch.object(hads4.tool_bus(), 'health_scores', return_value={}):
                snapshot = hads4.dashboard_snapshot()
            self.assertIn('score', snapshot)
            self.assertTrue(worker.is_alive(), 'Read-only dashboard queued behind a writer')
        finally:
            release.set()
            worker.join(5)

    def test_recovery_network_call_does_not_hold_writer_and_revalidates(self):
        with hads4.db() as conn:
            conn.execute("INSERT INTO entity_runtime(entity_id,condition_state,recovered_at,first_seen,last_changed) VALUES('light.probe','VERIFYING','2020-01-01T00:00:00+00:00','2020-01-01T00:00:00+00:00','2020-01-01T00:00:00+00:00')")
        def fresh(*args, **kwargs):
            done = threading.Event()
            def observe():
                with hads4.db() as conn:
                    conn.execute("UPDATE entity_runtime SET condition_state='OFFLINE' WHERE entity_id='light.probe'")
                done.set()
            worker = threading.Thread(target=observe)
            worker.start()
            self.assertTrue(done.wait(2), 'Network call held the writer lane')
            worker.join(3)
            return {'entity_id': 'light.probe', 'state': 'on'}
        with mock.patch.object(hads4, 'supervisor_request', side_effect=fresh):
            self.assertEqual(0, hads4.verify_recoveries()['verified'])
        with hads4.db_read() as conn:
            self.assertEqual('OFFLINE', conn.execute("SELECT condition_state FROM entity_runtime WHERE entity_id='light.probe'").fetchone()[0])

    def test_diagnostic_export_survives_unavailable_source_database(self):
        self.job()
        with mock.patch.object(hads4, 'log_source_overview', side_effect=RuntimeError('DB unavailable')):
            export = hads4.collector_diagnostics()
        self.assertEqual('probe', export['log_collection_test']['job_id'])
        self.assertIn('DB unavailable', export['log_sources_error'])

    def test_export_is_bounded_snapshot_not_mutable_job_reference(self):
        self.job()
        value = hads4.log_collection_test_status()
        value['message'] = 'changed by caller'
        self.assertNotIn('message', hads4.runtime['log_collection_test'])

    def test_success_is_persisted_with_source_counts(self):
        self.job()
        with mock.patch.object(hads4, 'begin_task', return_value=True), mock.patch.object(hads4, 'end_task') as end, mock.patch.object(hads4, 'run_log_pass', return_value={'collection_state':'complete', 'sources':18, 'attempted_sources':18}):
            hads4._run_log_collection_test('probe')
        saved = json.loads((hads4.DATA_DIR / 'last_log_collection_test.json').read_text(encoding='utf-8'))
        self.assertEqual('complete', saved['status'])
        self.assertEqual(18, saved['sources'])
        end.assert_called_once_with(True)

    def test_source_export_removes_authentication_urls(self):
        with mock.patch.object(hads4, 'log_source_overview', return_value=[{'name':'core','last_error':'failed https://host/mcp/private-secret?token=123'}]):
            export = hads4.collector_diagnostics()
        self.assertNotIn('private-secret', json.dumps(export))
        self.assertIn('[URL skryta]', export['log_sources'][0]['last_error'])

    def test_successful_publication_survives_optional_timestamp_deferral(self):
        with mock.patch.object(hads4, 'options', return_value={'ha_dashboard_enabled':True}), mock.patch.object(hads4, 'dashboard_snapshot', return_value={}), mock.patch.object(hads4, 'dashboard_entity_payloads', return_value={'sensor.probe':{'state':'1'}}), mock.patch.object(hads4, 'supervisor_request') as publish, mock.patch.object(hads4, 'export_dashboard_card', return_value=None), mock.patch.object(hads4, 'set_setting', side_effect=hads4.runtime_core.ResourceDeferred('writer busy')):
            result = hads4.publish_ha_dashboard()
        self.assertTrue(result['ok'])
        self.assertEqual(1, result['published'])
        self.assertIsNone(hads4.runtime['last_dashboard_error'])
        self.assertTrue(hads4.runtime['last_dashboard_publish'])
        publish.assert_called_once()


if __name__ == '__main__':
    unittest.main()
