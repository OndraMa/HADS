"""Offline regressions from the user's 15 October evidence. No paid calls."""
import datetime as dt
import json
import unittest
from unittest import mock

import diagnostic_policy as policy
import functional_focus as focus
import hads4
import mcp_diagnostics as mcp
import runtime_core as rt
import test_rc8_regressions as legacy
from test_502_mcp import bus_with, tool
from test_500_runtime import test_directory, healthy
from pathlib import Path


class PolicyTests(unittest.TestCase):
    def test_dns_icloud_auth_and_phone_name_are_distinct(self):
        cases = [('plugin/errors: 2 p130-fmipweb.icloud.com A: dial tcp 1.0.0.1:853: i/o timeout', 'dns_timeout'),
                 ('pyicloud.exceptions.PyiCloudFailedLoginException: Invalid authentication token.', 'icloud_auth'),
                 ('icloud: Authentication required for Account (421)', 'icloud_auth'),
                 ('icloud.play_sound: no device with name Old Phone', 'icloud_target'),
                 ('icloud: Error fetching reminders Request failed', 'icloud_unknown'),
                 ('Supervisor ingress HTTP 403 Forbidden', 'ingress_permission')]
        for value, expected in cases:
            self.assertEqual(expected, policy.explanation(value)['kind'])
        self.assertEqual('technical', focus.classify({'title': cases[0][0]})['lane'])
        self.assertEqual('action', focus.classify({'title': cases[0][0], 'decision_state': 'repair_failed'})['lane'])

    def test_source_rules_do_not_blame_phone_for_dns_or_auth(self):
        for message in ('plugin/errors: 2 setup.icloud.com A: dial tcp 1.1.1.1:853: i/o timeout',
                        'pyicloud: Invalid authentication token.'):
            value = hads4.rule_analysis('dns', message, 'ERROR', 'system')
            self.assertNotIn('Jednou z ověřovaných', value['cause'])
            self.assertNotIn('Příčina zatím nebyla', value['cause'])

    def test_masked_ids_and_traceback_filenames_are_not_entities(self):
        value = 'automation.good failed /usr/lib/script.py media_player.hom**** script.py light.desk'
        self.assertEqual(['automation.good', 'light.desk'], mcp.entity_ids(value))
        self.assertEqual([], mcp.entity_ids('light.mask*** sensor.name.json custom_components.meross_lan'))
        investigator = mock.Mock()
        result = focus.collect({'title': 'script.py media_player.hom****'}, investigator, '2026-10-15T10:00:00Z')
        self.assertEqual([], result['targets'])
        investigator.live_state.assert_not_called()
        self.assertEqual('technical', focus.classify({'title':'Traceback File /usr/lib/script.py line <LINE>'})['lane'])

    def test_runtime_deferral_names_job_deadline_and_reason(self):
        with test_directory() as folder:
            gov = rt.Governor(Path(folder)/'runtime.db', sample=healthy)
            gov.defer('planner', 'Předchozí běh přerušen.', 60)
            with self.assertRaises(rt.ResourceDeferred) as exc:
                gov.admit('planner')
            self.assertIn('planner čeká do', str(exc.exception))
            self.assertIn('Předchozí běh přerušen.', str(exc.exception))
            self.assertTrue(gov.status()['jobs'][0]['cooldown_active'])

    def test_disabled_ai_is_not_a_spending_limit(self):
        self.assertEqual('disabled', policy.ai_defer_kind('Placená AI je bezpečnostně vypnutá.'))
        self.assertEqual('duplicate', policy.ai_defer_kind('Stejný AI požadavek již byl odeslán.'))
        self.assertEqual('budget', policy.ai_defer_kind('Dosažen limit AI požadavků.'))


class MCPTests(unittest.TestCase):
    def test_schema_bound_compact_search_and_paginated_candidate_reads(self):
        props = {'query': {'type':'string'}, 'limit': {'type':'integer'}, 'include_config': {'type':'boolean'},
                 'include_attributes': {'type':'boolean'}, 'fields': {'type':'array','items':{'type':'string'}},
                 'result_fields': {'type':'array','items':{'type':'string'}}}
        catalog = [tool('ha_search', props, ['query']),
                   tool('ha_get_state', {'entity_id':{'type':'string'}}, ['entity_id']),
                   tool('ha_get_entity', {'entity_id':{'type':'string'}}, ['entity_id']),
                   tool('ha_get_history', {'entity_ids':{'type':'array','items':{'type':'string'}}}, ['entity_ids'])]
        payload = {'structuredContent': {'success':True, 'has_more':True, 'entities':[{'entity_id':'light.desk'}]}}
        calls=[]
        def rpc(a,u,m,p):
            calls.append(p)
            return payload if p['name']=='ha_search' else {'state':'on'}
        bus=bus_with(catalog,rpc)
        result=bus._mcp_case_evidence('ha_mcp','Lampička neodpovídá',{'last_seen':'2026-10-14T20:00:00+02:00'})
        self.assertEqual(['ha_search','ha_get_state','ha_get_entity','ha_get_history'],[p['name'] for p in calls])
        self.assertEqual(3,calls[0]['arguments']['limit'])
        self.assertFalse(calls[0]['arguments']['include_config'])
        self.assertEqual('light.desk',calls[1]['arguments']['entity_id'])
        self.assertEqual('partial',result['coverage']['state'])

    def test_double_encoded_json_and_explicit_errors_are_safe(self):
        value={'content':[{'type':'text','text':json.dumps(json.dumps({'entities':[{'entity_id':'light.desk'}]}))}]}
        self.assertEqual(['light.desk'],mcp.search_entities(value))
        self.assertTrue(mcp.search_followup_safe(value))
        for flag in ('partial','truncated','errors'):
            self.assertFalse(mcp.search_followup_safe({'entities':[{'entity_id':'light.desk'}],flag:True}))
        error={'content':[{'type':'text','text':json.dumps(json.dumps({'success':False,'error':'no'}))}]}
        self.assertTrue(mcp.result_error(error))
        self.assertFalse(mcp.search_followup_safe(error))


class DatabaseTests(unittest.TestCase):
    setUp=legacy.RC8RegressionTests.setUp
    tearDown=legacy.RC8RegressionTests.tearDown
    _case_and_plan=legacy.RC8RegressionTests._case_and_plan

    def test_old_automatic_conclusion_cannot_hide_pending_plan(self):
        _,plan_id,root_id=self._case_and_plan()
        with hads4.db() as conn:
            conn.execute("UPDATE root_cases SET decision_state='review_ready' WHERE id=?",(root_id,))
        hads4.first_officer().rebuild_root_cases()
        root=hads4.first_officer().root_case(root_id)
        self.assertEqual('awaiting_decision',root['decision_state'])
        self.assertEqual(plan_id,root['repair_plan_id'])
        view=hads4.first_officer().command_center()
        self.assertEqual(0,view['approved_plans'])
        self.assertEqual([root_id],[r['id'] for r in view['repair_cases']])

    def test_nonactive_link_is_not_reported_as_missing_link(self):
        _,plan_id,root_id=self._case_and_plan()
        with hads4.db() as conn:
            conn.execute("UPDATE root_cases SET decision_state='ignored' WHERE id=?",(root_id,))
        plan=hads4.first_officer().command_center()['standalone_plans'][0]
        self.assertEqual(root_id,plan['linked_root_id'])
        self.assertEqual('ignored',plan['linked_root_state'])
        self.assertIn('je navázán',plan['visibility_note'])
        self.assertEqual(plan_id,plan['id'])

    def test_diagnostic_only_plan_is_not_presented_as_repair(self):
        _,plan_id,_=self._case_and_plan()
        with hads4.db() as conn:
            conn.execute("UPDATE repair_plans SET actions_json='[{\"type\":\"core_check\"}]' WHERE id=?",(plan_id,))
        hads4.first_officer().rebuild_root_cases()
        plan=hads4.first_officer().command_center()['standalone_plans'][0]
        self.assertFalse(plan['executable'])
        self.assertIn('neobsahuje vykonatelnou opravu',plan['visibility_note'])

    def test_dns_correlation_preserves_explicit_captain_choice(self):
        _,_,root_id=self._case_and_plan()
        officer=hads4.first_officer()
        officer.decide(root_id,'ignore','Nechci tento případ řešit.')
        before=officer.root_case(root_id)
        with mock.patch.object(officer,'_group_key',return_value='new-rule-must-not-revive'):
            officer.rebuild_root_cases()
        after=officer.root_case(root_id)
        self.assertEqual('ignored',after['decision_state'])
        self.assertEqual(before['fingerprint'],after['fingerprint'])

    def test_related_dns_lines_share_correlation_key_not_confirmed_cause(self):
        from first_officer import FirstOfficer
        values=['plugin/errors: 2 setup.icloud.com A: dial tcp 1.1.1.1:853: i/o timeout',
                'plugin/errors: 2 p130-fmipweb.icloud.com AAAA: read udp 127.0.0.1:30000->127.0.0.1:5553: i/o timeout']
        self.assertEqual(*[FirstOfficer._group_key({'normalized_message':v,'logger':'coredns'}) for v in values])

    def test_latest_batch_exposes_bounded_verification_failure(self):
        _,plan_id,_=self._case_and_plan()
        officer=hads4.first_officer()
        batch=officer.create_batch([plan_id],{})
        remote={'uploaded':True,'verified':False,'message':'Missing verifier',
                'verification_errors':['missing hads_rescue.verify'],'raw':'x'*rt.MIB}
        officer.update_batch(batch,status='blocked_remote_verify',last_error='Missing verifier',remote_verification_json=json.dumps(remote))
        value=officer.command_center()['latest_batch']
        self.assertEqual([plan_id],value['plan_ids'])
        self.assertEqual(['missing hads_rescue.verify'],value['remote_verification']['verification_errors'])
        self.assertNotIn('raw',value['remote_verification'])
        self.assertLess(len(json.dumps(value)),5000)

    def test_missing_verifier_is_explicit_and_does_not_open_gate(self):
        with mock.patch.object(hads4,'upload_onedrive_to',return_value={'ok':True}), \
             mock.patch.object(hads4,'resolve_onedrive_config_entry',return_value={'entry_id':'test'}), \
             mock.patch.object(hads4,'_onedrive_verifier_services',return_value=[]):
            result=hads4.upload_and_verify_rescue('fake-rescue.zip','HADS/Repairs')
        self.assertFalse(result['verified'])
        self.assertEqual('missing_verifier',result['failure_stage'])
        self.assertIn('hads_rescue.verify',result['message'])

    def test_disabled_ai_has_distinct_planner_state_and_counter(self):
        _,plan_id,root_id=self._case_and_plan()
        with hads4.db() as conn:
            conn.execute("UPDATE repair_plans SET status='cancelled' WHERE id=?",(plan_id,))
            conn.execute("UPDATE root_cases SET repair_plan_id=NULL,decision_state='investigating' WHERE id=?",(root_id,))
        bus=mock.Mock()
        bus.collect.return_value={'used':[]}
        result=hads4.first_officer().automatic_repair_planner(mock.Mock(),mock.Mock(),
            lambda *args:{'summary':'Local evidence','ai_deferred_reason':'Placená AI je bezpečnostně vypnutá.'},bus,root_ids=[root_id])
        self.assertEqual(1,result['ai_disabled'])
        self.assertEqual(0,result['ai_budget_deferred'])
        self.assertEqual('ai_disabled',hads4.first_officer().root_case(root_id)['planner_state'])
