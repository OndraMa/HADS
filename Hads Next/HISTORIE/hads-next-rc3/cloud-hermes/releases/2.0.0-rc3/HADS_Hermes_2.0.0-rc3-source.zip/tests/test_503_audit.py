"""Regression cases from the real 3 October audit. Offline, no paid calls."""
import datetime as dt
import json
import sqlite3
import threading
import unittest
from contextlib import ExitStack
from unittest import mock

import hads4
import test_rc8_regressions as legacy
from tool_adapters import ToolAdapterBus


class AuditRegressionTests(unittest.TestCase):
    setUp = legacy.RC8RegressionTests.setUp
    tearDown = legacy.RC8RegressionTests.tearDown
    _case_and_plan = legacy.RC8RegressionTests._case_and_plan

    def test_read_snapshot_does_not_wait_for_writer_or_see_uncommitted_data(self):
        with hads4.db() as conn:
            conn.execute("INSERT INTO settings VALUES('read_probe','old')")
        started, release = threading.Event(), threading.Event()
        def writer():
            with hads4.db() as conn:
                conn.execute("UPDATE settings SET value='new' WHERE key='read_probe'")
                started.set()
                release.wait(3)
        worker = threading.Thread(target=writer)
        worker.start()
        try:
            self.assertTrue(started.wait(2))
            self.assertEqual('old', hads4.get_setting('read_probe'))
            with hads4.db_read() as conn:
                with self.assertRaises(sqlite3.OperationalError):
                    conn.execute("DELETE FROM settings")
        finally:
            release.set(); worker.join(3)
        self.assertFalse(worker.is_alive())
        self.assertEqual('new', hads4.get_setting('read_probe'))

    def test_nested_read_observes_own_transaction(self):
        with hads4.db() as conn:
            conn.execute("INSERT INTO settings VALUES('nested_probe','new')")
            self.assertEqual('new', hads4.get_setting('nested_probe'))

    def test_entire_panel_snapshot_reads_while_writer_waits(self):
        self._case_and_plan()
        bus=hads4.tool_bus()
        entered, release=threading.Event(), threading.Event()
        def writer():
            with hads4.db() as conn:
                conn.execute("INSERT INTO settings VALUES('panel_writer_probe','new')")
                entered.set(); release.wait(5)
        worker=threading.Thread(target=writer)
        worker.start()
        try:
            self.assertTrue(entered.wait(2))
            with mock.patch.object(bus,'health_scores',return_value={}):
                panel=hads4.first_officer_command_center()
            self.assertEqual(1,panel['prepared_plan_count'])
            self.assertTrue(worker.is_alive(), 'Panel read waited for the writer instead of using WAL')
            self.assertFalse(panel['batch_checklist']['runnable'])
        finally:
            release.set(); worker.join(3)
        self.assertFalse(worker.is_alive())

    def test_yaml_processing_does_not_own_writer_and_flush_is_bounded(self):
        with hads4.AuditStatements() as conn:
            results = []
            def unrelated_write():
                hads4.set_setting('concurrent_probe', 'ok')
                results.append(True)
            worker = threading.Thread(target=unrelated_write)
            worker.start(); worker.join(2)
            self.assertEqual([True], results)
            self.assertIsNone(conn.execute('SELECT sha256 FROM yaml_files WHERE path=?', ('missing.yaml',)).fetchone())
            for index in range(120):
                conn.execute('INSERT INTO settings(key,value) VALUES(?,?)', (f'audit_{index}', '1'))
                self.assertLess(len(conn.pending), 50)
            # The deferred change event does not claim an immediate row id.
            self.assertIsNone(hads4.insert_system_event(conn, 'config_change', 'changed', hads4.now_utc(), 'test'))
        with hads4.db_read() as conn:
            self.assertEqual(120, conn.execute("SELECT count(*) FROM settings WHERE key LIKE 'audit_%'").fetchone()[0])

    def test_stage_failure_is_visible_and_next_stage_runs(self):
        errors = {}
        with mock.patch.object(hads4, 'diagnostic_progress') as progress:
            result = hads4.diagnostic_stage('yaml', lambda: (_ for _ in ()).throw(ValueError('bad yaml')), errors)
            self.assertFalse(result['ok'])
            self.assertEqual('bad yaml', errors['yaml'])
            self.assertEqual(42, hads4.diagnostic_stage('planner', lambda: 42, errors))
            self.assertEqual('planner', progress.call_args.kwargs['phase'])

    def test_independent_investigation_starts_without_completed_deep_audit(self):
        with mock.patch.object(hads4, 'options', return_value={}), mock.patch.object(hads4, 'get_setting', return_value=None), mock.patch.object(hads4, 'tool_bus', return_value='bus'), mock.patch.object(hads4, 'start_planner_worker', return_value={'status':'running'}) as worker:
            self.assertEqual('running', hads4.investigation_tick()['status'])
            worker.assert_called_once_with('bus')

    def test_recent_cycle_does_not_start_again(self):
        with mock.patch.object(hads4, 'options', return_value={}), mock.patch.object(hads4, 'get_setting', return_value=json.dumps({'finished_at':hads4.now_utc()})), mock.patch.object(hads4, 'start_planner_worker') as worker:
            self.assertEqual('not_due', hads4.investigation_tick()['status'])
            worker.assert_not_called()

    def test_standalone_plan_count_matches_footer(self):
        _, plan, root = self._case_and_plan()
        with hads4.db() as conn:
            conn.execute("UPDATE root_cases SET repair_plan_id=NULL,decision_state='investigating' WHERE id=?", (root,))
        value = hads4.first_officer().command_center()
        self.assertEqual(0, len(value['repair_cases']))
        self.assertEqual(1, value['prepared_plan_count'])
        self.assertEqual(value['executable_plans'], value['prepared_plan_count'])
        self.assertEqual(plan, value['standalone_plans'][0]['id'])

    def test_connection_expiry_does_not_remove_observed_installation(self):
        with hads4.db() as conn:
            conn.execute("INSERT INTO tool_adapters(adapter_id,title,discovery_json,updated_at) VALUES(?,?,?,?)", ('spook','Spook',json.dumps({'installed':True,'current_presence':'confirmed','running':True,'connection_verified':True}), '2026-09-01T00:00:00+00:00'))
        bus = ToolAdapterBus(hads4.db, hads4.now_utc, None, None, None)
        row = bus.status()[0]['discovery']
        self.assertEqual('confirmed', row['current_presence'])
        self.assertTrue(row['installed'])
        self.assertFalse(row['connection_verified'])
        self.assertFalse(row['running_currently_verified'])

    def test_local_explanation_and_impact_are_specific(self):
        message = 'Cannot connect to host registry.hub.docker.com:443 Timeout while contacting DNS servers'
        value = hads4.rule_analysis('homeassistant.components.version', message, 'ERROR', 'home_assistant')
        self.assertIn('DNS', value['title'])
        self.assertIn('nikoli', value['cause'])
        self.assertEqual(18, hads4.case_impact_profile({'logger':'homeassistant.components.version','normalized_message':message})[0])
        phone = hads4.rule_analysis('websocket_api', 'No device with name alcaiphone', 'ERROR', 'home_assistant')
        self.assertEqual('P2', phone['priority'])
        self.assertIn('totožnosti', phone['solution'])

    def test_collector_test_is_not_full_quick_pipeline(self):
        hads4.runtime['log_collection_test'] = {'job_id':'probe','status':'running'}
        with mock.patch.object(hads4, 'begin_task', return_value=True), mock.patch.object(hads4, 'end_task') as end, mock.patch.object(hads4, 'run_quick_scan', side_effect=AssertionError('wrong pipeline')), mock.patch.object(hads4, 'run_log_pass', return_value={'collection_state':'partial','failed_sources':[{'name':'audio'}]}):
            hads4._run_log_collection_test('probe')
        self.assertEqual('partial', hads4.runtime['log_collection_test']['status'])
        end.assert_called_once_with(False)

    def test_db_score_reports_contention_and_old_planner(self):
        with mock.patch.dict(hads4.db_diagnostics, {'timeouts':3,'last_timeout_at':hads4.now_utc()}), mock.patch.object(hads4, 'observer_snapshot', return_value={}):
            score = hads4.hads_health_breakdown([])['components']
        self.assertEqual(25, score['database']['score'])
        self.assertEqual(0, score['planner']['score'])
        self.assertIn('neprokazuje', score['database']['detail'])

    def test_partial_deep_audit_still_attempts_investigation_and_keeps_success_age(self):
        names = ('capture_metrics','collect_inventory','collect_external_diagnostics',
                 'refresh_new_occurrence_contexts','update_recurrence_and_fixes','recalculate_smart_priorities',
                 'build_correlations','build_dependency_graph','refresh_knowledge_base','verify_recoveries',
                 'cleanup','notify_urgent_cases','export_cases','publish_ha_dashboard')
        with ExitStack() as stack:
            stack.enter_context(mock.patch.dict(hads4.runtime, {'last_scan':'previous-success','last_deep_audit':'previous-success'}))
            stack.enter_context(mock.patch.object(hads4,'options',return_value={'yaml_audit_enabled':True,'daily_chatgpt_report':False,'onedrive_enabled':False}))
            stack.enter_context(mock.patch.object(hads4,'begin_task',return_value=True))
            stack.enter_context(mock.patch.object(hads4,'end_task'))
            for name in names:
                stack.enter_context(mock.patch.object(hads4,name,return_value={}))
            stack.enter_context(mock.patch.object(hads4,'tool_bus',return_value='bus'))
            stack.enter_context(mock.patch.object(hads4,'run_log_pass',return_value={'ok':True,'collection_state':'complete'}))
            stack.enter_context(mock.patch.object(hads4,'run_yaml_audit',side_effect=RuntimeError('YAML stage failure')))
            officer=stack.enter_context(mock.patch.object(hads4,'rebuild_first_officer',return_value={}))
            result=hads4.run_deep_audit('test')
            self.assertFalse(result['ok'])
            self.assertEqual('YAML stage failure',result['stage_errors']['yaml'])
            officer.assert_called_once_with(True,'bus')
            self.assertEqual('previous-success',hads4.runtime['last_deep_audit'])
            self.assertEqual('partial',hads4.runtime['diagnostic_job']['status'])
            self.assertIn('job_id',hads4.runtime['diagnostic_job'])

    def test_restart_marks_running_diagnostic_interrupted_not_completed(self):
        hads4.set_setting('last_diagnostic_job',json.dumps({'job_id':'restart-probe','status':'running','phase':'yaml'}))
        with mock.patch.object(hads4,'refresh_known_explanations'), mock.patch.object(hads4,'recalculate_smart_priorities'), mock.patch.object(hads4,'first_officer') as officer, mock.patch.object(hads4,'export_dashboard_card'):
            hads4.initialize_runtime()
        job=json.loads(hads4.get_setting('last_diagnostic_job'))
        self.assertEqual('restart-probe',job['job_id'])
        self.assertEqual('interrupted',job['status'])

    def test_incomplete_import_is_retried_not_treated_as_unchanged(self):
        message='2026-10-03 11:00:00 ERROR (MainThread) [test] sample error'
        with mock.patch.object(hads4,'ingest_event',side_effect=RuntimeError('interrupted')):
            with self.assertRaises(RuntimeError):
                hads4.import_text('core',message,'supervisor')
        with hads4.db_read() as conn:
            self.assertEqual(-1,conn.execute('SELECT parsed_events FROM imports').fetchone()[0])
        self.assertEqual(1,hads4.import_text('core',message,'supervisor')['new_occurrences'])
        self.assertEqual(1,hads4.import_text('core',message,'supervisor')['unchanged'])

    def test_old_log_source_is_not_presented_as_current_ok(self):
        hads4.update_collector_source('addon__removed',True,kind='addon_log')
        with hads4.db() as conn:
            conn.execute("UPDATE collector_sources SET last_ok_at='2026-09-01T00:00:00+00:00'")
        self.assertEqual('historical_not_rechecked',hads4.log_source_overview()[0]['status'])
