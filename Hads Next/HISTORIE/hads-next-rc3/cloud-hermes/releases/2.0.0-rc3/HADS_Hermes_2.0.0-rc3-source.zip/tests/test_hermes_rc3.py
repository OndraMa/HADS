"""Offline contracts: persistent evidence, scoped source tools, no model billing."""
import json
import unittest
from unittest import mock

import hads4
import investigation_team as team
import music_mcp
import mcp_diagnostics as policy
from test_502_mcp import bus_with, tool
import test_rc8_regressions as legacy


class TeamTests(unittest.TestCase):
    setUp = legacy.RC8RegressionTests.setUp
    tearDown = legacy.RC8RegressionTests.tearDown

    def run_step(self, value, role='devices'):
        return team.run(hads4.db, hads4.now_utc, 123, role, lambda: value, lambda x: x)

    def test_persisted_steps_are_not_diagnostic_conclusions(self):
        receipt = self.run_step({'state': 'on'})
        self.assertEqual('completed', receipt['status'])
        rows = team.latest(hads4.db_read, [123])
        self.assertEqual(receipt, rows[0]['result'])
        self.assertNotIn('result_json', rows[0])
        self.assertIn('není potvrzení', receipt['note'])

    def test_collection_time_change_does_not_create_independent_evidence(self):
        first = self.run_step({'state': 'on', 'fetched_at': 'old'})
        second = self.run_step({'state': 'on', 'fetched_at': 'new'})
        self.assertEqual(first['id'], second['same_evidence_as'])
        changed = self.run_step({'state': 'off'})
        self.assertIsNone(changed['same_evidence_as'])

    def test_real_event_time_is_not_erased_from_identity(self):
        self.run_step({'event_at': 'old'})
        self.assertIsNone(self.run_step({'event_at': 'new'})['same_evidence_as'])

    def test_partial_and_missing_evidence_never_claim_complete(self):
        for value in ({'available': False}, {'nested': {'error': 'timeout'}},
                      {'coverage_gaps': ['trace missing']}, {'status': 'partial'}):
            self.assertEqual('partial', self.run_step(value)['status'])

    def test_oversized_evidence_is_explicitly_incomplete(self):
        result = self.run_step({'log': 'x'*25000})
        self.assertEqual('partial', result['status'])
        self.assertTrue(result['result']['truncated'])

    def test_failure_is_redacted_before_persistence(self):
        def fail():
            raise ValueError('secret-token')
        value = team.run(hads4.db, hads4.now_utc, 123, 'logs', fail, lambda x: str(x).replace('secret-token', '[redacted]'))
        self.assertEqual('failed', value['status'])
        self.assertNotIn('secret-token', json.dumps(team.latest(hads4.db_read, [123])))

    def test_failed_redactor_does_not_persist_raw_secret(self):
        def fail():
            raise ValueError('secret-token')
        result = team.run(hads4.db, hads4.now_utc, 123, 'logs', fail, fail)
        self.assertEqual('failed', result['status'])
        self.assertNotIn('secret-token', json.dumps(team.latest(hads4.db_read, [123])))

    def test_restart_marks_in_progress_interrupted_only(self):
        done = self.run_step({'state': 'on'})
        with hads4.db() as conn:
            conn.execute("INSERT INTO specialist_runs(case_id,role,status,created_at) VALUES(123,'logs','running','test')")
        team.initialize(hads4.db, hads4.now_utc)
        rows = team.latest(hads4.db_read, [123])
        self.assertEqual('interrupted', rows[0]['status'])
        self.assertEqual('completed', rows[1]['status'])
        self.assertEqual(done['id'], rows[1]['id'])

    def test_unknown_role_never_executes(self):
        function = mock.Mock()
        with self.assertRaises(ValueError):
            team.run(hads4.db, hads4.now_utc, 123, 'write', function, lambda x:x)
        function.assert_not_called()

    def test_hermes_can_read_one_source_and_no_unknown_source(self):
        case, _, _ = legacy.RC8RegressionTests._case_and_plan(self)
        bus = mock.Mock()
        bus.collect.return_value = {'used': ['spook'], 'evidence': []}
        with mock.patch.object(hads4, 'tool_bus', return_value=bus):
            hads4._execute_officer_tool('hads_read_diagnostic_source', {'case_id':case, 'source':'spook'})
            bus.collect.assert_called_once()
            self.assertEqual({'spook'}, bus.collect.call_args.kwargs['adapter_ids'])
            result = hads4._execute_officer_tool('hads_read_diagnostic_source', {'case_id':case, 'source':'shell'})
            self.assertEqual('unsupported_diagnostic_source', result['error'])
            self.assertEqual(1, bus.collect.call_count)

    def test_source_tool_has_strict_explicit_enum(self):
        definition = next(x for x in hads4._officer_tools(False, []) if x['name']=='hads_read_diagnostic_source')
        allowed = definition['parameters']['properties']['source']['enum']
        for name in ('watchman', 'spook', 'hadocs', 'automation_inspector', 'haghs', 'entity_availability', 'ha_mcp', 'hamster_mcp'):
            self.assertIn(name, allowed)
        self.assertTrue(definition['strict'])
        self.assertFalse(definition['parameters']['additionalProperties'])

    def test_scoped_collection_queries_only_selected_mcp(self):
        from tool_adapters import ToolAdapterBus
        bus = ToolAdapterBus.__new__(ToolAdapterBus)
        bus.db=hads4.db; bus.now=hads4.now_utc; bus.refresh=mock.Mock(); bus._runtime={'states':[]}
        bus.global_findings=lambda:[]
        bus.status=lambda:[{'adapter_id':x,'active':False,'discovery':{'connector_ready':True}} for x in ('ha_mcp','hamster_mcp')]
        bus._matched_states=lambda *args:[]
        bus._mcp_case_evidence=mock.Mock(return_value={'outputs':[]})
        bus.collect({'id':123,'title':'device failed'},adapter_ids={'hamster_mcp'})
        bus._mcp_case_evidence.assert_called_once()
        self.assertEqual('hamster_mcp',bus._mcp_case_evidence.call_args.args[0])

    def test_local_planner_records_real_reads_without_paid_model(self):
        case, _, _ = legacy.RC8RegressionTests._case_and_plan(self)
        with mock.patch.object(hads4.functional_focus, 'collect', return_value={'current_impact':'unknown'}), \
             mock.patch.object(hads4.investigation.Investigator, 'logs', return_value={'core':{'available':False}}), \
             mock.patch.object(hads4, 'derive_verified_repair_actions', return_value={'repair_actions':[]}), \
             mock.patch.object(hads4, 'compile_analysis_changes', return_value={'repair_actions':[], 'blockers':[]}), \
             mock.patch.object(hads4, 'options', return_value={'ai_background_research':False}), \
             mock.patch.object(hads4, 'research_case') as paid:
            hads4.planner_research(case, 'Investigate', {'evidence':[], 'used':[]})
        paid.assert_not_called()
        rows = team.latest(hads4.db_read, [case])
        self.assertEqual({'devices','logs'}, {x['role'] for x in rows})
        self.assertEqual('partial', next(x for x in rows if x['role']=='logs')['status'])


class MusicTests(unittest.TestCase):
    def catalog(self):
        return [tool('search_tools', {'query':{'type':'string'}, 'limit':{'type':'integer'}}, ['query']),
                tool('get_tool_schema', {'tool_name':{'type':'string'}}, ['tool_name']),
                tool('call_tool', {'name':{'type':'string'}, 'arguments':{'type':'object'},
                                  'response_mode':{'type':'string'}, 'max_items':{'type':'integer'}}, ['name','arguments'])]

    def exercise(self, schema_change=None, search_change=None):
        calls=[]
        def rpc(a,u,m,p,**kw):
            calls.append(p)
            args=p['arguments']
            if p['name']=='search_tools':
                value={'items':[{'name':'ma_api:'+args['query']}]}
                return search_change(value) if search_change else value
            if p['name']=='get_tool_schema':
                command=args['tool_name'].removeprefix('ma_api:')
                value={'name':args['tool_name'], 'command':command, 'inputSchema':{'type':'object','properties':
                       {'limit':{'type':'integer'}} if 'recent_events' in command else {}, 'additionalProperties':False}}
                return schema_change(value) if schema_change else value
            return {'providers': [{'available':True}]}
        bus=bus_with(self.catalog(), rpc)
        bus._auto_mcp_urls=lambda cfg:{'music_assistant_mcp':'http://example.invalid/mcp'}
        return bus._mcp_case_evidence('music_assistant_mcp','Music Assistant disconnected'),calls

    def test_two_exact_reads_after_discovery_and_schema_with_six_call_bound(self):
        result,calls=self.exercise()
        self.assertEqual(6,len(calls))
        reads=[x for x in calls if x['name']=='call_tool']
        self.assertEqual(['ma_api:fastmcp/debug/health','ma_api:fastmcp/debug/recent_events'], [x['arguments']['name'] for x in reads])
        self.assertEqual(2,result['coverage']['successful_reads'])
        self.assertFalse(any(x['name'] in {'reload','play','execute'} for x in calls))

    def test_schema_cannot_relabel_write_as_read(self):
        result,calls=self.exercise(lambda v:{**v,'command':'fastmcp/debug/reload_provider'})
        self.assertFalse(any(x['name']=='call_tool' for x in calls))
        self.assertEqual(0,result['coverage']['successful_reads'])

    def test_unknown_required_argument_is_not_guessed(self):
        result,calls=self.exercise(lambda v:{**v,'inputSchema':{'type':'object','properties':{'secret':{'type':'string'}},'required':['secret']}})
        self.assertFalse(any(x['name']=='call_tool' for x in calls))

    def test_external_schema_reference_never_retrieved_or_executed(self):
        result,calls=self.exercise(lambda v:{**v,'inputSchema':{'$ref':'https://external.invalid/schema'}})
        self.assertFalse(any(x['name']=='call_tool' for x in calls))

    def test_partial_schema_is_not_authorization(self):
        result,calls=self.exercise(lambda v:{**v,'partial':True})
        self.assertFalse(any(x['name']=='call_tool' for x in calls))

    def test_missing_exact_tool_blocks_dispatch(self):
        result,calls=self.exercise(search_change=lambda v:{'items':[{'name':'ma_api:fastmcp/debug/reload_provider'}]})
        self.assertEqual(2,len(calls))
        self.assertEqual(0,result['coverage']['successful_reads'])

    def test_generic_dispatch_without_verified_read_path_is_not_evidence(self):
        self.assertFalse(policy.observation({'tool':'call_tool', 'result':{'ok':True}}))
        self.assertTrue(policy.observation({'tool':'call_tool', 'read_path_verified':True, 'result':{'ok':True}}))

    def test_missing_metadata_interface_skips_instead_of_guessing(self):
        call=mock.Mock(); skipped=[]
        music_mcp.collect({'tools':[]},call,skipped)
        call.assert_not_called()
        self.assertTrue(skipped)


if __name__ == '__main__':
    unittest.main()
