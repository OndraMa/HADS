import threading
import unittest
from unittest import mock
import hads4
from tool_adapters import ToolAdapterBus


class AuditRegressionTests(unittest.TestCase):
    def test_dashboard_does_not_wait_for_connector_lock(self):
        bus = ToolAdapterBus(None, lambda: '', None, None, None)
        held, release, done = threading.Event(), threading.Event(), threading.Event()
        def owner():
            with bus._refresh_lock:
                held.set()
                release.wait(3)
        thread = threading.Thread(target=owner)
        thread.start()
        self.assertTrue(held.wait(1))
        result = []
        reader = threading.Thread(target=lambda: (result.append(bus.health_scores()), done.set()))
        try:
            reader.start()
            self.assertTrue(done.wait(.5), 'Dashboard waited for network discovery lock')
            self.assertEqual([{}], result)
        finally:
            release.set()
            thread.join(3)
            reader.join(3)

    def test_sigkill_no_oom_cannot_be_p1(self):
        case = {'sample': 'Watchdog found Home Assistant exited with code 137', 'evidence_state': 'unverified'}
        self.assertEqual('P2', hads4.evidence_priority_guard(case, 'P1', '')[0])

    def test_confirmed_oom_not_downgraded(self):
        case = {'sample': 'oom-kill: out of memory SIGKILL', 'evidence_state': 'confirmed'}
        self.assertEqual('P1', hads4.evidence_priority_guard(case, 'P1', '')[0])

    def test_audio_warning_not_critical(self):
        case = {'sample': '[pulseaudio] Failed to open /proc/asound/card0: No such file or directory'}
        self.assertEqual('P4', hads4.evidence_priority_guard(case, 'P1', '')[0])

    def test_start_message_not_critical(self):
        case = {'sample': '[HABS3] HABS 3.1.2 started - Critical Config Backup + OneDrive'}
        self.assertEqual('P4', hads4.evidence_priority_guard(case, 'P1', '')[0])

    def test_unrelated_failure_not_downgraded(self):
        case = {'sample': 'automation failed: device unavailable'}
        self.assertEqual('P2', hads4.evidence_priority_guard(case, 'P2', '')[0])
