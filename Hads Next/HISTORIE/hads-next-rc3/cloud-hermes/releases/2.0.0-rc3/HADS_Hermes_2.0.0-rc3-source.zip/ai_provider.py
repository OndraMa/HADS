"""Safe, actionable provider failures. Never persist raw HTTP bodies or keys."""
import json


class ProviderUnavailable(RuntimeError):
    def __init__(self, message, code="unavailable", retry_seconds=60):
        super().__init__(message)
        self.code = code
        self.retry_seconds = retry_seconds


def http_failure(status, raw, headers):
    try:
        error = json.loads(raw).get("error") or {}
        code = str(error.get("code") or error.get("type") or "")
    except (ValueError, TypeError, AttributeError):
        code = ""
    if code in {"insufficient_quota", "billing_hard_limit_reached", "organization_spend_limit_exceeded", "project_spend_limit_exceeded", "organization_usage_limit_exceeded"}:
        return ProviderUnavailable("AI nemůže pokračovat: poskytovatel hlásí vyčerpaný kredit nebo limit projektu. Ověřte API fakturaci a limity projektu (předplatné ChatGPT je jiné). Další automatický pokus nejdříve za 15 minut; lokální diagnostika pokračuje.", "quota", 900)
    if status in (401, 403):
        return ProviderUnavailable("AI odmítla přístup. Ověřte API klíč, projekt a oprávnění modelu v nastavení HADS. Klíč nikam nevkládejte do incidentu.", "authentication", 900)
    if status in (400, 404):
        return ProviderUnavailable("AI požadavek není podporován. Ověřte zvolený API model a jeho podporované parametry; nejde o závadu Home Assistantu.", "request_configuration", 900)
    try:
        delay = max(30, min(900, int(float(headers.get("Retry-After", "60")))))
    except (ValueError, TypeError):
        delay = 60
    if status == 429:
        return ProviderUnavailable("AI dočasně omezuje počet požadavků (HTTP 429). HADS pozastavil další volání, aby chybu neopakoval u každého incidentu. Kredit z této odpovědi nelze určit.", "rate_limit", delay)
    return ProviderUnavailable(f"AI služba dočasně nedokončila požadavek (HTTP {status}). Příčina incidentu není potvrzena; HADS zkusí analýzu později.", "upstream", delay)
