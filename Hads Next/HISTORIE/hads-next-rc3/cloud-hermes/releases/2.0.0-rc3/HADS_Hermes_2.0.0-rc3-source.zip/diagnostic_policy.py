"""Evidence-specific explanations; never compiles or authorizes a repair."""
import re


def dns_timeout(value):
    text = str(value).lower()
    return ('timeout while contacting dns' in text or
            ('plugin/errors' in text and ('i/o timeout' in text or 'no such host' in text)) or
            ('dial tcp' in text and ':853' in text and 'timeout' in text))


def explanation(value):
    text = str(value).lower()
    if dns_timeout(text):
        return {'kind': 'dns_timeout', 'title': 'DNS nedokázalo včas přeložit adresu služby',
                'summary': 'Resolver nevrátil včas odpověď. Není to důkaz chybného názvu telefonu ani poruchy cílového zařízení.',
                'next_step': 'Porovnat DNS, síťové a Supervisor logy ve stejném čase a ověřit opakování. Změnu DNS navrhnout až po doložení příčiny; bez schválení nic neměnit.'}
    if ('icloud' in text or 'pyicloud' in text) and any(x in text for x in (
            'invalid authentication token', 'authentication required', 'failedloginexception', 'unauthorized', '401')):
        return {'kind': 'icloud_auth', 'title': 'iCloud odmítl přihlášení nebo ověřovací token',
                'summary': 'Odpověď ukazuje na problém přihlášení k účtu iCloud. Přejmenování telefonu tento důkaz nevysvětluje.',
                'next_step': 'Ověřit stav integrace a požadavek na nové přihlášení či 2FA. Potvrzení přihlášení provede uživatel v HA; heslo ani ověřovací kód nevkládat do chatu HADS.'}
    if 'ingress' in text and re.search(r'\b403\b|forbidden', text):
        return {'kind': 'ingress_permission', 'title': 'Ingress odmítl přístup kvůli oprávnění',
                'summary': 'HTTP 403 znamená odmítnutý přístup, ne důkaz nefunkčního doplňku. Příčinu oprávnění je potřeba ověřit.',
                'next_step': 'Ověřit administrátorský účet a panel_admin. Supervisor 2026.10.2 toto omezení vynucuje; nevypínat zabezpečení ani automaticky nezvyšovat oprávnění.'}
    if 'icloud' in text or 'play_sound' in text:
        missing = 'no device with name' in text or 'device not found' in text
        return {'kind': 'icloud_target' if missing else 'icloud_unknown',
                'title': 'iCloud nenalezl požadovaný telefon' if missing else 'iCloud nedokončil požadovanou operaci',
                'summary': 'Volaná akce nenalezla zařízení se zadaným názvem.' if missing else 'Hláška sama neurčuje příčinu. HADS musí odlišit přihlášení, síť a data konkrétní selhané akce.',
                'next_step': 'Porovnat název v trace s názvem ve Find My; při nejednoznačnosti se doptat, nevybírat podobný telefon.' if missing else 'Načíst okolní log a trace konkrétní akce. Zkontrolovat DNS i stav přihlášení; nepřepisovat název telefonu bez důkazu.'}
    return None


def ai_defer_kind(reason):
    value = str(reason or '').lower()
    if 'vypnut' in value or 'výslovné povolení' in value:
        return 'disabled'
    if 'stejný' in value and 'požadavek' in value:
        return 'duplicate'
    return 'budget'
