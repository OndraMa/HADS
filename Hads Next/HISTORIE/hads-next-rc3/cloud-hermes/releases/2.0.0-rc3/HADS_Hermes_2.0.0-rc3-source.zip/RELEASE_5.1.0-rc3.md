# HADS 5.1.0-rc3 — audit fronty, vysvětlení a čtecí MCP

15. 10. 2026. Výchozí verze: 5.1.0-rc2. Jde o další testovací kandidát,
ne o příslib bezchybnosti všech oprav nebo potvrzení živého provozu.

## Opraveno podle dodaných výpisů

- Automatický stav review_ready již při přestavbě incidentů neskrývá platný
  připravený plán. Výslovné odmítnutí, ignorování a další volby kapitána
  zůstávají zachované. Nedochází k automatickému schválení.
- Samostatné plány mají vlastní přehled a rozlišení skutečně chybějící vazby
  od existujícího incidentu mimo aktivní frontu.
- Dávka blocked_remote_verify je označena jako zablokovaný dokončený pokus,
  ne jako právě probíhající čekání. Zobrazuje upload, chybový důvod, omezené
  chyby ověřování a ID plánů této dávky. Nedochází k automatickému opakování.
- Chybějící služba pro nezávislé ověření OneDrive je vysvětlena výslovně.
  Upload ACK dál neodemyká zápisovou bránu. Samotný instalátor HADS neinstaluje
  Core companion hads_rescue ani neprokazuje jeho kompatibilitu s vaším Core.
- DNS timeout, iCloud autentizace, chybně pojmenovaný telefon a Ingress 403
  mají rozdílné závěry a další kroky. Z názvu domény iCloud se nehádá jméno telefonu.
- Související řádky CoreDNS upstream timeout se korelují do jednoho root-case.
  Jde o společný diagnostický okruh, nikoli potvrzení konečné příčiny. Surové
  události se nemažou; pravidla nepřevádějí již udělený souhlas na jiný incident.
- Maskované entity a soubory script.py se nepoužívají jako přesný cíl čtení.
- Vypnutá AI, duplicitní požadavek a limit počtu volání mají odlišné stavy.
  Tyto počty nejsou výpisem dolarového zůstatku OpenAI.
- Ochranná prodleva uvádí úlohu, UTC termín, zbývající sekundy a důvod.
  Panel označuje prošlé prodlevy jako starší záznam, ne současnou blokaci.
- Skóre sběru protokolů již není v hlavním panelu označeno jako úplné pokrytí
  diagnostiky. Čerstvě ověřené konektory se zobrazují zvlášť. Prošlé ověření
  neznamená automaticky nefunkční konektor.

## HA-MCP

Vyhledávání žádá nejvýše tři kandidáty a kompaktní projekci podporovanou
ověřeným schématem serveru. Zpracuje i JSON zabalený do JSON textu.
Stránkovaný úspěšný výsledek může posloužit jako vodítko pro omezené čtení
jednoho kandidáta, ale zůstává neúplným pokrytím. Explicitní chyba, truncation
nebo partial response neautorizuje navazující čtení. Kandidát není potvrzená
totožnost, funkční test ani oprávnění ke změně.

Allowlist MCP se nerozšiřuje o obecné zápisy nebo shell. OpenAI model ani
placené nastavení se samovolně nemění. Explicitní prompt caching existovalo
už v RC2; tento update neslibuje nezměřenou úsporu ani nepřidává placená volání.

## Ověřené podklady

- [Supervisor 2026.10.2](https://github.com/home-assistant/supervisor/releases/tag/2026.10.2): panel_admin v Ingressu.
- [HA-MCP nastavení](https://github.com/homeassistant-ai/ha-mcp/blob/master/homeassistant-addon/DOCS.md): Read Only Mode, Tool Search a pinned tools.
- [HA-MCP vyhledávání](https://github.com/homeassistant-ai/ha-mcp/blob/master/src/ha_mcp/tools/tools_search.py): fields, result_fields a stránkování.
- [Oficiální MCP v Core](https://www.home-assistant.io/integrations/mcp_server/): není totožný s projektem HA-MCP; jeho jiný katalog a OAuth nelze zaměňovat.
- [OpenAI Docs: prompt caching](https://developers.openai.com/api/docs/guides/prompt-caching): stabilní prefix a diagnostika cache; cache není kontrola celkové útraty.

## Přejímka

Skutečně provedené offline testy a kontroly balíčku uvádí verification.json.
Produkční databáze s plány #6/#7 nebyla poskytnuta: příčina konkrétního stavu
není ověřena proti ní. Detail původní dávky B-2 rovněž nemáme. Živé HA-MCP,
Ingress, OneDrive readback, obnova zálohy a systémová oprava vyžadují přejímku
po instalaci. Tento update neobchází žádnou zálohovací bránu.
