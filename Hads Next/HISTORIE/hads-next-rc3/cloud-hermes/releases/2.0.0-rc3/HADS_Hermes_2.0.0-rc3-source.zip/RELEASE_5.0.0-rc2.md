# HADS 5.0.0-rc2 — cílená MCP diagnostika a návod

28. 9. 2026. Navazuje na provozní přestavbu 5.0.0-rc1, nevydává ji za živě akceptovanou. Instalace: [český manuál](MANUAL_5.0.0-rc2_CS.md).

## Změny proti RC1

- Metadata Hamsteru (search/schema/explain) se již nezapočítávají jako přečtená diagnostika. Chybové a zkrácené odpovědi nemohou znamenat dokončené čtení.
- Pevná čtecí politika místo důvěry v libovolný serverový `readOnlyHint`. Obecné MCP služby a zápisy se při vyšetřování nevolají.
- HA-MCP dostává podle případu konkrétní entity, časované okno historie a ID automatizace/skriptu. Parametry jsou vázané na právě vrácené vstupní schéma; chybějící parametry jsou viditelnou mezerou, ne odhadem.
- Katalog podporuje omezené stránkování, deduplikaci jmen a detekci opakovaného kurzoru. Nedokončený katalog není úplný katalog.
- UUID pro jednotlivé JSON-RPC požadavky odstraňuje kolize při několika voláních stejné metody v jedné sekundě. Neshodující se ID odpovědi se odmítá. Tolerance chybějícího initialize se omezuje na Hamster.
- Cílené vyšetřování má rozpočet počtu nástrojů, síťového času a uloženého obsahu. Výsledky deklarované poskytovatelem jako částečné zůstávají částečné.
- Panel zdrojů zobrazuje katalog odděleně od posledního skutečného diagnostického čtení, chyb a mezer. Neúspěch nepřepíše historický čas použitých dat falešným čerstvým úspěchem.
- Opravené české popisky prázdných MCP/API adres a návod pro skutečné URL, autentizaci, zdroje, AI limity a OneDrive readback.

## Zachované bezpečnostní podmínky

Instalátor na žádost uživatele nevytváří předinstalační HA/OneDrive zálohu; zachovává staré zdroje. Běžící opravný motor stále potřebuje konkrétní schválení a nezávisle ověřenou OneDrive rescue zálohu. rclone není zaveden. Placená AI se upgradem nově nepovoluje, ale dříve uložená nastavení se zachovají — před instalací ji výslovně vypněte.

## Testování a omezení

Autoritativní výsledek je `HADS4_5.0.0-rc2-verification.json`. Nové offline testy pokrývají MCP čtecí politiku, schémata, čas historie, chyby/metadatové výsledky, stránkování, limity, korelaci odpovědí, trvalý stav zdroje a UI. Placené API se nevolá.

Nejde o implementaci všech MCP funkcí, všech oprav ani celého dříve popsaného autonomního agenta. Hamster čte úzký povolený okruh bezparametrických HA příkazů; další důkazy zajišťují existující nativní kolektory. Neznámý JSON kontrakt konektoru může stále vyžadovat adaptér. Aktuální běh všech konektorů, Docker na HAOS, fyzické zařízení, upload/readback vašeho OneDrive a skutečná obnova dosud nebyly ověřeny v této relaci.

Použité primární podklady a konkrétní instalační kroky jsou u jednotlivých částí manuálu. Verze serverů v manuálu nejsou automaticky instalovány ani aktualizovány spolu s HADS.
