# HADS Hermes 2.0.0-rc1

Bezpečný runtime vyžaduje Landlock ABI 4, zahazuje root oprávnění a nemá
přístup k HA konfiguraci/zálohám ani spouštění programů. Před placeným krokem
ověřuje 768 MiB rezervy. Obraz používá Python 3.14 a opravené SQLite 3.53.4
podle upstreamu (WAL-reset fix, ověřená SHA256 zdrojového archivu).

Nová kompatibilní větev nad 5.1.0-rc3. Skutečný Nous Research Hermes Agent
v0.22.2 je připnut na commit d923a5eb487a17c0a68801bba9ef0f56c81040a8.

- AIAgent v dočasném samostatném procesu bez přímých nástrojů, klíčů a
  automatických pluginů. Kontrolovaný katalog dovoluje žádat jen čtení HADS.
- Lokální modelový broker propustí nejvýše jeden požadavek v kroku. Každý
  skutečný požadavek vede přes perzistentní limity a účtenku použití HADS.
- Odpovědi se kontrolují podle JSON Schema, včetně argumentů čtení.
  Neplatný, duplicitní či neznámý požadavek nevyvolá žádné čtení ani zápis.
- Žádný automatický fallback na starý placený engine při chybě Hermes.
  Volbu `hermes_enabled: false` může udělat člověk v nastavení.
- Zachovány sběry, konektory, vyšetřování, chat, přesný kompilátor plánů,
  schválení, ochrana proti změně konfigurace a povinné cloudové zálohy.
- Obraz má build-time test skutečného Hermes proti falešnému modelu. Pokud
  neprojde, sestavení selže. Základ Debian/Python, jen amd64/aarch64.

Tato RC neznamená audit všech zdrojů starého HADS ani nové generické opravy
všech databází, registrů a souborů. Neomezené shell/MCP write nástroje nejsou
povoleny diagnostickému agentovi. Jde o první testovatelnou Hermes větev,
nikoli garantovanou produkční finální verzi. Lokálně nebylo spuštěno Docker
sestavení (Docker není dostupný), živé HAOS ani placená AI. Podrobné výsledky
provedených testů jsou v přiloženém verification JSON.

Zdroje ověřené 20. 10. 2026:

- https://github.com/NousResearch/hermes-agent/releases/tag/v0.22.2
- https://github.com/NousResearch/hermes-agent/blob/d923a5eb487a17c0a68801bba9ef0f56c81040a8/run_agent.py
- https://github.com/NousResearch/hermes-agent/blob/d923a5eb487a17c0a68801bba9ef0f56c81040a8/agent/agent_init.py
- https://github.com/NousResearch/hermes-agent/blob/d923a5eb487a17c0a68801bba9ef0f56c81040a8/model_tools.py
- https://developers.openai.com/api/docs/guides/function-calling

Odkazovaný chat byl přečten, ale hlavní odpovědi vracel pouze jako interní
reference bez textu; nemohly být převzaty jako kompletní technický návrh.
