# HADS 5.0.0-rc2 — instalace a nastavení

Dokončeno 28. 9. 2026. Návod odpovídá dodanému zdrojovému kódu RC2. Nejde o potvrzení, že níže popsané služby již fungují ve vašem HAOS; to ukáže kontrola po instalaci. Názvy „Aplikace“ a „Doplňky“ se liší podle verze/překladu HA.

## 1. Nejkratší doporučený postup

1. V nastavení nynějšího HADS nejprve vypněte placenou AI a placený web. Upgrade zachovává uložené volby — výchozí `false` není vypnutí dříve povolené služby.
2. Nahrajte `HADS4_install_5.0.0-rc2.sh` do `/config` v Home Assistantu.
3. V HAOS terminálu spusťte:

   ```bash
   bash /config/HADS4_install_5.0.0-rc2.sh
   ```

   Nepoužívejte `python3` na `.sh` soubor. Terminál musí mít `bash`, `python3`, `ha` a přístup k Supervisor API přes `SUPERVISOR_TOKEN`. Token nikam nekopírujte ani neposílejte. Pokud kontrola přístupu selže, instalátor nemá pokračovat výměnou zdrojů.
4. Otevřete HADS a proveďte Ctrl+F5. V panelu i informacích aplikace ověřte **5.0.0-rc2**.
5. Nastavte konektory podle následujících částí; potom **Diagnostické zdroje → Ověřit všechna spojení**. Počkejte na dokončení úlohy a obnovení dat.
6. Ověřte jeden známý incident. Teprve poté případně povolte jeden placený AI pokus. Opravy spouštějte až po samostatném ověření cloudové zálohy.

### Co instalace dělá a nedělá

Na vaše výslovné přání **nevytváří předinstalační HA ani OneDrive zálohu**, nevyžaduje rclone a při aktualizaci doplňku žádá `backup: false`. Staré zdroje uchová v `/share/hads4_installer_backups`. To není záloha databáze ani celého HAOS. Případná migrace databáze nemusí být vratná pouhým obnovením zdrojů. Existující starší zálohy nemaže.

Neinstaluje Hamster, HA-MCP ani pomocnou Core integraci a nerestartuje Core. Instalátor není nasazení provedené v tomto chatu — spouštíte jej vy. Povinné zálohy před následnou **opravou systému** zůstávají zapnuté.

## 2. Co vyplňovat kde

HADS: **Nastavení → Aplikace / Doplňky → HADS → Konfigurace**. Tabulka uvádí skutečné klíče pro YAML editor této konfigurace. Nevkládejte tyto volby do `configuration.yaml` a nenahrazujte jimi celý stávající seznam nastavení.

| Účel | Nastavení HADS | Význam |
| --- | --- | --- |
| HA-MCP server | `ha_mcp_url`, `ha_mcp_token` | Přesná MCP URL, nikoli stránka Ingressu |
| Hamster v Core | `hamster_mcp_url`, `hamster_mcp_token` | Samostatná adresa a případný HA token |
| Automation Inspector | `automation_inspector_api_url`, `automation_inspector_token` | Čtecí report JSON |
| HADocs | `hadocs_api_url`, `hadocs_token` | Čtecí JSON dané verze HADocs |
| Čas jedné externí komunikace | `external_connector_timeout_seconds: 30` | MCP vyšetřování má navíc rozpočet, nikoli nekonečné opakování |

Prázdná MCP adresa **neznamená vypnutý konektor**: HA-MCP se pokusí najít server z aktuální instalace/konfigurace/logu, Hamster použije interní HA proxy. RC2 opravuje staré zavádějící české popisky.

## 3. HA-MCP

Pro samostatnou aplikaci **Home Assistant MCP Server** použijte [postup autora](https://github.com/homeassistant-ai/ha-mcp/blob/master/homeassistant-addon/DOCS.md). Repozitář pro obchod aplikací je `https://github.com/homeassistant-ai/ha-mcp`. Po spuštění najdete v protokolu jeho přesnou MCP URL s tajnou cestou `/private_…`.

V HADS ponechte nejprve `ha_mcp_url` prázdné a ověřte spojení. Pokud autodetekce neuspěje, vyplňte skutečnou adresu. Pro komunikaci uvnitř HAOS lze použít hostname z informací aplikace:

```yaml
ha_mcp_url: "http://SKUTECNY-HOSTNAME:9583/private_SKUTECNA_TAJNA_CESTA"
ha_mcp_token: ""
```

Toto je vzor, ne hotová funkční adresa. Nahraďte oba zástupné údaje. U běžné varianty s tajnou cestou zůstává token prázdný; OAuth varianta vyžaduje jiný způsob autentizace a HADS zde nemá interaktivní OAuth průvodce. Tajná URL je přihlašovací údaj.

V HA-MCP nechte zpřístupněné diagnostické nástroje `ha_get_state`, `ha_get_entity`, `ha_get_history`, `ha_get_automation_traces`, `ha_search`, `ha_get_system_health`. Pokud vaše verze nabízí Read Only Mode, použijte jej pro diagnostické připojení. Pokud Tool Search skrývá vlastní nástroje z `tools/list`, připněte požadované čtecí nástroje do katalogu nebo pro toto připojení skrytí vypněte; RC2 obecný dispatcher Tool Search nevolá. Po změně znovu ověřte spojení v HADS.

Nepřidávejte odhadem `/mcp`, nepoužívejte URL panelu `/api/hassio_ingress/…`, nespouštějte druhou kopii přes `uvx`. Pro lokální spojení HADS není potřeba vystavovat port do internetu.

### Co RC2 přes HA-MCP skutečně dělá

Má pevně povolených šest výše uvedených čtecích nástrojů. Podle incidentu a živého vstupního schématu vybírá stav, registr, historii a stopy. Neznámý povinný parametr nevymýšlí: ukáže chybějící důkaz. Historie používá uložený čas incidentu s časovou zónou; jinak výslovně uvádí posledních 24 hodin. Stopy jsou poslední uložené běhy, nikoli automatický důkaz konkrétního včerejšího stisku.

Přečtení entity `on` samo nedokazuje, že fyzická lampička reagovala. Údaj o funkčnosti, historii i uživatelské potvrzení musí analýza posoudit společně. Nejde o podporu všech nástrojů HA-MCP ani všech oprav.

## 4. Hamster MCP

Hamster je **integrace uvnitř Core**, nikoli samostatná aplikace. Podle [dokumentace autora](https://github.com/altendky/hamster-mcp) se instaluje přes HACS jako vlastní repozitář `https://github.com/altendky/hamster-mcp`, kategorie Integrace. Po instalaci/restartu přidejte integraci v **Nastavení → Zařízení a služby**. Pokud už je načtená, nepřidávejte druhou instanci.

Preferované nastavení v HADS na HAOS:

```yaml
hamster_mcp_url: ""
hamster_mcp_token: ""
```

HADS zkusí `http://supervisor/core/api/hamster_mcp` s interním oprávněním. Úspěch této cesty je nutné ověřit na vašem Core. Při nepodporované proxy/401 použijte přímou adresu Core:

```yaml
hamster_mcp_url: "http://IP_ADRESA_HA:8123/api/hamster_mcp"
hamster_mcp_token: "DLOUHODOBY_HA_TOKEN"
```

Token vytvořte v profilu HA v části Zabezpečení / Dlouhodobé přístupové tokeny. Je to **HA token, nikoli OpenAI klíč**. Vkládá se bez slova `Bearer`; hlavičku vytvoří HADS. Na vzdálené nedůvěryhodné síti používejte zabezpečený přenos, nikoli toto lokální HTTP schéma. Token nesdílejte v chatu.

Hamster nabízí metanástroje `search`, `schema`, `explain`, `call` aj. Jejich katalog ještě neobsahuje aktuální stav HA. RC2 nejprve dohledá povolený čtecí příkaz, ověří dostupnost schématu a teprve pak čte; chybu schématu neobchází. Pro Spook/osiřelé statistiky preferuje Repairs, jinak aktuální stavy. Obecné akce Hamsteru, restart, mazání ani tvorba nejsou při vyšetřování povolené. Čtení všech historických a diagnostických funkcí Hamsteru tato RC nepokrývá; další zdroje čte nativní HA vrstva.

## 5. Ostatní diagnostické zdroje

### Spook

HADS čte standardní HA Repairs přes `repairs/list_issues`; zvláštní URL ani token Spooku se nezadává. Zkontrolujte, že je integrace načtená a její problém je vidět také v HA opravách. Spook provozuje své kontroly a registruje nalezené problémy — není to jen ruční tlačítko na načtení YAML. [Mechanismus Spook Repairs](https://spook.boo/repairs/).

Nula Repairs může být platný výsledek, nikoli závada konektoru. Osiřelé dlouhodobé statistiky samy neprokazují poškozenou databázi a jejich odstranění není automaticky naléhavější než nefunkční automatizace.

### Watchman

V možnostech Watchmanu ponechte report `/config/watchman_report.txt`. Watchman má také akci `watchman.report` se strukturovanou odpovědí. HADS ji umí vyžádat bez tvorby TXT (`create_file: false`), pokud ji verze poskytuje; TXT je další zdroj, ne samostatné síťové API. [Dokumentace Watchmanu](https://github.com/dummylabs/thewatchman).

Při ruční kontrole v **Vývojářské nástroje → Akce** lze zavolat `watchman.report` s `create_file: false`, `force_parsing: true`. Je to diagnostický přepočet, ne oprava automatizací. V HADS porovnejte konkrétní chybějící entitu/službu a umístění v souboru; nesrovnávejte jen celkový počet karet. HADS slučuje související nálezy a může zohlednit vypnuté automatizace. Watchman používá heuristiky, proto jeho každý nález není potvrzená příčina.

### Automation Inspector

Současné dokumentované čtení je `/api/v1/inspection`, schéma 2, s podporou ETag; `/ready` a `/api/v1/status` pomáhají odlišit živý proces od aktuálního reportu. [API autora](https://github.com/ITSpecialist111/Automation-Inspector).

HADS nejprve zkusí autodetekci. Ruční vzor:

```yaml
automation_inspector_api_url: "http://SKUTECNY-HOSTNAME:1234/api/v1/inspection"
automation_inspector_token: ""
```

Hostname ověřte v informacích aplikace; historický prefix z jiného systému nekopírujte. Token vyplňte jen podle autentizace vašeho serveru. HADS nepovažuje neznámé schéma či selhanou obnovu za prázdný zdravý report. Porovnejte jeden konkrétní nález, vlastníka automatizace a návrh změny s UI Inspectoru.

### HADocs

HADocs má strojově čitelná data pro svou analýzu, ale adresy/struktura závisejí na verzi. [Projekt HADocs](https://github.com/SirBlondieDK/HADocs). `hadocs_api_url` v HADS musí vracet JSON s nálezy, nikoli úvodní HTML stránku. Nejprve nechte automatické hledání. Jestli neuspěje, je potřeba ověřit API nasazené verze; tento návod nevydává odhadnutý endpoint za funkční napojení. Doporučení HADocs je důkaz pro posouzení, nikoli automatické schválení zásahu.

### HAGHS a Entity Availability

Nemají v HADS samostatná pole pro API klíč. HADS čte jejich dostupné entity, atributy a registry z Core. U HAGHS zkontrolujte nastavení zdrojů metrik a dostupné doporučující atributy; u Entity Availability nakonfigurované skupiny a monitorované entity. V HA **Vývojářské nástroje → Stavy** ověřte, že nejsou `unknown`/`unavailable`. Nestačí mít jen instalační záznam HACS.

HADS interpretuje podporované příznaky RAM/I/O/disku, offline/stale stavy a dostupné údaje o baterii/signálu; historie dostupnosti doplňuje již nalezený problém. Ne všechny verze/skupiny poskytují každé pole. [HAGHS](https://github.com/HA-Pulse/home-assistant-global-health-score), [Entity Availability](https://github.com/italo-lombardi/Home-Assistant-EntityAvailability).

Codex Terminal Pro nemusíte instalovat; není podmínkou diagnostiky. Home Assistant Digest není součástí sítě HADS.

## 6. Jak poznat skutečně funkční napojení

V **Diagnostických zdrojích** sledujte odděleně přítomnost, proces, ověřené rozhraní a čas odpovědi. Nově u MCP také:

- **MCP katalog:** kolik nástrojů bylo objeveno a zda bylo stránkování úplné.
- **Povolené čtecí nástroje:** ne všechny nástroje serveru mají oprávnění pro vyšetřování.
- **Poslední cílené čtení:** čas skutečného pokusu pro incident, ne čas pouhého katalogu.
- **Výsledek čtení / chybějící důkazy:** úspěch, částečná data, chybějící nástroj či parametr.

Po „Ověřit všechna spojení“ může být katalog dostupný, ale cílené čtení zatím neprovedené. To je správné rozlišení. Spusťte jednu hlubokou analýzu nebo v incidentu otevřete **Konverzace → Nesouhlasím — znovu vyšetřit**, uveďte přesné `entity_id`, datum a čas. Nové vyšetření odvolává starý souhlas s opravou. Dokončení může být odloženo kvůli paměťové rezervě/plánovači; sledujte stav úlohy, neklikejte opakovaně.

RC2 omezuje katalog na čtyři stránky / 300 nástrojů a jednu MCP část vyšetřování na nejvýše šest volání nástrojů. Před další síťovou operací kontroluje 60sekundový rozpočet a zkracuje její timeout; není to procesová garance přerušení libovolné externí knihovny. Nadlimitní odpověď je označena jako zkrácená, nikoli jako úplné ověření. Ani „diagnostická data přečtena“ neznamená „všechna zařízení fungují“.

## 7. OpenAI až po ověření dat

Bezpečný počáteční stav pro instalaci a test konektorů:

```yaml
openai_enabled: false
ai_paid_calls_enabled: false
ai_paid_web_enabled: false
ai_background_research: false
ai_call_limits_enabled: true
ai_daily_call_limit: 2
ai_case_daily_call_limit: 1
ai_max_output_tokens: 2000
```

Chcete-li pak vyzkoušet jednu AI otázku: zadejte klíč v `openai_api_key`, ponechte ověřený model dostupný vašemu API projektu a zapněte `openai_enabled` i `ai_paid_calls_enabled`. Web a pozadí zatím ponechte vypnuté. Klíč samotný analýzu nepovoluje. Pro nekompatibilní cache parametry lze `ai_prompt_cache_mode` nastavit na `implicit`; neřešte chybnou konfiguraci opakovaným placeným odesíláním. Volbu modelu tato verze automaticky nemění.

Zadejte jedinou otázku v incidentu, potom zkontrolujte jeho odpověď a evidenci API požadavků/tokenů. HADS účtuje do limitů i neúspěšné pokusy a limity přežijí restart. **Počet volání není dolarový strop.** Neznámá spotřeba po chybě se nemá interpretovat jako nulová. Pro oddělení od hlasového asistenta používejte oddělený API projekt/klíč a kontrolujte skutečnou spotřebu u poskytovatele.

MCP čtení HADS samo nepotřebuje OpenAI volání. Pokud později povolíte AI, vybrané důkazy se mohou posílat poskytovateli; maskování není důvod vkládat hesla do incidentu. V této vývojové relaci se neprovedl žádný placený AI test. Návrh odděluje model od vykonavatele podle [principu volání nástrojů OpenAI](https://developers.openai.com/api/docs/guides/function-calling): modelový návrh není sám oprávnění k zápisu.

### Poznámka k Astře a computer use

Schopnosti modelu nejsou automaticky schopnostmi doplňku. [Dokumentace computer use](https://developers.openai.com/api/docs/guides/tools-computer-use) vyžaduje prostředí a vykonavatele akcí na straně aplikace. RC2 takové produkční ovládání obrazovky nezavádí. Pro vývoj a budoucí UI akceptaci je tento směr užitečný; pro provoz HAOS zůstávají čtecí API/MCP a přesně schválené opravné kroky. Model ani placené volání nejsou na základě zprávy o vydání automaticky změněny.

## 8. OneDrive před opravami — ne před instalací

Používá se existující HA OneDrive integrace; rclone není potřeba. V HADS zůstává:

```yaml
onedrive_enabled: true
onedrive_config_entry_id: "ID_VASI_ONEDRIVE_INTEGRACE"
rescue_onedrive_folder: "HADS/Repairs"
backup_before_repairs: true
allow_repair_without_backup: false
rescue_accept_upload_ack: false
```

ID config entry není klientské ID Microsoft aplikace ani token. Získáte je z diagnostického exportu integrace / její skutečné konfigurace. Upload reportu **nedokazuje**, že byl záchranný ZIP nezávisle přečten a ověřen.

Pro nezávislé ověření ZIP je v balíčku volitelný **HADS Rescue Readback 0.1.0**. Jeho instalace je samostatná, nikoli skrytý krok tohoto instalátoru:

1. Zajistěte bezpečný přístup nezávislý na Core/Ingressu a zálohu Core konfigurace před přidáním integrace.
2. Ze zdrojového ZIP zkopírujte pouze `companion/custom_components/hads_rescue` do `/config/custom_components/hads_rescue`. Existující složku nepřepisujte bez kontroly.
3. Při bezpečně dostupném zařízení restartujte Core, přidejte integraci **HADS Rescue Readback** přes Zařízení a služby.
4. V HADS lze nastavit `rescue_remote_verify_service: "hads_rescue.verify"`; podporována je i autodetekce této služby.
5. Nejprve otestujte readback známého malého ZIP a odmítnutí neexistujícího souboru. Porovnává se účet/složka/název/velikost/SHA-256, ne jen potvrzení uploadu.

Podrobnosti a kompatibilita jsou v `companion/README.md`: ověřeno inspekcí pro Core 2026.9.2 / daný OneDrive SDK, nikoli živým testem vašeho účtu. Companion není automatická obnova celého HA ani důkaz obnovitelnosti. Pokud ověření selže, write gate má zůstat zamčená. **Nevypínejte zálohovou bránu, aby se rozsvítilo tlačítko.**

## 9. První akceptační kontrola

| Zkouška | Co má být vidět |
| --- | --- |
| Start HADS | RC2, čerstvý snapshot, dokončený cyklus; ne nekonečné 502 |
| Sběr protokolů | Test Core/Supervisor/host/aplikací; každá chyba zdroje samostatně |
| MCP bez AI | Dostupný katalog a potom skutečné čtení pro známý incident, nikoli metadata vydávaná za důkaz |
| Přejmenovaná entita | Vlastník automatizace, starý odkaz, ověřená náhrada nebo konkrétní chybějící informace |
| Funkční Meross HTTP | MQTT chyba se nesmí bez dalšího vydávat za nefunkční Wi-Fi/lampu |
| Nedostupný konektor | Viditelná chyba a historický čas; nikoli falešné „vše OK“ |
| Přijatý závěr | Sledování, nikoli schválená vykonatelná oprava |
| Skutečná oprava | Přesná změna před/po, souhlas, cloudová kontrola, výsledek a následné ověřování |

Při 401/403 řešte oprávnění; při 404 přesnou cestu; při DNS chybě hostname a běh aplikace. Při 502 ověřte protokol HADS a stav procesu/paměti. Opakované klikání ani doplnění dalšího API klíče nenahradí dostupný backend.

Toto vydání má omezené, testované vykonávací typy: změna YAML, automatizace/skriptu, voleb doplňku, restart doplňku/Core za stanovených podmínek a podporovaná údržba Recorderu. **Nemá univerzální shell ani libovolné SQL opravy.** Nepřipravený plán či chybějící důkaz musí být viditelný, ne zakrytý neověřeným příslibem opravy.

Pro potvrzení celé instalace zbývá živě ověřit konektory, paměť, OneDrive readback a jeden konkrétní schválený zásah s následným funkčním testem. Do té doby jde o RC, nikoli garantovaného finálního autonomního opraváře.
