# HADS 5.1.0-rc2 — oprava snapshotu

Nahrajte `HADS4_install_5.1.0-rc2.sh` do `/config` a spusťte:

```bash
bash /config/HADS4_install_5.1.0-rc2.sh
```

Nespouštět přes Python. Instalace zachovává nastavení a databázi HADS.
Podle vašeho dřívějšího požadavku nevytváří novou předinstalační HA/OneDrive
zálohu; povinná záloha před opravou systému tím není vypnutá.

Po instalaci obnovte panel Ctrl+F5 a ověřte verzi 5.1.0-rc2. Přehled má načíst
data místo chyby o paměťovém limitu. U delších seznamů použijte Předchozí/Další;
číselné součty zahrnují i ostatní stránky. Zkrácený text není úplný důkaz —
otevřete detail incidentu nebo plánu.

Pokud přehled opět selže, zobrazí konkrétní chybu a zachová čas posledních
platných dat. Diagnostické smyčky po úspěšném startu databáze pokračují,
ale jejich skutečný postup ověřte podle času dokončeného cyklu. Tlačítko
oprav při chybě přehledu není aktivní. Není třeba mazat incidenty ani
zvyšovat RAM pouze kvůli této hlášce.

Placenou AI pro tuto přejímku není nutné zapínat. Pokud se panel neobnoví,
pošlete nový log od startu RC2. Výsledek živé přejímky zatím není potvrzen.
