"""Bound presentation data, not the incident database or repair decisions.

Pages are read-only projections. Full evidence and plans stay on their detail
endpoints. Counts always describe the complete source, not the visible page.
"""
from __future__ import annotations

import json
from itertools import islice
from runtime_core import ResponseTooLarge

SECTIONS = (
    'root_cases', 'repair_cases', 'conclusion_cases', 'history_cases',
    'investigating_cases', 'watching_cases', 'automatic_monitoring_cases',
    'functional_cases', 'attention_cases', 'technical_cases', 'unverified_cases',
    'standalone_plans', 'plan_history', 'tool_adapters', 'log_sources',
)


def preview(value, depth=0, budget=None):
    """Bound stale connector/error metadata too; never used for execution."""
    if budget is None:
        budget = [16000]
    budget[0] -= 16
    if isinstance(value, str):
        size = min(1200, max(0, budget[0]))
        budget[0] -= min(size, len(value))
        return value if len(value) <= size else value[:size] + '… [zkrácený přehled]'
    if isinstance(value, (dict, list, tuple)) and depth >= 7:
        return '[podrobnosti nejsou součástí přehledu]'
    if isinstance(value, dict):
        result = {}
        for k, v in islice(value.items(), 60):
            if budget[0] <= 0:
                break
            key = str(k)[:100]
            budget[0] -= len(key)
            result[key] = preview(v, depth+1, budget)
        if len(value) > len(result):
            result['_preview_omitted_keys'] = len(value)-len(result)
        return result
    if isinstance(value, (list, tuple)):
        result = []
        for v in value[:30]:
            if budget[0] <= 0:
                break
            result.append(preview(v, depth+1, budget))
        if len(value) > len(result):
            result.append({'_preview_omitted_items': len(value)-len(result)})
        return result
    return value


def section_page(model, section, offset=0, limit=50):
    if section not in SECTIONS:
        raise ValueError('Neznámá část přehledu.')
    offset, limit = max(0, int(offset)), max(1, min(50, int(limit)))
    rows = model.get(section) or []
    total = len(rows)
    offset = min(offset, max(0, ((total-1)//limit)*limit)) if total else 0
    visible = [preview(row) for row in rows[offset:offset+limit]]
    while True:
        result = {'section': section, 'rows': visible[:limit],
                  'offset': offset, 'limit': limit, 'total': total,
                  'next_offset': offset+limit if offset+limit < total else None,
                  'previous_offset': max(0, offset-limit) if offset else None,
                  'updated_at': model.get('updated_at')}
        if len(json.dumps(result, ensure_ascii=False, default=str, separators=(',', ':')).encode()) <= 512*1024:
            return result
        if limit == 1:
            raise ResponseTooLarge('Jedna položka přehledu překročila limit; otevřete její detail.')
        limit = max(1, limit//2)


def bounded(model, limit=2*1024*1024):
    # Keep control values and counts intact; trim only presentation collections.
    # Leave headroom for runtime/snapshot status added by the HTTP read model.
    other = {k: preview(v) for k, v in model.items() if k not in SECTIONS}
    for page_size in (50, 25, 10, 5, 1):
        result = dict(other)
        pages = {}
        for name in SECTIONS:
            if name not in model:
                continue
            page = section_page(model, name, limit=page_size)
            result[name] = page.pop('rows')
            pages[name] = page
        result['panel_paging'] = pages
        result['panel_notice'] = (
            'Přehled je stránkovaný a texty mohou být zkrácené. '
            'Počty zahrnují všechny položky; úplné důkazy a plán otevřete v detailu.'
        )
        data = json.dumps(result, ensure_ascii=False, default=str, separators=(',', ':')).encode('utf-8')
        if len(data) <= max(0, limit-16384):
            return result
    raise ResponseTooLarge('Ani zkrácený přehled se nevešel do limitu dat panelu; diagnostika může pokračovat.')
