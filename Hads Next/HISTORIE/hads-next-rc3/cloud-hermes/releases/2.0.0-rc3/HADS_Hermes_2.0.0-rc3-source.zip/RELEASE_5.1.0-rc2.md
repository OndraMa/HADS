# HADS 5.1.0-rc2 — oprava startu a velikosti panelu

12. 10. 2026. Výchozí verze: 5.1.0-rc1.

## Potvrzená chyba RC1

Log z 12. října ukazuje selhání inicializace na limitu snapshotu. Jde o interní
limit 2 MiB serializovaných dat panelu, ne o potvrzení nedostatku RAM v HAOS.
Stejné incidenty jsou součástí více seznamů a opakují se v JSON. Přesný podíl
jednotlivých částí v produkčním snapshotu bez produkčních dat není změřen.
Výjimka při publikaci přehledu chybně zabránila spuštění všech pracovních smyček.

## Změny

- Stránkovaný přehled, nejvýše 50 položek v části, při větším payloadu méně.
  Počty zahrnují úplný zdroj, nikoli jen aktuální stránku. Předchozí/Další
  zpřístupní zbývající incidenty a plány; detail zůstává samostatný.
- Zkrácení dlouhých textů a vnořených diagnostických metadat pouze pro zobrazení.
  Databáze, důkazy, rozhodnutí a vykonatelné plány se tím nemění.
- Limit 2 MiB zůstává zachovaný. Serializace kontroluje UTF-8 bajty postupně.
- Selhání panelu nezablokuje pracovní smyčky po úspěšné inicializaci databáze.
  Selhání samotné inicializace databáze je nadále blokující.
- Při chybě zůstane poslední platný snapshot a jeho původní čas; při prvním
  startu se zobrazí stav nedostupného přehledu. Spouštěcí tlačítko je zamčené,
  readiness vrací 503 a další aktualizace zkouší přehled obnovit.
- Panel zobrazuje příčinu degradace a upozornění na stránkování/zkrácení.

Nemění se schvalovací a zálohovací brány oprav ani oprávnění MCP. Instalátor
podle předchozího výslovného požadavku nevytváří novou předinstalační HA/OneDrive
zálohu. Záloha před opravou systému zůstává povinná.

## Ověření a meze

Nové automatické testy reprodukují překročení limitu RC1 pomocí 2 000 incidentů,
ověřují stránkování, UTF-8 velikost, zachování počtů/schválení, start smyček,
selhání databáze a následné zotavení. Počty skutečně provedených testů jsou
v přiloženém verification.json. Testy nevolají placené API ani produkční HAOS.

Živá přejímka této verze na vašem HAOS, obnova zálohy a end-to-end oprava
nebyly provedeny. RC2 je cílená oprava hlášené regrese, nikoli tvrzení, že
všechny konektory nebo všechny možné opravy již fungují bezchybně.
