# HADS 5.0.0-rc1 — přestavba provozního jádra

Kandidát připravený 24. 9. 2026. Není nasazený ani otestovaný na skutečném HAOS. Nahrazuje způsob řízení práce, datový model panelu a přenos externích odpovědí. Není to úplný přepis každého modulu ani důkaz, že už umí automaticky opravit libovolnou závadu. Ověřené parsování a bezpečnostní motor zůstávají zachovány. Slug `local_hads4`, adresáře a databáze zůstávají kvůli kompatibilitě.

## Co řeší doložené selhání

Export z 23. 9. ukázal několik OOM ukončení Pythonu v kontejneru HADS (např. anon-rss 551880 kB), restart s kódem 137 a téměř vyčerpaný swap na přibližně 2GB hostu. Současně obsahuje dřívější ukončení jiných procesů. Nelze tvrdit, že veškerý tlak na RAM způsobil výhradně HADS, ani určit přesnou alokaci bez profilování běžícího procesu.

Nové provozní jádro:

- HTTP naslouchá před inicializací databáze. `/health` ověřuje jen dostupnost procesu; `/ready` vyžaduje čerstvý dokončený snapshot. Jedno není zaměňováno za druhé.
- Panel čte hotový snapshot. Nevyvolává síťovou diagnostiku ani placenou AI. SQL projekce nečte celé důkazy, výzkum a náhledy oprav do každého přehledu. Detail si ponechává úplná uložená data.
- Náročná kontrola, plánování, incidentní chat, ruční refresh konektorů a opravná dávka se dělí o jednu řízenou pracovní kapacitu. Lehké obnovování přehledu probíhá vedle nich. Zápisy stále chrání původní bezpečnostní brány.
- Před přijetím těžké práce se vyžaduje nejméně 192 MiB dostupné paměti a RSS HADS pod 192 MiB. Kontroluje se host i omezení cgroup v2. Neznámá rezerva znamená odklad, ne neověřené „OK“.
- `runtime_jobs.db` uchovává stav úloh. Běh přerušený restartem dostane nejméně 15minutový odstup; selhání exponenciální odstup. Nedostatek RAM další pokus odloží o 5 minut.
- Čtení HTTP dat má byte limity: log 1 MiB, Supervisor JSON 4 MiB, externí diagnostika/AI 2 MiB. Překročení se hlásí jako neúplný zdroj, nikoli úspěšný prázdný report. Rozsah sběru není tiše „úplný“, pokud zdroj limit překročí.
- Cache odpovědí je omezená součtem bytů a dobou platnosti. Surové logy se v ní neuchovávají. HTTP používá nejvýše šest obslužných vláken a konečný timeout. HADS nereingestuje vlastní add-on log jako nové HA incidenty.

Toto je řízení zátěže, **nikoli tvrdá garance maximálního RSS**. Parsování YAML, WebSocket rámce, starší interní dotazy a externí knihovny ještě nemají procesovou izolaci. Extrémně velká databáze nebo nedostatek paměti celého HAOS mohou práci stále zastavit. Právě proto zůstává označení RC.

## AI: cache není povolení utrácet

Podle ověřené dokumentace OpenAI je stabilní instrukční prefix v prvním developer vstupu a proměnné důkazy v následujícím user vstupu. Explicitní breakpoint s `ttl: 30m` je povolen pro rozpoznané GPT-5.6/GPT-6 názvy; neznámé rodiny ponechávají implicitní cache. Nastavení umožňuje zvolit implicitní režim i ručně. Model se upgradem nemění a kontext se uměle nenafukuje kvůli minimální délce pro cache.

HADS ukládá skutečné `cached_tokens` a `cache_write_tokens` z odpovědi do evidence spotřeby. Cache nemusí mít hit; její vytvoření může být dražší než běžný vstup. Neuvádíme pevnou procentní úsporu ani fiktivní dolarový strop.

Stejný úplný AI požadavek ke stejnému případu a identitě poskytovatele se 24 hodin znovu neodesílá, ani po restartu. Nová data nebo jiná otázka představují jiný požadavek. Zůstávají povinné limity, výslovný souhlas s placenou AI a zvlášť s placeným webem. Výchozí konfigurace má placené funkce vypnuté; při upgradu se zachovává uživatelské nastavení, takže před nasazením ověřte, že jsou vypnuté. Testy nezavolaly placené API.

## Diagnostické zdroje a standardy

| Zdroj | Co je v tomto kandidátu ověřeno či změněno | Co tím není prokázáno |
| --- | --- | --- |
| Core, Supervisor, host, DNS/audio/multicast, aplikace | Ohraničené čtení, sekvenční sběr, viditelné selhání zdroje, `/logs/latest` tam, kde existuje | Dostupnost všech zdrojů v konkrétním HAOS |
| Automation Inspector | Schéma v2, revalidace pomocí ETag/304, odmítnutí neznámého schématu | Že každá budoucí verze zachová tento kontrakt |
| Entity Availability | Offline/stale/baterie/signál; MTBF/MTTR/offline_events připojeny jako historie k existujícímu problému | Historická nestabilita sama o sobě není dnešní porucha |
| HAGHS | Současné příznaky rec_ram_pressure, rec_io_pressure, rec_disk_low aj. mají srozumitelný význam | Nízké skóre samo neprokazuje příčinu chyby automatizace |
| Spook | Zachované čtení konkrétních Repairs a křížová kontrola referencí | Že je potřeba Spook ručně „zmáčknout“, nebo že lze automaticky smazat statistiky |
| Watchman | Zachován TXT i podporovaná strukturovaná odpověď; report má skutečný limit bez tichého useknutí | Nález v archivu nebo disabled automatizaci není automaticky aktivní závada |
| HA-MCP / Hamster MCP | Vyjednání podporované verze až 2025-11-25, protokolová hlavička, bounded SSE čtení končící odpovědí na správné ID | Nejde o plnou implementaci všech MCP transportů a capabilities; read-only allowlist zůstává |
| HADocs | Zachován existující JSON adaptér, doporučení jako důkazy, nikoli schválené zásahy | Nebyl ověřen nový univerzální endpoint ani úplné využití každé funkce HADocs |

„Nejnovější“ není automatické volání všeho, co doplněk nabízí. Mazací, vytvářecí a řídicí funkce MCP nejsou diagnostická oprávnění. Nesprávné nebo neúplné odpovědi nesmějí odemknout opravu.

## Instalace a záloha

Instalátor zůstává bash skript, **nikoli Python skript**. Neinstaluje další integraci, nepovoluje placenou AI, nerestartuje Core a nemaže databázi HADS.

Varianta z 25. 9. 2026 na výslovnou žádost **nevytváří ani neověřuje předinstalační HA/OneDrive zálohu**. Také při aktualizaci výslovně vypíná automatickou zálohu doplňku Supervisoru (`backup: false`). Vyžaduje pouze:

1. `ha`, `python3` a běžné nástroje používané dosavadním instalátorem;
2. dostupný `SUPERVISOR_TOKEN` v prostředí terminálu — neposílat do chatu. Čtecí kontrola přístupu proběhne před výměnou zdrojů. OneDrive ani rclone nejsou podmínkou instalace.

Spuštění v HAOS terminálu po uložení instalátoru do `/config`:

```bash
bash /config/HADS4_install_5.0.0-rc1.sh
```

Původní adresář zdrojů se zachová přesunem do `/share/hads4_installer_backups`. To není záloha databáze HADS ani celého systému a neumožňuje zaručený návrat po migraci databáze. Při instalaci bez aktuální úplné zálohy může být návrat ke staré verzi omezený. Starší existující zálohy se nemažou. Nouzový přístup nezávislý na Core musí zůstat dostupný.

Změna se týká pouze instalace. Exporty běžícího HADS používají `onedrive.upload`. Brána oprav v běžícím HADS nadále vyžaduje vlastní ověřený rescue balík (čtecí službu/companion); instalátor tuto ochranu nevypíná. Nativní zálohovací pomocné funkce zůstávají v kódu a testech, ale tento instalátor jejich kroky `preflight` ani `cloud` nespouští.

Aktualizace používá zdokumentovaný Supervisor store update a kontrolu `version_latest` i výsledné verze. Pouhý rebuild staré verze není náhradou aktualizace. Při chybě aktualizace zůstává zdrojová záloha v `/share/hads4_installer_backups`; neprovádí se neověřený automatický downgrade databáze.

## Ověření a omezení

Autoritativní výsledek offline testů je v souboru `HADS4_5.0.0-rc1-verification.json` vedle instalátoru. Zahrnuje také skutečný lokální HTTP server s nedostupnou inicializací, simulované omezení paměti, přerušené úlohy, velkou odpověď, kompaktní projekci důkazů, cache, konektory a bezpečnost schvalování. Nejde o běh Docker obrazu na HAOS.

Před označením za finální zbývá na konkrétním zařízení ověřit: start a aktuální verzi Supervisoru; stabilní RSS při několika cyklech; skutečné výstupy všech konektorů; cache a náklady na jednom výslovně povoleném požadavku; OneDrive readback; jeden konkrétní náhled → schválení → záloha → oprava → funkční ověření; chování při selhání. Než to proběhne, nepovolovat hromadné opravy ani placený výzkum na pozadí.

## Použité primární zdroje (ověřeno 23.–24. 9. 2026)

- [OpenAI prompt caching](https://developers.openai.com/api/docs/guides/prompt-caching)
- [Supervisor API](https://developers.home-assistant.io/docs/api/supervisor/endpoints/)
- [MCP HTTP transport](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports) a [životní cyklus](https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle)
- [Automation Inspector](https://github.com/ITSpecialist111/Automation-Inspector)
- [Entity Availability](https://github.com/italo-lombardi/Home-Assistant-EntityAvailability)
- [HAGHS](https://github.com/HA-Pulse/home-assistant-global-health-score)
- [Spook](https://github.com/frenck/spook), [Watchman](https://github.com/dummylabs/thewatchman)
- [HA-MCP dokumentace](https://github.com/homeassistant-ai/ha-mcp/blob/master/homeassistant-addon/DOCS.md), [Hamster MCP](https://github.com/altendky/hamster-mcp), [HADocs](https://github.com/SirBlondieDK/HADocs)
- [Nativní OneDrive](https://www.home-assistant.io/integrations/onedrive/), [OneDrive backup agent](https://github.com/home-assistant/core/blob/dev/homeassistant/components/onedrive/backup.py)
- [HA 2026.9.3 backup HTTP API](https://github.com/home-assistant/core/blob/2026.9.3/homeassistant/components/backup/http.py), [backup manager](https://github.com/home-assistant/core/blob/2026.9.3/homeassistant/components/backup/manager.py)
