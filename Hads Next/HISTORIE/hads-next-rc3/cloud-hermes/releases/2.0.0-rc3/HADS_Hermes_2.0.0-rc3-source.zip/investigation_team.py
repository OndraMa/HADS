"""Sequential read specialists with durable receipts, no autonomous HA writes.

These roles execute explicit native reads. They are not parallel Hermes forks.
Hermes remains the bounded reasoning coordinator behind the existing broker.
"""
import hashlib
import json
import sqlite3
import time

SCHEMA = '''CREATE TABLE IF NOT EXISTS specialist_runs (
 id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL,
 role TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL,
 finished_at TEXT, evidence_hash TEXT, result_json TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS specialist_case ON specialist_runs(case_id,id);'''
TITLES = {'devices': 'Zařízení a systém', 'automations': 'Automatizace a skripty',
          'logs': 'Protokoly v čase incidentu', 'connectors': 'Nálezy diagnostických doplňků'}


def initialize(db, now):
    with db() as conn:
        conn.executescript(SCHEMA)
        conn.execute("UPDATE specialist_runs SET status='interrupted',finished_at=? WHERE status='running'", (now(),))


def canonical(value):
    if isinstance(value, dict):
        return {k: canonical(v) for k, v in value.items() if k not in {'fetched_at', 'collected_at', 'checked_at', 'observed_at'}}
    return [canonical(x) for x in value] if isinstance(value, list) else value


def run(db, now, case_id, role, function, scrub):
    if role not in TITLES:
        raise ValueError('Unknown specialist role')
    with db() as conn:
        cursor = conn.execute('INSERT INTO specialist_runs(case_id,role,status,created_at) VALUES(?,?,?,?)',
                              (case_id, role, 'running', now()))
        run_id = int(cursor.lastrowid)
    started = time.monotonic()
    try:
        value = function()
        clean = scrub(value)
        encoded = json.dumps(clean, ensure_ascii=False, default=str)
        if len(encoded.encode()) > 24000:
            clean = {'status': 'partial', 'truncated': True, 'note': 'Výstup specialisty přesáhl 24 KiB; nelze prohlásit úplné vyšetření.'}
            encoded = json.dumps(clean, ensure_ascii=False)
        # Completion means the step returned evidence, never that HA is healthy.
        status = 'partial' if _gaps(clean) else 'completed'
        digest = hashlib.sha256(json.dumps(canonical(clean), sort_keys=True, default=str).encode()).hexdigest()
        with db() as conn:
            previous = conn.execute('SELECT id FROM specialist_runs WHERE case_id=? AND role=? AND evidence_hash=? AND id<>? ORDER BY id DESC LIMIT 1',
                                    (case_id, role, digest, run_id)).fetchone()
            receipt = {'id': run_id, 'role': role, 'title': TITLES[role], 'status': status,
                       'duration_ms': int((time.monotonic()-started)*1000), 'same_evidence_as': previous[0] if previous else None,
                       'result': clean, 'note': 'Dokončený čtecí krok není potvrzení příčiny ani opravy.'}
            conn.execute('UPDATE specialist_runs SET status=?,finished_at=?,evidence_hash=?,result_json=? WHERE id=?',
                         (status, now(), digest, json.dumps(receipt, ensure_ascii=False, default=str), run_id))
        return receipt
    except Exception as exc:
        # Callers supply a redactor; errors must not persist tokens or secret URLs.
        try:
            error = str(scrub(str(exc)))[:500]
        except Exception:
            error = 'Čtecí krok selhal; podrobnost nebyla uložena, protože redakce tajných údajů selhala.'
        with db() as conn:
            conn.execute('UPDATE specialist_runs SET status=?,finished_at=?,result_json=? WHERE id=?',
                         ('failed', now(), json.dumps({'error': error}), run_id))
        return {'id': run_id, 'role': role, 'title': TITLES[role], 'status': 'failed', 'result': {'error': error}}


def _gaps(value):
    if isinstance(value, dict):
        if value.get('error') or value.get('errors') or value.get('available') is False or value.get('truncated') or value.get('coverage_gaps') or value.get('status') in {'unavailable', 'deferred', 'failed', 'partial'}:
            return True
        return any(_gaps(v) for v in value.values())
    return any(_gaps(v) for v in value) if isinstance(value, list) else False


def latest(db, case_ids):
    ids = [int(x) for x in case_ids][:100]
    if not ids:
        return []
    try:
        with db() as conn:
            rows = conn.execute('SELECT id,role,status,created_at,finished_at,result_json FROM specialist_runs WHERE case_id IN ('+
                                ','.join('?' for _ in ids)+') ORDER BY id DESC LIMIT 16', ids).fetchall()
        return [{**{k: row[k] for k in row.keys() if k != 'result_json'}, 'title': TITLES.get(row['role'], row['role']),
                 'result': json.loads(row['result_json'])} for row in rows]
    except sqlite3.OperationalError as exc:
        if 'no such table' not in str(exc).lower():
            raise
        return []
