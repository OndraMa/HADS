# HADS 5.1.0-rc3 — instalace a co nastavit

Nahrajte instalátor do /config a spusťte v HA terminálu:

```bash
bash /config/HADS4_install_5.1.0-rc3.sh
```

Potom Ctrl+F5 a ověřit 5.1.0-rc3. Nastavení a databáze HADS se zachovávají.
Podle předchozí výslovné žádosti se nevytváří nová předinstalační HA/OneDrive
záloha. Povinná ověřená záloha před vlastní opravou systému zůstává zachovaná.

## HA-MCP — ponechte současnou instalaci

Neinstalujte další kopii a nezaměňujte HA-MCP s novým oficiálním MCP v Core.
V HA-MCP nastavte, pokud volby vaše verze nabízí:

```yaml
read_only_mode: true
enable_tool_search: false
redact_secrets: true
```

Změňte jen příslušné volby, nenahrazujte celou konfiguraci. Pokud potřebujete
Tool Search pro jiné klienty, ponechte ho a připněte podporované čtecí nástroje:
ha_search, ha_get_state, ha_get_entity, ha_get_history,
ha_get_automation_traces, ha_get_system_health. Změna doplňku může vyžadovat
restart tohoto doplňku; Core kvůli tomu naslepo nezastavujte.

V HADS ponechte skutečnou Connect URL v ha_mcp_url. OpenAI klíč do pole
ha_mcp_token nepatří. URL s private/webhook cestou je tajný přihlašovací údaj.
Nevystavujte ji do internetu a neposílejte ji do chatu ani na screenshotu.
Podrobný průvodce je v samostatném souboru HA-MCP-nastaveni-CS.md.

Potom Diagnostické zdroje → Ověřit všechna spojení. Ve vašem předchozím výpisu
už byl katalog 40 nástrojů, z toho šest podporovaných čtecích. To není důvod
vše instalovat znovu. Důležité je čerstvé cílené čtení, nikoli jen velikost katalogu.
Při dalším vyšetření známého incidentu ověřte stav/historii správné entity
a konkrétní chyby/skipped kroky. Vyhledání jiné podobné entity není správná diagnóza.

## Zablokovaná záloha B-2

Po instalaci otevřete Opravy a zálohy. RC3 zobrazuje uložený důvod a chyby
ověření. Chybí-li hads_rescue.verify, samotný HADS ji do Core neinstaluje.
Dodávaný HADS_Rescue_Readback_0.1.0.zip je samostatná volitelná integrace.
Její kompatibilita byla dříve ověřena zdrojově pouze pro Core 2026.9.2;
instalaci a cloudové ověření na vašem aktuálním Core je nutné ověřit zvlášť.
Neprovádějte instalaci companionu ani restart Core bez dostupné obnovy a přístupu.

Není-li nezávislé ověření funkční, opravy zůstanou zablokované. ACK ani ruční
odškrtnutí povinné zálohy není řešení. Před novým spuštěním zkontrolujte přesný
náhled každé opravy; starší B-2 nemusí obsahovat dnešní plány #6/#7.

## AI a kredity

Instalace AI nezapíná. Uložený klíč, povolení analýzy a povolení placených
volání jsou různé věci. Pro první kontrolu ponechte placenou AI vypnutou.
Po ověření lokálního sběru lze výslovně povolit analýzu a placená volání;
automatický výzkum na pozadí má samostatnou volbu ai_background_research.
Pro zkušební provoz doporučujeme začít dvěma požadavky za den a dvěma na případ,
bez placeného webu. To je limit počtu volání, nikoli garantovaný dolarový strop.
Nepovolujte neomezené volání pouze proto, že fronta obsahuje mnoho položek.

## Co ověřit

1. Načtení panelu, stránkování a časy dokončených cyklů.
2. Plány #6/#7: přesný cíl, před/po, riziko a verifikace; žádné automatické schválení.
3. B-2: konkrétní důvod blokace a ID jejích plánů.
4. DNS chyby nemají být vysvětlené názvem telefonu; autentizační chyby iCloudu
   mají doporučit ověření přihlášení, nikoli přepis názvu.
5. Při 403 ověřit oprávnění účtu/Ingress; při 502/504 dostupnost backendu.
6. Živá oprava, cloud readback a obnova ještě nejsou potvrzené offline testy.
