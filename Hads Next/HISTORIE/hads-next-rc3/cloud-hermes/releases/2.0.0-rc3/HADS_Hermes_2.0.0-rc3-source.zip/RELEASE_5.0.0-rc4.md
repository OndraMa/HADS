# HADS 5.0.0-rc4 — HA-MCP s navazujícím čtením a průvodcem

3. 10. 2026. Navazuje na připravenou RC3; původní zdroje jsou zachovány.

## Nové změny

- Hláška bez ID entity nemusí skončit jen u ha_search. Úplný, nezkrácený a bezchybný JSON výsledek se strojovým entity_id umožní navázat čtecími recepty pro prvního kandidáta: stav, registr, případná stopa a historie v okně události. Kandidát není potvrzená totožnost ani příčina. Volný text, neplatná ID a chybné/částečné výsledky další čtení nerozšiřují.
- Diagnostické zdroje zobrazují konkrétní pomoc HA-MCP: chybějící adresa, selhání spojení, katalog bez podporovaných čtecích nástrojů, neúplný katalog a připravenost čtecích nástrojů. Expirace sondy neprezentuje staré ověření jako aktuální spojení. Ve veřejné pomoci nejsou Connect URL ani tokeny.
- Explicitní cache podporuje gpt-6.1-sol a jeho datumový snapshot. Neznámé minor řady nepřebírají schopnost automaticky. Model se nemění; implicitní volba explicitní parametry neposílá.
- Český průvodce rozlišuje doplněk HA-MCP a serverovou integraci v Core, Read Only Mode, viditelnost nástrojů a cílené čtení od katalogu.

## Zachované opravy a bezpečnost

RC3 opravy WAL čtení panelu, kratších zápisových dávek, sledování diagnostických úloh, samostatného plánovače, viditelnosti plánů, logových testů a DNS vysvětlení zůstávají.

Maximálně šest volání nástrojů a 60sekundový rozpočet cílené MCP diagnostiky zůstává. Bez schématu se parametry nehádají. Nová jména nástrojů, služby ani obecné shell akce nejsou povolené. Schválení konkrétního plánu a nezávisle ověřená záloha jsou nadále podmínkou opravy. Read Only Mode MCP slouží diagnostice; opravy zajišťuje oddělený vykonavatel HADS.

Placené API, web a pozadí se automaticky nezapínají; uložené volby zůstávají. MCP čtení samo nevyžaduje OpenAI účet. Instalátor zůstává na dřívější výslovný požadavek bez nové předinstalační HA/OneDrive zálohy s místní kopií zdrojů; ta není systémová záloha.

## Ověření a hranice

Autoritativní offline výsledek: HADS4_5.0.0-rc4-verification.json. Obsahuje automatické testy, kompilaci Pythonu, JS regresní scénáře, integritu payloadu/ZIP, YAML a dostupnou kontrolu Bash syntaxe. Nové testy používají podvržené odpovědi MCP, nikoli váš HA server.

Na HAOS RC4 v tomto vydání nasazena nebyla. Skutečné konektory, placená AI, úspora cache a oprava / obnovení zálohy nejsou živě ověřené. Nejde o univerzální autonomní opravy ani využití všech funkcí poskytovatelů. Computer use, Agents API, MCP Events a plugin panel se tímto vydáním nezavádějí.

Nastavení a akceptační postup: MANUAL_5.0.0-rc4_CS.md a HA_MCP_NASTAVENI_CS.md.
