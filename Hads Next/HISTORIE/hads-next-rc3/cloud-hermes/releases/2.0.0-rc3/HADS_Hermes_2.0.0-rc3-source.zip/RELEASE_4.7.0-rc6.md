# HADS 4.7.0-rc6 — obnova diagnostického toku

Navazuje na RC5, jejíž opravy otevírání incidentů, priorit a dostupnosti UI zůstávají zahrnuty.

## Implementované opravy

- Watchman: rozpoznání vnořených parametrů `advanced_options.fields.force_parsing`, čerstvý report bez vytváření souboru, obnovení nejvýše jednou za 15 minut při běžném refreshi a při výslovném ověření. Poslední platná strukturovaná odpověď nezmizí při dalším refreshi; zachovává čas původního získání a po 30 minutách se nepoužívá jako čerstvá. Přidána dokumentovaná cesta `thewatchman_report.txt`. Chyba získání reportu je viditelná u konektoru.
- HA-MCP: rozpoznání integrace `ha_mcp_tools`, nikoli pouze starého add-onu. Pokud Core log obsahuje její řádek s dokumentovanou webhook adresou, HADS použije pouze cestu přes lokální Supervisor proxy. Nedohledaná adresa znamená neověřené spojení s konkrétním pokynem k nastavení Connect URL. Vlastní secret, vypnutý webhook či jiné formáty logů vyžadují explicitní adresu. Instalace samotných File & YAML Tools není důkaz běžícího MCP serveru.
- MCP: Supervisor token se neposílá na libovolnou externí adresu. Chybové odpovědi nástrojů se nepočítají jako použitá data. Webhook tajemství se rediguje.
- AI: rozlišení kvóty, autentizace, konfigurace požadavku, rate limitu a výpadku. Společné odložení dalších volání je uloženo v databázi; neodeslané odložené požadavky nečerpají lokální limit volání. Změna klíče/modelu dovolí nový pokus. Neúspěšná odpověď nevytvoří plán. Vzdálené texty chyb ani klíče se neukládají do stavové tabulky.
- Vyšetřování má samostatného pracovníka s ochranou před dvojím spuštěním; dlouhá AI analýza již neobsazuje smyčku sběru protokolů. Panel ukazuje aktuální incident a počet zpracovaných položek. Síťový refresh konektorů stále může čekat na své časové limity.
- Restart označí nedokončené plánovací běhy jako přerušené, nikoli stále běžící.
- Obecné „příčina nebyla určena“ není společný klíč pro nesouvisející technické události. Při novém seskupení se již schválený plán vrátí k novému souhlasu. Historie původního případu se nemaže.
- Opravné plány bez viditelného aktivního incidentu jsou dohledatelné na stránce Opravy, včetně upozornění na chybějící vazbu. Zobrazení neobchází kontrolu schválení ani zálohy.

## Ověření a hranice vydání

Počet skutečně spuštěných testů a kontroly balíčku jsou v `HADS4_4.7.0-rc6-verification.json`. Testy jsou offline; používají izolovanou databázi, simulované konektory a UI kontrakty. Tento release není důkazem funkčnosti všech konektorů na konkrétním HAOS ani univerzálního autonomního opraváře. Nemění API model, nenavyšuje rozpočet a neinstaluje nové doplňky.

Nadále se automaticky provádí jen diagnostika. Skutečný zásah vyžaduje konkrétní podporovaný plán, souhlas a ověřenou povinnou zálohu. Nenalezení bezpečné opravy nesmí být nahrazeno vymyšleným úkonem. Úplná korelace všech zdrojů na zařízení a všechny možné třídy oprav nejsou tímto balíčkem dokončeny.

## Povinná akceptace po nasazení

1. Ověřit RC6 v UI a otevřít incident během probíhajícího vyšetřování.
2. Porovnat čerstvé nálezy Watchmanu, Spooku, HADocs, Inspectoru a Entity Availability se zdrojovými rozhraními. HAGHS má dodat metriky, ne duplicitní nové incidenty. MCP musí doložit konkrétní úspěšné čtecí volání; katalog nástrojů sám nestačí.
3. Zkontrolovat konkrétní vysvětlení případné chyby AI a další termín pokusu. Neodstraňovat limity naslepo.
4. Pro vybraný doložený problém připravit přesný plán, prohlédnout změnu a výslovně jej schválit. Ověřit jeho viditelnost a spouštěcí tlačítko.
5. Před jakoukoli změnou prokázat OneDrive readback správného záchranného balíku a plnou zálohu. Následně ověřit funkci, výsledek v historii a možnosti návratu. To se nesmí předstírat offline testem.

## Podklady k opravám konektorů a AI

- [Watchman service schema](https://github.com/dummylabs/thewatchman/blob/master/custom_components/watchman/services.yaml)
- [HA-MCP in-process server](https://github.com/homeassistant-ai/ha-mcp/blob/master/docs/in-process-server.md)
- [OpenAI API error codes](https://developers.openai.com/api/docs/guides/error-codes)

Tyto odkazy jsou podklady konkrétních změn, nikoli tvrzení, že byly živě prověřeny všechny verze doplňků.
