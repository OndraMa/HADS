"""Music Assistant diagnostics only; no playback, reload, config or shell.

Canonical command names come from the upstream FastMCP command registry.
Catalogues/schemas are evidence, never permission to widen this list.
"""
import json
from jsonschema import Draft202012Validator
from mcp_diagnostics import bind, result_error, result_partial

COMMANDS = frozenset({'fastmcp/debug/health', 'fastmcp/debug/recent_events',
                      'fastmcp/debug/tail_log', 'fastmcp/debug/event_buffer_stats'})


def unpack(value):
    for _ in range(5):
        if isinstance(value, str):
            if len(value.encode()) > 24000:
                return None
            try:
                value = json.loads(value)
            except ValueError:
                return None
        elif isinstance(value, dict) and isinstance(value.get('structuredContent'), dict):
            value = value['structuredContent']
        elif isinstance(value, dict) and isinstance(value.get('content'), list):
            texts = [b.get('text') for b in value['content'] if isinstance(b, dict) and b.get('type') == 'text']
            if len(texts) != 1:
                return None
            value = texts[0]
        else:
            return value
    return None


def validates(schema, value):
    # Never retrieve an external schema supplied by a remote MCP server.
    def local(item, depth=0):
        if depth > 20:
            return False
        if isinstance(item, dict):
            return not any(k in item for k in ('$ref', '$dynamicRef')) and all(local(v, depth+1) for v in item.values())
        return all(local(v, depth+1) for v in item) if isinstance(item, list) else True
    try:
        return local(schema) and not list(Draft202012Validator(schema).iter_errors(value))
    except Exception:
        return False


def collect(catalog, call, skipped):
    tools = {t.get('name'): t for t in catalog.get('tools', []) if isinstance(t, dict)}
    required = ('search_tools', 'get_tool_schema', 'call_tool')
    if not all(name in tools for name in required):
        skipped.append({'tool': 'music_assistant_mcp', 'reason': 'Chybí podporované FastMCP discovery rozhraní; ovládání nebylo povoleno.'})
        return
    # Six bounded calls: discovery + exact schema + read, twice.
    for command, values in [('fastmcp/debug/health', {}),
                            ('fastmcp/debug/recent_events', {'limit': 50})]:
        name = 'ma_api:' + command
        args, reason = bind(tools['search_tools'], {'query': command, 'limit': 5})
        found = call('search_tools', args, 'Vyhledání přesného čtecího příkazu Music Assistantu') if args is not None else None
        data = unpack((found or {}).get('result'))
        if not found or found.get('error') or found.get('truncated') or result_error(data) or not isinstance(data, dict) or not any(isinstance(i, dict) and i.get('name') == name for i in data.get('items', [])):
            skipped.append({'tool': name, 'reason': reason or 'Přesný diagnostický nástroj není dostupný pro tento token/verzi.'})
            continue
        args, reason = bind(tools['get_tool_schema'], {'tool_name': name})
        response = call('get_tool_schema', args, 'Ověření schématu konkrétního diagnostického čtení') if args is not None else None
        schema = unpack((response or {}).get('result'))
        if not response or response.get('error') or response.get('truncated') or result_partial(schema) or not isinstance(schema, dict) or schema.get('name') != name or schema.get('command') != command or command not in COMMANDS:
            skipped.append({'tool': name, 'reason': reason or 'Schéma neprokázalo povolený čtecí příkaz.'})
            continue
        inner, reason = bind({'inputSchema': schema.get('inputSchema')}, values)
        outer = {'name': name, 'arguments': inner, 'response_mode': 'full', 'max_items': 50}
        if inner is None or not validates(schema.get('inputSchema'), inner) or not validates(tools['call_tool'].get('inputSchema'), outer):
            skipped.append({'tool': name, 'reason': reason or 'Nepodporované schéma; požadavek nebyl odeslán.'})
            continue
        call('call_tool', outer, 'Čtecí diagnostika Music Assistantu; není důkaz fyzického přehrávání', read_path=True)
