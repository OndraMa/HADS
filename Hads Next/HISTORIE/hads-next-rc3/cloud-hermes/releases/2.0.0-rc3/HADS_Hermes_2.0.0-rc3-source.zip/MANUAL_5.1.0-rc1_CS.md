# HADS 5.1.0-rc1 — instalace a přejímka

## Instalace

Nahrajte instalátor do `/config` a v terminálu spusťte:

```bash
bash /config/HADS4_install_5.1.0-rc1.sh
```

Nespouštět přes python3. Instalátor zachovává nastavení a uložená data. Podle předchozího požadavku nevytváří novou předinstalační HA/OneDrive zálohu; tato výjimka se nevztahuje na žádnou následnou opravu systému.

## Co nyní uvidíte

1. **Vaše rozhodnutí / výsledky zásahů:** konkrétní plány, potřebné informace, selhané opravy a ověřování. Přijetí závěru stále není schválení opravy.
2. **Co může bránit automatizaci či ovládání:** případy se skutečným nebo možným funkčním dopadem. HADS musí odlišit současné čtení a historický problém.
3. **Dopad neurčen:** nejsou dostatečné důkazy. Nejde o vyřešený problém.
4. **Technické důkazy a krátké výpadky:** rozbalitelné, stále dostupné. Nejsou automaticky uživatelskými úkoly.

V detailu incidentu najdete stručné nativní zjištění, čas čtení, další krok a mezery v datech. Úplný výstup je v Důkazech. Konverzace umožňuje doplnit skutečný průběh události. HADS nesmí sám zkoušet rozsvěcet, vypínat, prozvánět telefon nebo měnit konfiguraci jako součást read-only diagnostiky.

## Co ověřit po instalaci

1. Obnovit Ctrl+F5, ověřit verzi a dokončení analýzy. Spuštění/zařazení úlohy není dokončení.
2. Diagnostické zdroje → Otestovat sběr protokolů; při chybě stáhnout diagnostiku JSON. Částečné načtení není OK všech zdrojů.
3. Ověřit všechna spojení: HA, Spook, Watchman, Automation Inspector, HADocs, Entity Availability, HAGHS a nakonfigurované MCP. Nainstalovaný doplněk či seznam nástrojů není důkaz použitého reportu. Přesný postup MCP zůstává v `HA_MCP_NASTAVENI_CS.md`.
4. Nechat proběhnout plánovač. U incidentu s přesným `automation.*` / `light.*` má být čas nativního čtení, stav/historie či konkrétní mezera v pokrytí. Pokud log neobsahuje přesný identifikátor, HADS nesmí hádat podobně pojmenované zařízení.
5. Testovací případy: selhaná automatizace má hlavní pozornost; Error fetching version a krátké tracebacky jsou technické důkazy; připravený plán či selhaná oprava se nesmí ztratit ani u technického případu. Funkční fyzický výsledek potvrďte vlastním feedbackem.
6. Před schválením zkontrolovat přesnou změnu, riziko, návrat a následný test. Pokud plán chybí, HADS musí uvést proč; žádný prázdný nebo pouze diagnostický plán nesmí aktivovat opravy.
7. Ověřená OneDrive záloha musí být dostupná před systémovým zápisem. Při selhání zůstává brána zamčená. Nesnažit se ji obejít.

## AI a náklady

Klíč sám AI nespouští. Placené volby a jejich existující denní limity zůstávají beze změny. Technický šum se automaticky nepředává AI, ale přímá konverzace ji může použít. Limity počtu volání nejsou dolarový rozpočet; pro oddělení HADS použijte samostatný API projekt/klíč a sledujte využití u poskytovatele. Bez živé kontroly a reálného funkčního případu nejde potvrdit kompletní provozní spolehlivost.
