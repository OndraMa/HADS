"""Cache-aware Responses input; provider-specific options are capability gated."""
import copy
import re


def prepare(body, mode='explicit'):
    result = copy.deepcopy(body)
    items = list(result.get('input') or [])
    if not items or items[0].get('role') != 'developer':
        return result
    stable = str(result.pop('instructions', '')).strip() + '\n\n' + str(items[0]['content'])
    block = {'type': 'input_text', 'text': stable.strip()}
    # Documentation verified for GPT-5.6, GPT-6 and GPT-6.1 Sol; unknown families fall back
    # to the provider's implicit behavior. Never auto-switch the user's model.
    supported = re.fullmatch(r'gpt-(?:5\.6|6)(?:-[a-z0-9.-]+)?|gpt-6\.1-sol(?:-\d{4}-\d{2}-\d{2})?', str(result.get('model', '')))
    if mode == 'explicit' and supported:
        block['prompt_cache_breakpoint'] = {'mode': 'explicit'}
        result['prompt_cache_options'] = {'mode': 'explicit', 'ttl': '30m'}
    items[0] = {'role': 'developer', 'content': [block]}
    result['input'] = items
    return result
