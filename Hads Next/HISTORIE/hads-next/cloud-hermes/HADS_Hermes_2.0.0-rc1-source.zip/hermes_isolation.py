"""Fail-closed Landlock ABI 4 confinement. amd64/aarch64 Linux only.

Filesystem writes only inside temporary HOME, no exec rights anywhere, no HA
configuration/credentials/backups access. TCP connect only to broker port.
The Python network guard additionally restricts the address to loopback.
"""
import ctypes
import os
from pathlib import Path
import sys


def confine(home, port):
    if sys.platform != "linux":
        raise RuntimeError("Hermes requires Linux Landlock ABI 4")
    home = Path(home).resolve(strict=True)
    if not home.name.startswith("hads-hermes-") or home.parent != Path("/tmp") or not 1 <= int(port) <= 65535:
        raise ValueError("Invalid private worker directory or broker port")
    libc = ctypes.CDLL(None, use_errno=True)
    libc.syscall.restype = ctypes.c_long
    create, add, restrict = 444, 445, 446
    if libc.syscall(create, 0, 0, 1) < 4:
        raise RuntimeError("HAOS kernel lacks Landlock ABI 4; Hermes remains disabled")

    class Ruleset(ctypes.Structure):
        _fields_ = [("fs", ctypes.c_uint64), ("net", ctypes.c_uint64)]

    class PathRule(ctypes.Structure):
        _pack_ = 1
        _fields_ = [("access", ctypes.c_uint64), ("fd", ctypes.c_int32)]

    class PortRule(ctypes.Structure):
        _fields_ = [("access", ctypes.c_uint64), ("port", ctypes.c_uint64)]

    rights = (1 << 15) - 1
    read = (1 << 2) | (1 << 3)
    attr = Ruleset(rights, 3)
    fd = libc.syscall(create, ctypes.byref(attr), ctypes.sizeof(attr), 0)
    if fd < 0:
        raise RuntimeError("Cannot create worker confinement")
    try:
        paths = [(Path(p), read) for p in ("/usr", "/lib", "/lib64", "/opt/hermes", "/opt/sqlite-fixed", "/app", "/etc/ssl",
                "/etc/ld.so.cache", "/etc/hosts", "/etc/resolv.conf", "/etc/nsswitch.conf", "/etc/localtime",
                "/dev/urandom", "/dev/random")]
        paths += [(home, rights & ~1), (Path("/dev/null"), (1 << 1) | (1 << 2))]
        for target, allowed in paths:
            if not target.exists():
                continue
            if not target.is_dir():
                allowed &= ~((1 << 3) | sum(1 << bit for bit in range(4, 14)))
            path_fd = os.open(target, os.O_PATH | os.O_CLOEXEC)
            try:
                rule = PathRule(allowed, path_fd)
                if libc.syscall(add, fd, 1, ctypes.byref(rule), 0) != 0:
                    raise RuntimeError("Cannot restrict worker filesystem")
            finally:
                os.close(path_fd)
        net = PortRule(2, int(port))
        if libc.syscall(add, fd, 2, ctypes.byref(net), 0) != 0:
            raise RuntimeError("Cannot restrict worker TCP port")
        if libc.prctl(38, 1, 0, 0, 0) != 0 or libc.syscall(restrict, fd, 0) != 0:
            raise RuntimeError("Cannot activate worker confinement")
    finally:
        os.close(fd)
    if os.geteuid() == 0:
        os.setgroups([])
        os.setgid(65534)
        os.setuid(65534)
