"""Deterministic read policy and schema-bound MCP evidence recipes.

The remote catalogue is data, never authority to execute a new tool. These
recipes cannot approve a repair or invoke generic service / shell dispatch.
"""
from __future__ import annotations

import datetime as dt
import json
import re
from typing import Any

METADATA = frozenset({'search', 'explain', 'schema', 'list_resources'})
HA_READS = frozenset({
    'ha_search', 'ha_get_state', 'ha_get_history', 'ha_get_automation_traces',
    'ha_get_entity', 'ha_get_system_health',
})
READ_TOOLS = METADATA | HA_READS
ENTITY = re.compile(r'(?<![a-zA-Z0-9_./])(?:automation|script|light|switch|sensor|binary_sensor|'
                    r'device_tracker|climate|cover|fan|button|input_boolean|'
                    r'input_number|media_player|lock|vacuum|number|select)\.[a-z0-9_]+(?![a-zA-Z0-9_.*-])')


def entity_ids(value):
    # A traceback filename or masked ID is not an exact HA target.
    return list(dict.fromkeys(e for e in ENTITY.findall(str(value).lower())
                             if e.split('.', 1)[1] not in {'py', 'yaml', 'yml', 'json', 'js'}))


def readable_tools(catalog: dict) -> list[dict]:
    return [item for item in catalog.get('tools', []) if isinstance(item, dict)
            and item.get('name') in READ_TOOLS
            and (item.get('annotations') or {}).get('readOnlyHint') is not False]


def result_error(value: Any, depth=0) -> bool:
    """Understand transport-success/tool-error and JSON encoded text errors."""
    if value is None:
        return True
    if depth > 8:
        return True
    if isinstance(value, str) and len(value) <= 24000:
        try:
            decoded = json.loads(value)
            if decoded != value:
                return result_error(decoded, depth+1)
        except (ValueError, TypeError):
            pass
    if isinstance(value, dict):
        if value.get('isError') or value.get('success') is False or value.get('error'):
            return True
        if 'structuredContent' in value and result_error(value['structuredContent'], depth+1):
            return True
        for item in value.get('content', []) if isinstance(value.get('content'), list) else []:
            if isinstance(item, dict) and item.get('type') == 'text':
                try:
                    decoded = json.loads(item.get('text', ''))
                except (ValueError, TypeError):
                    continue
                if result_error(decoded, depth+1):
                    return True
    return False


def observation(output: dict) -> bool:
    name = output.get('tool')
    is_read = name in HA_READS or (name == 'call' and output.get('read_path_verified') is True)
    return bool(is_read and 'result' in output and not output.get('error')
                and not result_error(output['result']) and not output.get('truncated'))


def result_partial(value: Any, depth=0) -> bool:
    if depth > 8:
        return True
    if isinstance(value, str) and len(value) <= 24000:
        try:
            decoded = json.loads(value)
            if decoded != value:
                return result_partial(decoded, depth+1)
        except (ValueError, TypeError):
            pass
    if isinstance(value, dict):
        if any(value.get(key) for key in ('partial', 'has_more', 'truncated', 'errors')):
            return True
        if result_partial(value.get('structuredContent'), depth+1):
            return True
        for block in value.get('content', []) if isinstance(value.get('content'), list) else []:
            if isinstance(block, dict) and block.get('type') == 'text':
                try:
                    if result_partial(json.loads(block.get('text', '')), depth+1):
                        return True
                except (ValueError, TypeError):
                    pass
    return False


def fits(value: Any, schema: dict) -> bool:
    """Small fail-closed schema subset; unsupported required shapes are skipped."""
    if not isinstance(schema, dict) or '$ref' in schema or 'allOf' in schema or 'not' in schema:
        return False
    if 'anyOf' in schema:
        return any(fits(value, option) for option in schema['anyOf'])
    if 'oneOf' in schema:
        return sum(fits(value, option) for option in schema['oneOf']) == 1
    kinds = schema.get('type')
    kinds = kinds if isinstance(kinds, list) else [kinds]
    match = any((kind == 'string' and isinstance(value, str)) or
                (kind == 'array' and isinstance(value, list) and
                 all(fits(child, schema.get('items', {})) for child in value)) or
                (kind == 'integer' and type(value) is int) or
                (kind == 'number' and type(value) in (int, float)) or
                (kind == 'boolean' and type(value) is bool) or
                (kind == 'object' and isinstance(value, dict) and not value
                 and not schema.get('required') and not schema.get('minProperties', 0)) or
                (kind == 'null' and value is None) for kind in kinds)
    if not match or ('enum' in schema and value not in schema['enum']):
        return False
    if type(value) in (int, float):
        return schema.get('minimum', value) <= value <= schema.get('maximum', value)
    if isinstance(value, str):
        return schema.get('minLength', 0) <= len(value) <= schema.get('maxLength', len(value))
    return True


def bind(tool: dict, values: dict) -> tuple[dict | None, str]:
    schema = tool.get('inputSchema') or {}
    if schema.get('type') != 'object' or any(k in schema for k in ('$ref', 'allOf', 'oneOf', 'anyOf')):
        return None, 'Nepodporované vstupní schéma nástroje.'
    props, required = schema.get('properties') or {}, schema.get('required') or []
    args = {}
    for name, value in values.items():
        if name not in props:
            continue
        candidates = [value]
        if isinstance(value, list) and all(isinstance(item, str) for item in value):
            candidates.append(','.join(value))
        selected = next((item for item in candidates if fits(item, props[name])), None)
        if selected is not None:
            args[name] = selected
    missing = [name for name in required if name not in args]
    if missing:
        return None, 'Chybí doložené parametry: ' + ', '.join(map(str, missing))
    return args, ''


def recipes(query: str, case: dict | None = None) -> list[tuple[str, dict, str]]:
    entities = entity_ids(query)[:4]
    owners = [entity for entity in entities if entity.startswith(('automation.', 'script.'))]
    result = []
    if entities:
        result.append(('ha_get_state', {'entity_id': entities if len(entities) > 1 else entities[0], 'entity_ids': entities}, 'Aktuální stav dotčených entit'))
        result.append(('ha_get_entity', {'entity_id': entities[0]}, 'Registr dotčené entity'))
        if owners:
            result.append(('ha_get_automation_traces', {'automation_id': owners[0], 'limit': 3, 'deduplicate': True, 'detailed': False}, 'Poslední uložené stopy automatizace / skriptu'))
        # Anchor history to the event when available, never silently substitute
        # today's history for yesterday's failed automation.
        values = {'entity_ids': entities, 'limit': 100, 'minimal_response': True}
        stamp = str((case or {}).get('last_seen') or (case or {}).get('last_seen_at') or '')
        try:
            event = dt.datetime.fromisoformat(stamp.replace('Z', '+00:00'))
            if event.tzinfo is None:
                raise ValueError('timezone missing')
            values.update(start_time=(event - dt.timedelta(hours=1)).isoformat(),
                          end_time=(event + dt.timedelta(minutes=15)).isoformat())
        except ValueError:
            values['start_time'] = '24h'
        result.append(('ha_get_history', values, 'Historie v okně události' if 'end_time' in values else 'Historie posledních 24 h; čas události není doložen'))
    else:
        result.append(('ha_search', {'query': query[:300], 'limit': 3,
                       'include_config': False, 'include_attributes': False,
                       'result_fields': ['entity_id', 'friendly_name', 'state'],
                       'fields': ['success', 'entities', 'has_more', 'next_offset']},
                       'Omezené vyhledání souvisejících entit; nenahrazuje funkční test'))
    if any(word in query.lower() for word in ('memory', 'oom', 'ram', 'zigbee', 'zha', 'supervisor', 'core', 'health')):
        result.append(('ha_get_system_health', {}, 'Dostupná systémová diagnostika'))
    return result[:5]


def search_entities(value: Any) -> list[str]:
    """Extract typed IDs from bounded JSON search results, never arbitrary prose.

    A result is untrusted evidence, not permission to call new tool names. Only
    existing entity-scoped read recipes may use these IDs. Preserve search rank.
    """
    found, visited = [], [0]

    def walk(item, depth=0):
        visited[0] += 1
        if visited[0] > 500 or depth > 8:
            return
        if isinstance(item, str) and len(item) <= 24000:
            try:
                decoded = json.loads(item)
                if decoded != item:
                    walk(decoded, depth+1)
            except (ValueError, TypeError):
                pass
        elif isinstance(item, dict):
            for key in ('entity_id', 'entity_ids'):
                raw = item.get(key)
                for candidate in raw if isinstance(raw, list) else [raw]:
                    if isinstance(candidate, str) and ENTITY.fullmatch(candidate) and candidate in entity_ids(candidate) and candidate not in found:
                        found.append(candidate)
                        if len(found) >= 4:
                            return
            for block in item.get('content', []) if isinstance(item.get('content'), list) else []:
                if isinstance(block, dict) and block.get('type') == 'text':
                    raw = block.get('text', '')
                    if isinstance(raw, str) and len(raw) <= 24000:
                        try:
                            walk(json.loads(raw), depth + 1)
                        except (ValueError, TypeError):
                            pass
            for key, child in item.items():
                if key not in {'content', 'entity_id', 'entity_ids', 'inputSchema', 'schema'} and isinstance(child, (dict, list)):
                    walk(child, depth + 1)
                    if len(found) >= 4:
                        return
        elif isinstance(item, list):
            for child in item[:100]:
                walk(child, depth + 1)
                if len(found) >= 4 or visited[0] > 500:
                    break

    walk(value)
    return found[:4]


def search_followup_safe(value, depth=0):
    """Pagination is incomplete coverage, but a valid returned ID can be read.

    Explicit errors/truncation/partial data still block follow-up. Search only
    supplies a read-only lead, never a confirmed identity or a repair target.
    """
    if depth > 8:
        return False
    if isinstance(value, str):
        if len(value) > 24000:
            return False
        try:
            return search_followup_safe(json.loads(value), depth+1)
        except (ValueError, TypeError):
            return True
    if isinstance(value, dict):
        if result_error(value) or any(value.get(k) for k in ('partial', 'truncated', 'errors')):
            return False
        return all(search_followup_safe(v, depth+1) for k,v in value.items()
                   if k not in {'inputSchema', 'schema'} and isinstance(v, (dict, list, str)))
    if isinstance(value, list):
        return len(value) <= 100 and all(search_followup_safe(v, depth+1) for v in value)
    return True


def ha_mcp_setup(url_present: bool, probe: dict | None) -> dict:
    """Public setup explanation. Never return a URL, token or remote tool text."""
    known = [name for name in (probe or {}).get('tools', []) if name in HA_READS]
    missing = sorted(HA_READS - set(known))
    if not url_present:
        state, message = 'needs_endpoint', 'HA-MCP zatím nemá ověřenou adresu pro HADS.'
        action = 'V HA-MCP otevřete připojení / Connect a zkopírujte skutečnou MCP URL do ha_mcp_url. Nepoužívejte adresu Ingress panelu.'
    elif probe is None:
        state, message = 'connection_failed', 'Adresa byla nalezena nebo vyplněna, ale MCP spojení se nepodařilo ověřit.'
        action = 'Ověřte běh HA-MCP, dostupnost adresy z HAOS a způsob přihlášení. Tajná cesta je přihlašovací údaj; nezveřejňujte ji.'
    elif not known:
        state, message = 'needs_read_tools', 'Server odpověděl, ale nezveřejnil žádný z podporovaných diagnostických nástrojů HADS.'
        action = 'Ponechte Read Only Mode zapnutý. Připněte čtecí nástroje nebo vypněte jejich skrytí přes Tool Search a obnovte spojení.'
    elif probe.get('catalog_complete') is False:
        state, message = 'partial_catalog', 'Část čtecích nástrojů je dostupná; katalog nebyl načten celý.'
        action = 'Zpřístupněte potřebné čtecí nástroje přímo v katalogu. Neúplný katalog není potvrzení kompletního napojení.'
    else:
        state, message = 'read_tools_ready', 'Čtecí nástroje jsou dostupné. Katalog ještě není vyšetření incidentu ani potvrzení zdraví.'
        action = 'Při vyšetřování sledujte Poslední cílené čtení a jeho důkazy. Ověřit spojení samo nečte historii každého incidentu.'
    return {'state': state, 'message': message, 'next_step': action,
            'supported_reads_available': len(known), 'missing_read_tools': missing,
            'purpose': 'Přístup k důkazům HA: stav, registr, historie a stopy automatizace. MCP není AI model ani schválení opravy.'}


def evidence_summary(outputs: list[dict], skipped: list[dict]) -> dict:
    reads = sum(observation(item) for item in outputs)
    failures = sum(bool(item.get('error')) or result_error(item.get('result')) for item in outputs)
    truncated = sum(bool(item.get('truncated')) for item in outputs)
    partial = sum(bool(item.get('partial')) for item in outputs)
    return {'successful_reads': reads, 'tool_errors': failures, 'truncated_results': truncated,
            'metadata_calls': sum(item.get('tool') in METADATA for item in outputs), 'partial_responses': partial,
            'skipped': skipped,
            'state': 'partial' if reads and (failures or skipped or truncated or partial) else
                     'read_completed' if reads else 'no_diagnostic_data',
            'note': 'Čtení není potvrzení zdraví zařízení ani úspěchu opravy.'}
