# HADS Hermes 2 — hranice oprávnění a rozsah

Ingress UI -> HADS diagnostika -> Hermes worker -> požadavek na čtení
-> validátor katalogu/JSON argumentů -> HADS čtecí nástroje -> důkazy
-> další Hermes krok -> strukturovaný závěr -> kompilátor přesného plánu
-> náhled -> schválení -> ověřené OneDrive zálohy -> vykonavatel -> ověření.

Modelový tok: Hermes AIAgent -> dočasný autentizovaný localhost broker
-> perzistentní HADS limity -> OpenAI Responses -> účtenka skutečné usage.
Worker nedostává skutečný API klíč ani Supervisor token. Broker nevystavuje
HA čtení ani opravy; propustí pouze jeden modelový požadavek na krok.

## Proti dodanému návrhu

- HADS produkt + Hermes analytik: implementováno.
- HAOS aplikace a ARM64: připraven build, na RPi dosud neověřeno.
- Ne-AI sběr, konektory, historie, chat, schválení, zálohy: převzato a testováno.
- Nová samostatná HACS integrace a průvodce propojením: nejsou v této RC;
  použité je stávající Ingress UI a publikování HA senzorů.
- Lokální model a více providerů: upstream umožňuje, tato RC používá
  stávající OpenAI Responses bránu. Nejde o slib nové podpory.
- Automatické skills, shell, browser a delegace: záměrně vypnuté.
- Libovolná oprava: není slíbena. Pouze podporované akce přes existující
  kompilátor a vykonavatel; chybějící vykonavatel není falešný plán.

## Izolace a testování

Povinné Landlock ABI 4: žádné /data, /share, /config, /homeassistant ani
/proc se soukromými daty ostatních procesů. Zápis pouze do soukromého HOME,
exec nikde. TCP port jen broker, Python síťová pojistka navíc jen loopback.
Root oprávnění se zahazují. Přístup přes předané stdin/stdout je záměrný.
Není to VM ani ochrana před exploitem jádra. Upstream a závislosti jsou
důvěryhodný kód; model a konektorová data nikoli.

Windows offline test není test skutečného Landlock. Při Docker sestavení
je povinný skutečný AIAgent smoke test s falešným lokálním modelem. Živé
HAOS, konektory, cloud readback a funkční opravu je třeba ověřit po instalaci.
