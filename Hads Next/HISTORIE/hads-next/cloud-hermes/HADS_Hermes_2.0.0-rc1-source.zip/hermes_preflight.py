"""Read-only installer preflight before add-on sources are replaced."""
import ctypes
import platform
import sys


def check():
    if sys.platform != "linux" or sys.maxsize <= 2**32 or platform.machine() not in {"aarch64", "x86_64", "arm64"}:
        raise RuntimeError("HADS Hermes vyžaduje 64bit HAOS (aarch64 nebo amd64).")
    libc = ctypes.CDLL(None, use_errno=True)
    libc.syscall.restype = ctypes.c_long
    abi = libc.syscall(444, 0, 0, 1)
    if abi < 4:
        raise RuntimeError("Jádro nebo bezpečnostní profil neposkytuje Landlock ABI 4. Původní zdroje HADS zatím nebyly nahrazeny.")
    print("64bit Linux a Landlock ABI " + str(abi) + " ověřeny. Cílový kontejner vyžaduje samostatný test.")


if __name__ == "__main__":
    try:
        check()
    except Exception as exc:
        print("Instalace Hermes zastavena: " + str(exc), file=sys.stderr)
        sys.exit(1)
