"""Authenticated controller orchestration around the existing guarded executor."""
from contextlib import closing
import json
import threading
import time
from datetime import datetime
from .managed_repair import ManagedReferenceEngine,MISSING,TARGET
from .repair import ApprovalAuthority,RepairBlocked,RepairPlan,connect
from .verification import FunctionalVerifier

class RepairService:
    def __init__(self,app):
        self.app=app;self.root=app.data_dir/'managed-repair';self.root.mkdir(mode=0o700,exist_ok=True)
        self.companion_checked_at=None;self.enabled=False;self.last_error=None;self.stop=threading.Event();self.thread=None
        self.observations=[];self.lock=threading.RLock();self.trigger_coverage=None;self.trigger_heartbeat=None
        with app.store._connect() as db:db.execute('CREATE TABLE IF NOT EXISTS managed_repair_settings(id INTEGER PRIMARY KEY,enabled INTEGER NOT NULL DEFAULT 0)');db.execute('INSERT OR IGNORE INTO managed_repair_settings VALUES(1,0)')
        connect(app.store.db_path).close()

    def owner_only(self,principal):
        if not principal or principal!=self.app.owner():raise RepairBlocked('Tuto operaci smí potvrdit pouze vlastník.')

    def engine(self):
        if not self.status()['enabled'] or self.app.core_ws is None:raise RepairBlocked('Nejprve povol izolovaný testovací katalog a ověř companion.')
        return ManagedReferenceEngine(self.app.store.db_path,self.root,self.app.core_ws.transport,owner=self.app.owner())

    def configure(self,enabled,principal):
        self.owner_only(principal)
        if type(enabled) is not bool:raise RepairBlocked('Neplatný souhlas.')
        if enabled:
            if self.app.core_ws is None:raise RepairBlocked('Core není dostupný.')
            try:value=self.app.core_ws.transport({'type':'hads_reference/read'})
            except Exception:raise RepairBlocked('Companion není dostupný nebo odmítl přístup. Katalog se nepovolil.') from None
            ManagedReferenceEngine._entity(value)
            self.companion_checked_at=self.app.clock()
        with self.app.store._connect() as db:db.execute('UPDATE managed_repair_settings SET enabled=? WHERE id=1',(int(enabled),))
        if enabled:self.start()

    def status(self):
        with self.app.store._connect() as db:enabled=bool(db.execute('SELECT enabled FROM managed_repair_settings WHERE id=1').fetchone()[0])
        return {'enabled':enabled,'catalog':'integration_owned_virtual_test_reference','native_automation_writes':False,
            'last_error':self.last_error,'companion_checked_at':self.companion_checked_at,'backup':'Ověřený snapshot jediné reference; není to záloha HAOS/OneDrive.',
            'one_drive_risky_operations':'blocked_no_independent_restore_proof'}

    def plans(self,incident_id):
        with closing(connect(self.app.store.db_path)) as db:
            rows=db.execute('SELECT p.id,p.document,e.status,e.id AS execution_id FROM repair_plans p LEFT JOIN repair_executions e ON e.plan_id=p.id ORDER BY p.created_at DESC LIMIT 100').fetchall()
        result=[]
        for r in rows:
            document=json.loads(r['document'])
            if document['incident_id']==incident_id and document['operation']=='core_managed.replace_entity_reference':
                result.append({'plan_id':r['id'],'document':document,'status':r['status'],'execution_id':r['execution_id']})
        return result

    def plan(self,identity):
        with closing(connect(self.app.store.db_path)) as db:row=db.execute('SELECT document FROM repair_plans WHERE id=?',(identity,)).fetchone()
        if not row:raise RepairBlocked('Plán neexistuje.')
        return RepairPlan(row[0])

    def prepare(self,incident_id,principal):
        # Preserve the status of each native read across concurrent diagnostics.
        with self.app._read_lock:return self._prepare_locked(incident_id,principal)

    def _prepare_locked(self,incident_id,principal):
        self.owner_only(principal);case=self.app.store.case(incident_id)
        ids=[e['evidence_id'] for e in case['evidence']]
        if not ids:raise RepairBlocked('Nejprve získej důkazy funkční poruchy.')
        # This independent validator supports one exact managed test resource.
        engine=self.engine();original=json.loads(engine._read(engine.FILENAME))
        if engine._entity(original)!=MISSING:raise RepairBlocked('Testovací reference již není chybná.')
        old=self.app.core.states(MISSING) if self.app.core else None
        if old is not None or self.app.core is None or self.app.core.status.last_response_status!=404:raise RepairBlocked('Původní reference není doložená jako chybějící. Chyba připojení nebo oprávnění není důkaz neexistence.')
        state=self.app.core.states(TARGET) if self.app.core else None
        if not isinstance(state,dict) or state.get('state') not in {'off','on'}:raise RepairBlocked('Virtuální cíl není čitelný.')
        if 'input_boolean.hads_next_test_target' not in case['incident']['components'] and 'automation.hads_next_reference_test' not in case['incident']['components']:raise RepairBlocked('Tento spis se netýká podporované testovací automatizace.')
        jobs=self.app.investigations.for_case(incident_id)
        suggestion=(jobs[0].get('conclusion') or {}).get('repair_suggestion') if jobs else None
        if suggestion and suggestion.get('status')=='supported_managed_candidate':
            from .repair_suggestions import RepairSuggestion,prepare_reference_plan
            from .repair import canonical
            plan=prepare_reference_plan(RepairSuggestion(canonical(suggestion)),engine,engine.FILENAME,watch_seconds=10)
        else:
            plan=engine.prepare_entity_reference(incident_id,engine.FILENAME,MISSING,TARGET,ids,'Doložená vlastní testovací reference ukazuje na neexistující virtuální cíl.',watch_seconds=10)
        self.app.store.record(incident_id,'repair_plan_prepared',{'plan_id':plan.plan_id,'scope':'owned_virtual_reference'})
        return plan

    def decide(self,identity,decision,principal):
        self.owner_only(principal);plan=self.plan(identity)
        authority=ApprovalAuthority(self.app.store.db_path,owner=self.app.owner())
        # Reject/manual revoke previous approvals too; neither performs a write.
        token=authority.decide(plan,principal=principal,decision=decision)
        self.app.store.record(plan.document['incident_id'],'repair_decision',{'plan_id':identity,'decision':decision,'principal':principal})
        if decision!='approve':return None
        if self.trigger_coverage is None or self.app.clock()-(self.trigger_heartbeat or 0)>15:raise RepairBlocked('Neprobíhá ověřený odběr automatizace. Schválení nic neprovedlo; po obnovení zkontroluj plán znovu.')
        execution=self.engine().execute(plan,token,principal=principal)
        with self.lock:self.observations=[]
        self.app.store.record(plan.document['incident_id'],'repair_applied',{'plan_id':identity,'execution_id':execution.execution_id,'summary_cs':'Reference změněna přes atomické CAS. Stiskni testovací tlačítko. Ověření čeká.'})
        return execution

    def rollback(self,identity,principal):
        self.owner_only(principal);plan=self.plan(identity)
        case=self.app.store.case(plan.document['incident_id']);evidence=[e['evidence_id'] for e in case['evidence']]
        rollback=self.engine().prepare_rollback(plan,evidence)
        self.app.store.record(plan.document['incident_id'],'rollback_prepared',{'plan_id':rollback.plan_id,'summary_cs':'Návrat vlastní reference vyžaduje samostatné nové schválení. Neobnovuje HAOS.'})
        return rollback

    def on_trigger(self,event):
        if event.get('data',{}).get('entity_id')!='automation.hads_next_reference_test':return
        try:stamp=datetime.fromisoformat(event['time_fired']).timestamp();context=event['context']['id']
        except (ValueError,KeyError,TypeError):return
        with self.lock:
            self.observations.append({'kind':'automation_triggered','observed_at':stamp,'payload':{'automation_id':'hads_next_reference_test','context_id':context}});self.observations=self.observations[-256:]

    def observe_state(self,state,stamp):
        if state['entity_id']!=TARGET:return
        context=state.get('context',{}).get('id')
        with self.lock:
            self.observations.append({'kind':'target_state','observed_at':stamp,'payload':{'entity_id':TARGET,'state':state['state'],'context_id':context}});self.observations=self.observations[-256:]
        # A later legitimate off alone is not recurrence. A failed new trigger
        # is detected by the functional monitor, not by arbitrary state changes.

    def verify_pending(self):
        now=self.app.clock();detector=self.app.detection.health
        if detector['state']!='listening' or now-(detector['heartbeat_at'] or 0)>15 or self.trigger_coverage is None or now-(self.trigger_heartbeat or 0)>15:return
        with closing(connect(self.app.store.db_path)) as db:
            rows=db.execute("SELECT p.id,p.document FROM repair_plans p JOIN repair_executions e ON e.plan_id=p.id WHERE e.status='applied_verification_pending'").fetchall()
        for row in rows:
            plan=RepairPlan(row['document'])
            if plan.document['operation']!='core_managed.replace_entity_reference':continue
            engine=self.engine();execution=engine.execution(row['id'])
            if plan.document['rollback']['rollback_of']:
                # Exact readback is configuration rollback evidence, not a
                # functional success of the deliberately broken old reference.
                if json.loads(engine._read(engine.FILENAME))==plan.document['proposed']:
                    with closing(connect(self.app.store.db_path)) as db:db.execute("UPDATE repair_executions SET status='rollback_reference_restored' WHERE id=?",(execution.execution_id,))
                    self.app.store.record(plan.document['incident_id'],'rollback_report',{'classification':'Návrat reference ověřen čtením; funkční problém trvá','plan_id':plan.plan_id,'haos_restored':False})
                continue
            with self.lock:observations=list(self.observations)
            current=self.app.core.states(TARGET) if self.app.core else None
            if not isinstance(current,dict) or current.get('state')!=plan.document['verification']['state']:continue
            observations.append({'kind':'monitoring_checkpoint','observed_at':now,'payload':{'entity_id':TARGET,'continuous_since':max(execution.completed_at,detector['continuous_since'] or now,self.trigger_coverage),'healthy':True}})
            report=FunctionalVerifier(self.app.store.db_path).evaluate(plan,execution,observations)
            if report['classification']=='Vyřešeno a ověřeno':self.app.store.mark_resolved(plan.document['incident_id'],report)

    def on_functional_failure(self,incident_id,entity,stamp,identity):
        with closing(connect(self.app.store.db_path)) as db:
            rows=db.execute("SELECT p.id,p.document FROM repair_plans p JOIN repair_executions e ON e.plan_id=p.id WHERE e.status='verified'").fetchall()
        for row in rows:
            plan=RepairPlan(row['document'])
            if plan.document['incident_id']!=incident_id or plan.document['operation']!='core_managed.replace_entity_reference' or plan.document['verification']['entity_id']!=entity:continue
            engine=self.engine();execution=engine.execution(row['id'])
            report=FunctionalVerifier(self.app.store.db_path).evaluate(plan,execution,[{'kind':'functional_failure','observed_at':stamp,'payload':{'entity_id':entity,'event_id':identity}}])
            self.app.store.reopen_for_report(incident_id,report)

    def start(self):
        transport=getattr(self.app.core_ws,'transport',None)
        if not callable(getattr(transport,'automation_events',None)):return False
        if self.thread and self.thread.is_alive():return True
        self.stop.clear()
        def ready():self.trigger_coverage=self.app.clock();self.trigger_heartbeat=self.app.clock()
        def heartbeat():self.trigger_heartbeat=self.app.clock()
        def run():
            while not self.stop.is_set():
                try:transport.automation_events(self.stop,self.on_trigger,ready,heartbeat)
                except Exception:self.last_error='Odběr spuštění automatizace není dostupný.'
                self.trigger_coverage=None
                if self.stop.wait(10):break
        self.thread=threading.Thread(target=run,daemon=True,name='hads-repair-verification');self.thread.start();return True

    def close(self):
        self.stop.set()
        if self.thread:self.thread.join(timeout=3)
